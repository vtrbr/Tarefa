# Tedflix

Aplicativo Android e versão web do Tedflix.

## APIs oficiais (3 servidores)

| Serviço | URL base | Uso |
|---|---|---|
| **CONTENT** (catálogo) | `https://servidores-ted-auth-1.onrender.com/api` | Home, carousel, agenda, lançamentos, filmes, séries, temporadas, episódios, gêneros, busca, player HLS |
| **USER / ADMIN** | `https://servidores-ted-auth.onrender.com` | Cadastro, login, sessão, perfis, favoritos, progresso, histórico, assinatura, admin |
| **TEDTOP** | `https://servidores-ted-apply2.onrender.com` | Conteúdo complementar, trailers YouTube, ingresso/player direto, radar, bilheteria, telao |

### Regras de integração

- **CONTENT** é a autoridade sobre catálogo e estrutura de séries/filmes.
- **USER** é a autoridade sobre estado privado do usuário (favoritos, progresso, histórico, perfil).
- **TEDTOP** é a autoridade sobre trailers, links de ingresso e recursos TEDTOP.
- O frontend **orquestra** as três fontes e normaliza os dados na interface.
- Não misturar endpoints entre servidores.
- Não usar `x-access-token`, `/validar/:token` ou autenticação antiga.
- Chamadas protegidas do USER usam `Authorization: Bearer <Firebase ID Token>`.
- Fluxo de entrada: **login/cadastro → perfis → seleção do perfil → validação de acesso → catálogo**.

### Configuração no código

As URLs estão centralizadas em:

- `app/src/main/assets/tedflix/js/config.js` (CONTENT, USER, TEDTOP)
- `app/src/main/java/com/tedflix/app/auth/AuthSession.kt` (USER + CONTENT no lado nativo)

## Estrutura

- `app/`: projeto Android (Kotlin + WebView com assets web).
- Assets web: `app/src/main/assets/tedflix/` (HTML/JS/CSS).
- `artifacts/`: artefatos locais de build (não versionados).

## Trailer YouTube (TEDTOP)

Na tela de detalhes, o app consulta `GET /filme/:slug` no TEDTOP.  
Se o campo `trailer` existir, extrai o videoId e embute o player YouTube (`youtube.com/embed/{id}`).  
Se o trailer estiver ausente ou inválido, a seção é omitida sem quebrar a tela.

## Validação local (assets web)

```bash
cd app/src/main/assets/tedflix
python3 -m http.server 4173
```

Abra `http://localhost:4173` no navegador.
