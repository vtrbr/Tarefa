import { el, limpar } from "../dom.js";
import { cardTitulo, skeletonCard } from "../components/card.js";
import {
  getTedtopPorAno,
  getTedtopPorLetra,
  getTedtopPorGenero,
  getTedtopRadar,
  getTedtopTelao,
  getTedtopBilheteria,
} from "../api.js";

const ANOS = Array.from({ length: 12 }, (_, i) => String(2026 - i));
const LETRAS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");
const GENEROS_TEDTOP = [
  { slug: "acao", label: "Ação" },
  { slug: "aventura", label: "Aventura" },
  { slug: "comedia", label: "Comédia" },
  { slug: "drama", label: "Drama" },
  { slug: "terror", label: "Terror" },
  { slug: "romance", label: "Romance" },
  { slug: "ficcao", label: "Ficção" },
  { slug: "suspense", label: "Suspense" },
  { slug: "animacao", label: "Animação" },
  { slug: "documentario", label: "Documentário" },
];

function skeletonGrid(n = 8) {
  const g = el("div", { class: "grid pad" });
  for (let i = 0; i < n; i++) g.append(skeletonCard());
  return g;
}

function renderItens(grid, itens) {
  limpar(grid);
  if (!itens.length) {
    grid.append(el("p", { class: "sub pad" }, "Nenhum título encontrado."));
    return;
  }
  const frag = document.createDocumentFragment();
  itens.forEach((item, i) => frag.append(cardTitulo(item, { size: "sm", eager: i < 8 })));
  grid.append(frag);
}

function erroComRetry(grid, msg, onRetry) {
  limpar(grid);
  grid.append(
    el("div", { class: "pad" }, [
      el("p", { class: "sub" }, msg || "Não foi possível carregar."),
      el("button", { class: "btn ghost", type: "button", onclick: onRetry }, "Tentar de novo"),
    ]),
  );
}

/** Telão */
export async function paginaTedtopTelao(raiz) {
  return paginaLista(raiz, "Em cartaz (Telão)", async () => {
    const d = await getTedtopTelao(1);
    return d.itens || [];
  });
}

/** Bilheteria */
export async function paginaTedtopBilheteria(raiz) {
  return paginaLista(raiz, "Bilheteria", async () => getTedtopBilheteria());
}

async function paginaLista(raiz, titulo, carregar) {
  const page = el("div", { class: "page" });
  page.append(el("h1", { class: "page-title" }, titulo));
  const grid = skeletonGrid();
  page.append(grid);
  raiz.append(page);
  try {
    renderItens(grid, (await carregar()) || []);
  } catch (e) {
    erroComRetry(grid, "Falha ao carregar.", async () => {
      limpar(grid);
      grid.append(...Array.from({ length: 6 }, () => skeletonCard()));
      try {
        renderItens(grid, (await carregar()) || []);
      } catch (_) {
        erroComRetry(grid, "Ainda sem dados.", () => location.reload());
      }
    });
  }
  return page;
}

/** Por ano — GET /sessao/ano/:ano */
export default function paginaTedtopPorAno(raiz, { ano: anoInicial } = {}) {
  const page = el("div", { class: "page" });
  page.append(el("h1", { class: "page-title" }, "Filmes por ano"));
  page.append(el("p", { class: "sub pad", style: "padding-top:0" }, "Dados reais da TEDTOP · /sessao/ano/:ano"));

  const chips = el("div", { class: "pad tedtop-chips tedtop-chips--wide" });
  const grid = skeletonGrid();
  let atual = String(anoInicial || ANOS[0]);
  let reqId = 0;

  async function carregar(ano) {
    atual = String(ano);
    const my = ++reqId;
    [...chips.children].forEach((b) => b.classList.toggle("active", b.dataset.ano === atual));
    limpar(grid);
    for (let i = 0; i < 8; i++) grid.append(skeletonCard());
    try {
      const d = await getTedtopPorAno(atual);
      if (my !== reqId) return; // resposta antiga
      renderItens(grid, d.itens || []);
    } catch (e) {
      if (my !== reqId) return;
      erroComRetry(grid, `Erro ao carregar ${atual}.`, () => carregar(atual));
    }
  }

  ANOS.forEach((ano) => {
    const btn = el("button", {
      class: `chip${ano === atual ? " active" : ""}`,
      type: "button",
      "data-ano": ano,
    }, ano);
    btn.addEventListener("click", () => {
      location.hash = `#/tedtop/ano/${ano}`;
      carregar(ano);
    });
    chips.append(btn);
  });

  page.append(chips, grid);
  raiz.append(page);
  carregar(atual);
  return page;
}

/** Por letra — GET /alfabeto/:letra */
export function paginaTedtopPorLetra(raiz, { letra: letraInicial } = {}) {
  const page = el("div", { class: "page" });
  page.append(el("h1", { class: "page-title" }, "Por letra"));
  page.append(el("p", { class: "sub pad", style: "padding-top:0" }, "Navegação alfabética TEDTOP · /alfabeto/:letra"));

  const chips = el("div", { class: "pad tedtop-chips" });
  const grid = skeletonGrid();
  let atual = String(letraInicial || "A").toUpperCase().slice(0, 1);
  let reqId = 0;

  async function carregar(letra) {
    atual = String(letra).toUpperCase().slice(0, 1);
    const my = ++reqId;
    [...chips.children].forEach((b) => b.classList.toggle("active", b.dataset.letra === atual));
    limpar(grid);
    for (let i = 0; i < 8; i++) grid.append(skeletonCard());
    try {
      const d = await getTedtopPorLetra(atual);
      if (my !== reqId) return;
      renderItens(grid, d.itens || []);
    } catch (e) {
      if (my !== reqId) return;
      erroComRetry(grid, `Erro na letra ${atual}.`, () => carregar(atual));
    }
  }

  LETRAS.forEach((L) => {
    const btn = el("button", {
      class: `chip${L === atual ? " active" : ""}`,
      type: "button",
      "data-letra": L,
    }, L);
    btn.addEventListener("click", () => {
      location.hash = `#/tedtop/letra/${L}`;
      carregar(L);
    });
    chips.append(btn);
  });

  page.append(chips, grid);
  raiz.append(page);
  carregar(atual);
  return page;
}

/** Por gênero TEDTOP */
export function paginaTedtopPorGenero(raiz, { genero: genInicial } = {}) {
  const page = el("div", { class: "page" });
  page.append(el("h1", { class: "page-title" }, "Gêneros TEDTOP"));
  const chips = el("div", { class: "pad tedtop-chips tedtop-chips--wide" });
  const grid = skeletonGrid();
  let atual = genInicial || GENEROS_TEDTOP[0].slug;
  let reqId = 0;

  async function carregar(g) {
    atual = g;
    const my = ++reqId;
    [...chips.children].forEach((b) => b.classList.toggle("active", b.dataset.g === atual));
    limpar(grid);
    for (let i = 0; i < 8; i++) grid.append(skeletonCard());
    try {
      const d = await getTedtopPorGenero(atual);
      if (my !== reqId) return;
      renderItens(grid, d.itens || []);
    } catch (e) {
      if (my !== reqId) return;
      erroComRetry(grid, "Erro ao carregar gênero.", () => carregar(atual));
    }
  }

  GENEROS_TEDTOP.forEach((g) => {
    const btn = el("button", {
      class: `chip${g.slug === atual ? " active" : ""}`,
      type: "button",
      "data-g": g.slug,
    }, g.label);
    btn.addEventListener("click", () => {
      location.hash = `#/tedtop/genero/${g.slug}`;
      carregar(g.slug);
    });
    chips.append(btn);
  });

  page.append(chips, grid);
  raiz.append(page);
  carregar(atual);
  return page;
}

/** Radar live */
export function paginaTedtopRadar(raiz) {
  const page = el("div", { class: "page" });
  page.append(el("h1", { class: "page-title" }, "Radar TEDTOP"));
  page.append(el("p", { class: "sub pad", style: "padding-top:0" }, "Busca ao vivo · /radar/live/:termo"));
  // Busca manual: digita + lupa (ou Enter). Evita spam na API / anti-leechers.
  const campo = el("input", {
    class: "input",
    type: "search",
    placeholder: "Digite um termo…",
    enterkeyhint: "search",
    autocomplete: "off",
    style: "flex:1;min-width:0;margin:0",
  });
  const btnBuscar = el(
    "button",
    {
      class: "btn primary radar-search-btn",
      type: "submit",
      "aria-label": "Buscar",
      title: "Buscar",
      style: "flex:0 0 auto;min-width:48px;padding:10px 14px",
    },
    [
      el("span", {
        html: '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>',
        style: "display:flex;align-items:center;justify-content:center",
      }),
    ],
  );
  const form = el(
    "form",
    {
      class: "radar-search-form",
      style: "display:flex;gap:8px;align-items:center;margin:0 16px;width:calc(100% - 32px)",
    },
    [campo, btnBuscar],
  );
  const aviso = el("p", { class: "sub pad" }, "Digite o termo e toque na lupa para buscar.");
  const grid = el("div", { class: "grid pad" });
  page.append(form, aviso, grid);
  raiz.append(page);

  function mensagemAviso(raw) {
    const s = String(raw || "");
    if (/leech|anti.?leech|prote/i.test(s)) {
      return "A API limitou buscas (proteção anti-leechers). Espere alguns segundos e tente de novo.";
    }
    return s;
  }

  let reqId = 0;
  let busy = false;

  async function buscar() {
    const q = String(campo.value || "").trim();
    if (q.length < 2) {
      aviso.textContent = "Digite ao menos 2 letras.";
      limpar(grid);
      return;
    }
    if (busy) return;
    busy = true;
    btnBuscar.disabled = true;
    const my = ++reqId;
    aviso.textContent = "Buscando…";
    limpar(grid);
    for (let i = 0; i < 4; i++) grid.append(skeletonCard());
    try {
      const d = await getTedtopRadar(q);
      if (my !== reqId) return;
      limpar(grid);
      if (d.aviso) {
        aviso.textContent = mensagemAviso(d.aviso);
        return;
      }
      const itens = d.itens || [];
      aviso.textContent = itens.length ? `${itens.length} resultado(s)` : "Nenhum resultado.";
      if (!itens.length) {
        grid.append(el("p", { class: "sub pad" }, "Nenhum título encontrado."));
        return;
      }
      const frag = document.createDocumentFragment();
      itens.forEach((item, i) => frag.append(cardTitulo(item, { size: "sm", eager: i < 6 })));
      grid.append(frag);
    } catch (e) {
      if (my !== reqId) return;
      aviso.textContent = "Falha no radar. Verifique a conexão e tente de novo.";
      limpar(grid);
    } finally {
      busy = false;
      btnBuscar.disabled = false;
    }
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    buscar();
  });
  setTimeout(() => campo.focus(), 50);
  return page;
}
