import { el, anoCurto } from "../dom.js";
import { backdrop, poster } from "../img.js";
import { rotaDetalhe } from "../api.js";

/** Carrossel de destaques com troca automática (pausa quando fora da tela). */
export function hero(itens) {
  const raiz = el("div", { class: "hero" });
  if (!itens.length) {
    raiz.classList.add("skel");
    return raiz;
  }

  const img = el("img", { alt: "", decoding: "async", fetchpriority: "high" });
  const h1 = el("h1");
  const tags = el("div", { class: "tags" });
  const desc = el("p");
  const btn = el("a", {
    class: "btn",
    html: '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>Assistir',
  });
  const dots = el("div", { class: "dots" });

  raiz.append(
    img,
    el("div", { class: "veil" }),
    el("div", { class: "info" }, [tags, h1, desc, el("div", { style: "margin-top:12px" }, [btn])]),
    dots,
  );

  itens.forEach(() => dots.append(el("i")));

  let atual = 0;
  img.referrerPolicy = "no-referrer";
  img.addEventListener("error", () => {
    const it = itens[atual];
    if (!it) return;
    const raw = absHero(it.imagem || it.banner || it.capa || "");
    if (!raw) return;
    const fallbacks = [
      backdrop(raw, 500),
      poster(raw, "md"),
      poster(raw, "sm"),
      raw.replace(/\/t\/p\/(w\d+|original)\//, "/t/p/w500/"),
      raw,
    ].filter(Boolean);
    const cur = img.getAttribute("src");
    const next = fallbacks.find((u) => u && u !== cur);
    if (next) img.src = next;
  });
  function absHero(u) {
    const s = String(u || "").trim();
    if (s.startsWith("//")) return "https:" + s;
    return s;
  }
  function mostrar(i) {
    atual = i % itens.length;
    const it = itens[atual];
    const raw = absHero(it.imagem || it.banner || it.capa || "");
    img.src = backdrop(raw, 780) || poster(raw, "lg") || raw;
    img.alt = it.titulo || "";
    h1.textContent = it.titulo || "";
    desc.textContent = it.descricao || "";
    btn.href = rotaDetalhe(it);
    tags.innerHTML = "";
    const partes = [
      it.nota ? `★ ${Number(it.nota).toFixed(1)}` : null,
      it.tipo,
      anoCurto(it.ano),
    ].filter(Boolean);
    partes.forEach((p) => tags.append(el("span", {}, p)));
    [...dots.children].forEach((d, k) => d.classList.toggle("on", k === atual));
    // pré-carrega o próximo slide
    const prox = itens[(atual + 1) % itens.length];
    if (prox) new Image().src = backdrop(prox.imagem, 780);
  }

  mostrar(0);

  let arrastando = false;
  let pressionado = false;
  let inicioX = 0;
  let suprimirCliqueAte = 0;
  raiz.addEventListener("pointerdown", (evento) => {
    if (evento.target.closest("a, button")) return;
    if (evento.pointerType === "mouse" && evento.button !== 0) return;
    pressionado = true;
    arrastando = false;
    inicioX = evento.clientX;
    parar();
    try { raiz.setPointerCapture(evento.pointerId); } catch (_) {}
  });
  raiz.addEventListener("pointermove", (evento) => {
    if (!pressionado) return;
    if (Math.abs(evento.clientX - inicioX) > 12) {
      arrastando = true;
      evento.preventDefault();
    }
  }, { passive: false });
  const terminarSwipe = (evento) => {
    if (!pressionado) return;
    const delta = evento.clientX - inicioX;
    if (arrastando && Math.abs(delta) > 34) {
      mostrar(delta < 0 ? atual + 1 : atual - 1 + itens.length);
      suprimirCliqueAte = Date.now() + 420;
    }
    pressionado = false;
    arrastando = false;
    rodar();
  };
  raiz.addEventListener("pointerup", terminarSwipe);
  raiz.addEventListener("pointercancel", terminarSwipe);
  raiz.addEventListener("click", (evento) => {
    if (Date.now() < suprimirCliqueAte) {
      evento.preventDefault();
      evento.stopImmediatePropagation();
      suprimirCliqueAte = 0;
    }
  }, true);

  let timer = null;
  const rodar = () => {
    parar();
    timer = setInterval(() => mostrar(atual + 1), 6000);
  };
  const parar = () => {
    if (timer) clearInterval(timer);
    timer = null;
  };

  const io = new IntersectionObserver((e) => (e[0].isIntersecting ? rodar() : parar()));
  io.observe(raiz);
  raiz.destruir = () => {
    parar();
    io.disconnect();
  };

  return raiz;
}
