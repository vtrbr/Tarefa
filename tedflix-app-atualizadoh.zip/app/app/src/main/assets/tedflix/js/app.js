import { el, svgIcone } from "./dom.js";
import { NAV, CATEGORIAS } from "./config.js";
import { getFilmes, getSeries, getGenero, getLancamentos, buscar, ehSerie, parseLink, limparCacheCatalogo } from "./api.js";
import paginaInicio from "./pages/home.js";
import { paginaCatalogo } from "./pages/catalogo.js";
import paginaCategorias from "./pages/categorias.js";
import paginaAgenda from "./pages/agenda.js";
import paginaCanais, { paginaCanal, paginaEvento } from "./pages/canais.js";
import paginaBusca from "./pages/busca.js";
import paginaDetalhe from "./pages/detalhes.js";
import paginaAssistir from "./pages/assistir.js";
import paginaConfiguracoes from "./pages/configuracoes.js";
import paginaFavoritos from "./pages/favoritos.js";
import { paginaNoflixFilme, paginaNoflixSerie } from "./pages/noflix-detalhes.js";
import paginaNoflixCatalogo from "./pages/noflix-catalogo.js";
import paginaTedtopPorAno, {
  paginaTedtopPorLetra,
  paginaTedtopPorGenero,
  paginaTedtopRadar,
  paginaTedtopTelao,
  paginaTedtopBilheteria,
} from "./pages/tedtop-explorar.js";
import { limparPlayer } from "./components/player.js";
import { medirOcioso } from "./net.js";


const app = document.getElementById("app");
const tabbar = document.getElementById("tabbar");
let atual = null;

/* ---------- navegação inferior ---------- */
NAV.forEach((n) => {
  const a = el("a", { href: n.href, "data-href": n.href });
  a.innerHTML = `${svgIcone(n.icon)}<span>${n.label}</span>`;
  tabbar.append(a);
});

function marcarNav(rota) {
  const semQuery = rota.split("?")[0];
  const base = "#/" + (semQuery.split("/")[1] || "");
  [...tabbar.children].forEach((a) =>
    a.classList.toggle("active", a.dataset.href === (base === "#/" ? "#/" : base)),
  );
}

/* ---------- rotas ---------- */
function resolver(hash) {
  const rota = (hash || "#/").replace(/^#/, "") || "/";
  const [caminho, queryString = ""] = rota.split("?");
  const p = caminho.split("/").filter(Boolean);

  if (!p.length) return (r) => paginaInicio(r);
  // Rotas internas de pull-to-refresh (não renderizam tela)
  if (p[0] === "_ptr" || p[0] === "_refresh") return (r) => paginaInicio(r);
  if (p[0] === "filmes")
    return (r) => paginaNoflixCatalogo(r, { tipo: "filme", titulo: "Filmes" });
  if (p[0] === "lancamentos")
    return (r) => paginaCatalogo(r, { titulo: "Lançamentos", carregar: getLancamentos });
  if (p[0] === "series")
    return (r) => paginaNoflixCatalogo(r, { tipo: "serie", titulo: "Séries" });
  // Catálogo legado Tedflix (sem filtro DUB/LEG)
  if (p[0] === "filmes-ted")
    return (r) => paginaCatalogo(r, { titulo: "Filmes (Tedflix)", carregar: getFilmes });
  if (p[0] === "series-ted")
    return (r) => paginaCatalogo(r, { titulo: "Séries (Tedflix)", carregar: getSeries });
  if (p[0] === "categorias") return (r) => paginaCategorias(r);
  if (p[0] === "categoria" && p[1]) {
    if (p[1] === "lancamentos") return (r) => paginaCatalogo(r, { titulo: "Lançamentos", carregar: getLancamentos });
    const cat = CATEGORIAS.find((c) => c.slug === p[1]);
    return (r) =>
      paginaCatalogo(r, { titulo: cat ? cat.label : p[1], carregar: () => getGenero(p[1]) });
  }
  if (p[0] === "agenda") return (r) => paginaAgenda(r);
  if (p[0] === "busca") return (r) => paginaBusca(r);
  if (p[0] === "favoritos") return (r) => paginaFavoritos(r);
  if (p[0] === "favorito") {
    const params = new URLSearchParams(queryString);
    const titulo = params.get("titulo") || "";
    return async (r) => {
      if (!titulo) {
        r.append(el("p", { class: "center" }, "Favorito sem título disponível."));
        return null;
      }
      try {
        const resposta = await buscar(titulo);
        const itens = resposta.resultados || [];
        const normalizado = (titulo || "").trim().toLowerCase();
        const item = itens.find((i) => (i.titulo || "").trim().toLowerCase() === normalizado) || itens[0];
        if (!item) {
          r.append(el("p", { class: "center" }, "Não foi possível localizar este título no catálogo."));
          return null;
        }
        const link = parseLink(item.link_assistir);
        const categoria = item.categoria || link.categoria;
        const slug = item.slug || link.slug;
        if (!categoria || !slug) {
          r.append(el("p", { class: "center" }, "Este favorito não possui uma rota de detalhe válida."));
          return null;
        }
        return paginaDetalhe(r, { tipo: ehSerie(item) ? "serie" : "filme", categoria, slug });
      } catch (error) {
        r.append(el("p", { class: "center" }, "Não foi possível abrir este favorito agora."));
        return null;
      }
    };
  }
  if (p[0] === "titulo" && p.length >= 4)
    return (r) => paginaDetalhe(r, { tipo: p[1], categoria: p[2], slug: p[3] });
  if (p[0] === "assistir" && p.length >= 3) {
    const params = new URLSearchParams(queryString);
    const lerLista = (nome) => {
      try {
        const valor = params.get(nome);
        const lista = valor ? JSON.parse(valor) : [];
        return Array.isArray(lista) ? lista : [];
      } catch (_) { return []; }
    };
    const fila = lerLista("fila");
    return (r) => paginaAssistir(r, {
      categoria: p[1],
      slug: p[2],
      fila,
      filmeId: params.get("filmeId") || "",
      thumb: params.get("thumb") || "",
      tipo: params.get("tipo") || "",
      serieCategoria: params.get("serieCategoria") || "",
      serieSlug: params.get("serieSlug") || "",
      episodios: lerLista("episodios"),
      recomendados: lerLista("recomendados"),
    });
  }
  if (p[0] === "tedtop" && p[1] === "telao") return (r) => paginaTedtopTelao(r);
  if (p[0] === "tedtop" && p[1] === "bilheteria") return (r) => paginaTedtopBilheteria(r);
  if (p[0] === "tedtop" && p[1] === "ano")
    return (r) => paginaTedtopPorAno(r, { ano: p[2] || "2026" });
  if (p[0] === "tedtop" && p[1] === "letra")
    return (r) => paginaTedtopPorLetra(r, { letra: p[2] || "A" });
  if (p[0] === "tedtop" && p[1] === "genero")
    return (r) => paginaTedtopPorGenero(r, { genero: p[2] || "acao" });
  if (p[0] === "tedtop" && p[1] === "radar") return (r) => paginaTedtopRadar(r);
  // Catálogo NoFlix (listas extras — não remove Tedflix legado)
  if (p[0] === "noflix" && (p[1] === "filmes" || p[1] === "cinema")) {
    const modo = p[2] || "lista"; // lista | top | ano | genero
    return (r) => paginaNoflixCatalogo(r, { tipo: "filme", titulo: "Filmes", modoInicial: modo });
  }
  if (p[0] === "noflix" && (p[1] === "series" || p[1] === "seriados")) {
    const modo = p[2] || "lista"; // lista | top | estreias | eps | ano | genero
    return (r) => paginaNoflixCatalogo(r, { tipo: "serie", titulo: "Séries", modoInicial: modo });
  }
  if (p[0] === "noflix" && p[1] === "filme" && p[2])
    return (r) => paginaNoflixFilme(r, { idtmdb: decodeURIComponent(p[2]) });
  if (p[0] === "noflix" && p[1] === "serie" && p[2])
    return (r) => paginaNoflixSerie(r, { idtmdb: decodeURIComponent(p[2]) });
  if (p[0] === "canais" || p[0] === "canal") return (r) => { location.hash = "#/"; return Promise.resolve(); };
  if (p[0] === "evento" && p[1]) return (r) => paginaEvento(r, { id: decodeURIComponent(p[1]) });
  if (p[0] === "config") return (r) => paginaConfiguracoes(r);


  return (r) => {
    r.append(el("p", { class: "center" }, "Página não encontrada."));
    return null;
  };
}

async function navegar() {
  const rota = location.hash || "#/";
  limparPlayer();
  if (atual && atual.destruir) atual.destruir();
  // Mantém o fundo do app (sem tela cinza/corte seco)
  app.classList.add("page-switching");
  app.innerHTML = "";
  window.scrollTo(0, 0);
  marcarNav(rota.replace(/^#/, ""));
  document.title = tituloDaRota(rota);
  try {
    atual = (await resolver(rota)(app)) || null;
  } finally {
    requestAnimationFrame(() => app.classList.remove("page-switching"));
  }
}

function tituloDaRota(hash) {
  const caminho = hash.replace(/^#\//, "").split("?")[0];
  const p = caminho.split("/").filter(Boolean);
  if (!p.length) return "TEDFLIX — Filmes e séries online";
  const mapa = {
    filmes: "Filmes",
    series: "Séries",
    categorias: "Categorias",
    agenda: "Agenda de episódios",
    canais: "Canais ao vivo",
    tedtop: "Explorar TEDTOP",
    canal: "Canal ao vivo",
    evento: "Evento ao vivo",
    busca: "Buscar",
    favoritos: "Minha lista",
    favorito: "Favorito",
    titulo: "Detalhes",
    assistir: "Assistir",
  };
  return `${mapa[p[0]] || "TEDFLIX"} — TEDFLIX`;
}

window.addEventListener("hashchange", navegar);
navegar();


/* ---------- puxar para atualizar o catálogo ---------- */
(function setupPullToRefresh() {
  let startY = 0;
  let pulling = false;
  let refreshing = false;
  const limiar = 70;

  function rotaCatalogo() {
    const h = (location.hash || "#/").replace(/^#/, "") || "/";
    const base = h.split("?")[0].split("/").filter(Boolean)[0] || "";
    // Home e listas de catálogo
    return !base || ["", "filmes", "series", "lancamentos", "categorias", "categoria", "agenda"].includes(base);
  }

  function mostrarToast(msg) {
    let t = document.getElementById("ptr-toast");
    if (!t) {
      t = document.createElement("div");
      t.id = "ptr-toast";
      t.className = "ptr-toast";
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add("on");
    clearTimeout(t._hide);
    t._hide = setTimeout(() => t.classList.remove("on"), 1800);
  }

  async function atualizarCatalogo() {
    if (refreshing) return;
    refreshing = true;
    mostrarToast("Atualizando catálogo…");
    try {
      limparCacheCatalogo();
      // Re-dispara a rota atual (ou home) para buscar dados novos
      const atual = location.hash || "#/";
      const alvo = (!atual || atual === "#" || atual === "#/_refresh") ? "#/" : atual;
      if (location.hash === "#/_ptr") {
        location.hash = alvo;
      } else {
        location.hash = "#/_ptr";
        await new Promise((r) => requestAnimationFrame(r));
        location.hash = alvo === "#/_ptr" ? "#/" : alvo;
      }
      mostrarToast("Catálogo atualizado");
    } catch (_) {
      mostrarToast("Falha ao atualizar");
    } finally {
      setTimeout(() => { refreshing = false; }, 800);
    }
  }

  document.addEventListener(
    "touchstart",
    (e) => {
      if (refreshing) return;
      if (window.scrollY > 4) return;
      if (!rotaCatalogo()) return;
      startY = e.touches[0].clientY;
      pulling = true;
    },
    { passive: true },
  );

  document.addEventListener(
    "touchmove",
    (e) => {
      if (!pulling || refreshing) return;
      const dy = e.touches[0].clientY - startY;
      if (dy > 24 && window.scrollY <= 4) {
        document.body.classList.add("ptr-pulling");
      }
    },
    { passive: true },
  );

  document.addEventListener(
    "touchend",
    (e) => {
      if (!pulling) return;
      pulling = false;
      document.body.classList.remove("ptr-pulling");
      const dy = (e.changedTouches[0]?.clientY || 0) - startY;
      if (dy > limiar && window.scrollY <= 4 && rotaCatalogo()) {
        atualizarCatalogo();
      }
    },
    { passive: true },
  );
})();
