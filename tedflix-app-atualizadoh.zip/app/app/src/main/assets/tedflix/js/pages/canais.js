import { el, svgIcone, debounce } from "../dom.js";
import {
  getCanais,
  getCanalCategorias,
  getEventosAoVivo,
  getEventos,
  getCanal,
  buscarCanais,
  limparCacheCatalogo,
} from "../api.js";

function imagem(src, alt) {
  const img = el("img", { alt: alt || "", loading: "lazy", decoding: "async" });
  if (src) {
    img.src = src;
    img.addEventListener("load", () => img.classList.add("on"), { once: true });
    img.addEventListener("error", () => {
      img.style.opacity = "0.15";
    }, { once: true });
  }
  return img;
}

function programaAtual(item) {
  return item?.epg?.current?.title || item?.descricao || "Transmissão ao vivo";
}

function abrirAoVivo(item) {
  const embeds = Array.isArray(item.embeds) ? item.embeds : [];
  if (!embeds.length) return false;
  const payload = JSON.stringify(embeds);
  if (window.AndroidPlayer?.openLivePlayer) {
    window.AndroidPlayer.openLivePlayer(
      item.id,
      item.titulo,
      item.logo,
      payload,
      programaAtual(item),
      item.categoria || "",
    );
    return true;
  }
  return false;
}

function badgeTexto(item) {
  if (item.tipo === "evento") {
    if (item.status === "live") return "AO VIVO";
    if (item.status === "upcoming") return "EM BREVE";
    return (item.status || "EVENTO").toUpperCase();
  }
  return "AO VIVO";
}

function cardCanal(item) {
  const isEvento = item.tipo === "evento";
  const href = isEvento
    ? `#/evento/${encodeURIComponent(item.id)}`
    : `#/canal/${encodeURIComponent(item.id)}`;
  const card = el("a", { class: "live-card", href, "aria-label": `Assistir ${item.titulo}` });
  card.append(
    el("div", { class: "live-thumb" }, [
      imagem(item.logo, item.titulo),
      el("span", { class: "live-badge", html: `${svgIcone("play")} ${badgeTexto(item)}` }),
    ]),
    el("div", { class: "live-card-body" }, [
      el("strong", {}, item.titulo),
      el("span", { class: "live-meta" }, programaAtual(item)),
      el("span", { class: "live-provider" }, `${item.embeds?.length || 0} servidor(es)`),
    ]),
  );
  card.addEventListener("click", (event) => {
    if (abrirAoVivo(item)) event.preventDefault();
  });
  return card;
}

function destaque(item) {
  const card = el("a", { class: "live-feature", href: `#/canal/${encodeURIComponent(item.id)}` });
  card.append(
    el("div", { class: "live-feature-art" }, [
      imagem(item.logo, item.titulo),
      el("div", { class: "live-feature-veil" }),
      el("div", { class: "live-feature-copy" }, [
        el("span", { class: "live-badge live-badge-large", html: `${svgIcone("play")} AO VIVO` }),
        el("h2", {}, item.titulo),
        el("p", {}, programaAtual(item)),
      ]),
    ]),
  );
  card.addEventListener("click", (event) => {
    if (abrirAoVivo(item)) event.preventDefault();
  });
  return card;
}

function estado(texto, erro = false) {
  return el("div", { class: `center live-state${erro ? " is-error" : ""}` }, [
    !erro && el("div", { class: "spinner" }),
    el("p", {}, texto),
  ]);
}

export default async function paginaCanais(raiz) {
  const page = el("div", { class: "page live-page" });
  page.append(el("h1", { class: "page-title" }, "Canais ao vivo"));
  page.append(
    el("p", { class: "sub pad", style: "padding-top:0" }, "Rei dos Canais · lista atualizada da API"),
  );

  const busca = el("input", {
    class: "input",
    type: "search",
    placeholder: "Buscar canal ou evento…",
    style: "margin:0 16px 10px;width:calc(100% - 32px)",
  });
  const chips = el("div", {
    class: "pad",
    style: "display:flex;flex-wrap:wrap;gap:8px;padding-top:0",
  });
  const area = el("div", { class: "live-area" });
  area.append(estado("Carregando canais…"));
  page.append(busca, chips, area);
  raiz.append(page);

  let categorias = [];
  let categoriaAtual = "";
  let listaBase = [];

  function renderLista(itens) {
    area.replaceChildren();
    if (!itens.length) {
      area.append(estado("Nenhum canal encontrado.", true));
      return;
    }
    const comEmbed = itens.filter((i) => (i.embeds || []).length > 0);
    const destaqueItem = comEmbed[0] || itens[0];
    if (destaqueItem) area.append(destaque(destaqueItem));
    const grid = el("div", { class: "live-grid pad" });
    itens.forEach((item) => grid.append(cardCanal(item)));
    area.append(grid);
    area.append(
      el("p", { class: "sub pad" }, `${itens.length} canal(is) · API Rei dos Canais`),
    );
  }

  async function carregar(cat = "") {
    categoriaAtual = cat;
    area.replaceChildren(estado("Carregando canais…"));
    try {
      const [canais, eventos] = await Promise.all([
        getCanais(cat || ""),
        cat ? Promise.resolve([]) : getEventosAoVivo().catch(() => []),
      ]);
      listaBase = [...(eventos || []), ...(canais || [])];
      renderLista(listaBase);
    } catch (error) {
      area.replaceChildren(
        estado(error?.message || "Não foi possível carregar os canais.", true),
        el(
          "button",
          {
            class: "btn primary",
            type: "button",
            style: "margin:12px auto;display:block",
            onclick: () => {
              try {
                limparCacheCatalogo();
              } catch (_) {}
              carregar(categoriaAtual);
            },
          },
          "Tentar de novo",
        ),
      );
    }
  }

  try {
    categorias = await getCanalCategorias();
  } catch (_) {
    categorias = [];
  }

  const allBtn = el(
    "button",
    { class: "chip active", type: "button", "data-cat": "" },
    "Todos",
  );
  allBtn.addEventListener("click", () => {
    [...chips.children].forEach((b) => b.classList.remove("active"));
    allBtn.classList.add("active");
    carregar("");
  });
  chips.append(allBtn);
  categorias.forEach((c) => {
    const btn = el("button", { class: "chip", type: "button", "data-cat": c.nome }, c.nome);
    btn.addEventListener("click", () => {
      [...chips.children].forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      carregar(c.nome);
    });
    chips.append(btn);
  });

  const onBusca = debounce(async (termo) => {
    const q = String(termo || "").trim();
    if (!q) {
      renderLista(listaBase);
      return;
    }
    area.replaceChildren(estado("Buscando…"));
    try {
      const r = await buscarCanais(q);
      renderLista(r);
    } catch (_) {
      area.replaceChildren(estado("Falha na busca.", true));
    }
  }, 350);
  busca.addEventListener("input", () => onBusca(busca.value));

  await carregar("");
  return page;
}

export async function paginaCanal(raiz, { id }) {
  const page = el("div", { class: "page live-page" });
  raiz.append(page);
  page.append(estado("Carregando canal…"));
  try {
    const item = await getCanal(id);
    if (!item?.id) throw new Error("Canal não encontrado.");
    page.innerHTML = "";
    page.append(
      el("a", { class: "back", href: "#/canais", "aria-label": "Voltar", html: svgIcone("back") }),
      el("div", { class: "live-detail-art" }, [
        imagem(item.logo, item.titulo),
        el("div", { class: "live-detail-veil" }),
      ]),
      el("div", { class: "live-detail-body" }, [
        el("span", { class: "live-badge", html: `${svgIcone("play")} AO VIVO` }),
        el("h1", {}, item.titulo),
        el("p", { class: "sub" }, programaAtual(item)),
        el("p", { class: "desc" }, item.descricao || ""),
        el(
          "button",
          { class: "btn primary live-start", html: `${svgIcone("play")} Abrir transmissão` },
        ),
      ]),
    );
    page.querySelector(".live-start").addEventListener("click", () => {
      if (!abrirAoVivo(item)) {
        page.append(estado("Este canal não possui servidor disponível no momento.", true));
      }
    });
  } catch (error) {
    page.replaceChildren(
      estado(error.message || "Não foi possível abrir o canal.", true),
      el("a", { class: "btn ghost", href: "#/canais" }, "Voltar aos canais"),
    );
  }
  return page;
}

export async function paginaEvento(raiz, { id }) {
  const page = el("div", { class: "page live-page" });
  raiz.append(page);
  page.append(estado("Carregando evento…"));
  try {
    let item = null;
    try {
      const todos = await getEventos("");
      item = (todos || []).find((e) => e.id === id) || null;
    } catch (_) {}
    if (!item) {
      const live = await getEventosAoVivo();
      item = (live || []).find((e) => e.id === id) || null;
    }
    if (!item) throw new Error("Evento não encontrado neste momento.");
    page.innerHTML = "";
    page.append(
      el("a", { class: "back", href: "#/canais", "aria-label": "Voltar", html: svgIcone("back") }),
      el("div", { class: "live-detail-art" }, [
        imagem(item.logo, item.titulo),
        el("div", { class: "live-detail-veil" }),
      ]),
      el("div", { class: "live-detail-body" }, [
        el("span", { class: "live-badge", html: `${svgIcone("play")} ${badgeTexto(item)}` }),
        el("h1", {}, item.titulo),
        el("p", { class: "sub" }, item.categoria),
        el("p", { class: "desc" }, item.descricao || ""),
        el(
          "button",
          { class: "btn primary live-start", html: `${svgIcone("play")} Abrir transmissão` },
        ),
      ]),
    );
    page.querySelector(".live-start").addEventListener("click", () => {
      if (!abrirAoVivo(item)) {
        page.append(estado("Abra este evento no app para iniciar a transmissão.", true));
      }
    });
  } catch (error) {
    page.replaceChildren(
      estado(error.message || "Não foi possível abrir o evento.", true),
      el("a", { class: "btn ghost", href: "#/canais" }, "Voltar aos canais"),
    );
  }
  return page;
}
