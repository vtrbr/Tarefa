# TEDFLIX — Relatório de Integração das 3 APIs

Data: 2026-10-05  
Repositório base: `https://github.com/vtrbr/App`

---

## 1. Arquitetura final

```
TEDFLIX APP (Android WebView + Kotlin)
        |
   +----+----+----+
   |         |    |
CONTENT    USER   TEDTOP
(auth-1)  (auth)  (apply2)
```

| Serviço | URL | Responsabilidade |
|---------|-----|------------------|
| CONTENT | `https://servidores-ted-auth-1.onrender.com/api` | Catálogo, home, filmes, séries, episódios, busca, player HLS |
| USER | `https://servidores-ted-auth.onrender.com` | Login, perfis, favoritos, progresso, histórico, assinatura |
| TEDTOP | `https://servidores-ted-apply2.onrender.com` | Trailers YouTube, ingresso/player direto, radar, bilheteria |

---

## 2. O que foi corrigido / implementado

### Configuração
- `config.js`: centralizadas as 3 URLs oficiais (`CONTENT_API_BASE`, `USER_API_BASE`, `TEDTOP_API_BASE`)
- Alias `API_BASE` mantido para compatibilidade com código legado

### API layer (`api.js`)
- Import de `TEDTOP_API_BASE`
- Funções TEDTOP:
  - `getTedtopFilme(slug)`
  - `getTedtopIngresso(slug)` — TTL curto (link expira)
  - `getTedtopTelao`, `getTedtopRadar`, `getTedtopBilheteria`
  - `extrairYoutubeId(url)` — vários formatos de URL YouTube
- Rotas de séries corrigidas:
  - `/series/serie/:cat/:slug/temporadas`
  - `/series/serie/:cat/:slug/temporada/:n/episodios`
- Endpoint home corrigido: `/home/ultimos-filmes`

### Tela de detalhes (`detalhes.js`)
- Carrega CONTENT + TEDTOP em paralelo (`Promise.all`)
- Player de trailer YouTube embutido (iframe responsivo 16:9)
- Se trailer ausente/inválido → seção omitida (não quebra a tela)
- Favoritos: matching por `filmeId` **ou** `slug+categoria` (evita “título não encontrado”)

### Identidade de conteúdo (`identity.js` — novo)
- `getContentKey(item)` — chave estável `source:type:category:slug[:episode]`
- `mesmoConteudo(a, b)`
- `mergeConteudo({ content, user, tedtop })` — merge sem sobrescrever com null

### README
- Documenta as 3 APIs e regras de orquestração

---

## 3. Autenticação (já existente no Kotlin)

- `AuthSession.kt` usa USER API (`servidores-ted-auth.onrender.com`)
- Token: Firebase ID Token, cifrado com Android Keystore (AES-GCM)
- Header: `Authorization: Bearer <token>`
- Fluxo: login → perfis → select → access → catálogo
- Favoritos / progresso / histórico via bridge `window.AndroidPlayer`

---

## 4. Player

- Android: `PlayerActivity` (Media3/ExoPlayer) para HLS do CONTENT
- Web: player JS em `components/player.js`
- TEDTOP `direct_url` disponível via `getTedtopIngresso(slug)` — renovar quando expirar

---

## 5. Cache

- Catálogo: memória + localStorage (`tedflix:catalog-cache:v2:`)
- Preferências: `tedflix:prefs`
- Dados de usuário (favoritos/progresso): via Kotlin + isolados por profileId no AuthSession
- Cache TEDTOP: TTL curto para ingresso; longo para detalhes de filme

---

## 6. Endpoints em uso

### CONTENT
- `GET /home/carousel`, `/home/agenda`, `/home/lancamentos`, `/home/ultimos-filmes`
- `GET /filmes/stream`, `/filmes/filme/:cat/:slug`, `/filmes/filme-player/:cat/:slug`
- `GET /series/stream`, `/series/serie/:cat/:slug/temporadas`, `.../temporada/:n/episodios`
- `GET /animacoes/stream`, `/genero/:slug/stream`
- `GET /buscar/:query`

### USER
- `POST /api/auth/register`, `/api/auth/login`, `/api/auth/refresh`
- `GET /api/auth/me`, `/api/profiles`, `/api/subscription`
- `POST /api/profiles/:id/select`, `/api/profiles/:id/favorites/toggle`
- `GET /api/profiles/:id/favorites`, `/progress`, `/history`
- `PUT /api/profiles/:id/progress`

### TEDTOP
- `GET /filme/:slug` (trailer)
- `GET /ingresso/:slug` (direct_url)
- `GET /telao`, `/bilheteria`, `/radar/live/:termo`

---

## 7. Arquivos principais alterados

| Arquivo | Mudança |
|---------|---------|
| `js/config.js` | 3 bases oficiais |
| `js/api.js` | TEDTOP + rotas séries + ultimos-filmes |
| `js/pages/detalhes.js` | Trailer YouTube + favorito por slug |
| `js/identity.js` | **Novo** — identidade e merge |
| `README.md` | Documentação das 3 APIs |
| `INTEGRATION_REPORT.md` | Este relatório |

---

## 8. O que ainda depende de teste no aparelho

1. Login real com conta Firebase do USER server
2. Toggle de favorito e persistência após restart
3. Salvamento e retomada de progresso no PlayerActivity
4. Troca de perfil (isolamento de cache)
5. Expiração e refresh do `direct_url` TEDTOP no player nativo
6. Séries com múltiplas temporadas/episódios no fluxo completo
7. Build `assembleDebug` / `assembleRelease`

---

## 9. Como validar localmente (web assets)

```bash
cd app/src/main/assets/tedflix
python3 -m http.server 4173
# abrir http://localhost:4173
```

Probe TEDTOP:
```bash
curl https://servidores-ted-apply2.onrender.com/filme/o-fim-da-rua
```

---

## 10. Princípio respeitado

CONTENT ≠ USER ≠ TEDTOP.  
O frontend orquestra. Não há mock, endpoint inventado nem união artificial dos servidores.


---

## 11. Smoke test das APIs (2026-10-05)

| Endpoint | Status |
|----------|--------|
| CONTENT home/carousel | 200 |
| CONTENT home/lancamentos | 200 |
| CONTENT home/ultimos-filmes | 200 |
| CONTENT filmes/stream | 200 |
| CONTENT series/stream | 200 |
| CONTENT genero/acao/stream | 200 |
| CONTENT buscar/matrix | 200 |
| USER auth/me (sem token) | 401 (esperado) |
| USER profiles (sem token) | 401 (esperado) |
| TEDTOP telao | 200 |
| TEDTOP filme (trailer) | 200 |
| TEDTOP ingresso (direct_url) | 200 |
| TEDTOP bilheteria | 200 |

Script: `scripts/api-smoke-test.sh`

## 12. Atualizações Kotlin (nativo)

- `AuthSession`: constantes `TEDTOP_API_BASE` / `TEDTOP_API_HOST`
- `AuthSession.getTedtopIngresso(slug)` e `getTedtopFilme(slug)`
- `PlayerActivity`: fallback automático para `direct_url` TEDTOP se o HLS do CONTENT falhar (uma tentativa; link não é persistido)
- `ContinueWatchingStore`: já isolado por `profileId` (confirmado)

## 13. Legado removido / ausente

Confirmado em `AuthSession.kt`:
- sem `x-access-token`
- sem `/validar`
- sem URLs antigas (`authted`, `tedtv`, `cryptitys`)
- Bearer Token via Keystore



## 14. Fechamento de sessão (código)

### Corrigido / implementado nesta rodada
- `resolveCatalogItem`: busca no CONTENT sem exigir Bearer; matching por id/slug/título/link
- `saveProgress`: envia categoria, slug, tipo, serieCategoria, serieSlug
- `getTitulo` (séries): mais robusto, não quebra se busca falhar
- Imagens protocol-relative normalizadas
- TEDTOP fallback no PlayerActivity
- AuthSession TEDTOP methods
- identity.js, trailer YouTube, 3 bases oficiais

### Já existente e validado no código
- Login/register email+senha (sem código de acesso)
- Bearer + Keystore
- Perfis + select + access
- Favoritos via bridge
- Continue watching isolado por profileId
- Player HLS CONTENT + progresso remoto

### Limitação do ambiente de build
- Não há Android SDK/emulador aqui para `assembleDebug` nem login Firebase real
- Validação de APIs públicas: smoke test 13/13 OK
- Fluxos autenticados exigem conta real no aparelho

### Como aplicar
1. Extrair o ZIP sobre o projeto (ou copiar arquivos alterados)
2. Manter `res/drawable-nodpi` e assets de imagem do repo original
3. Sync Gradle → Run no device
4. Testar: login → perfil → home → detalhe (trailer) → favorito → assistir → progresso → troca perfil → logout
