import { el, limpar } from "../dom.js";
import { cardTitulo, skeletonCard } from "../components/card.js";
import { buscar, parseLink, rotaDetalhe } from "../api.js";

/** Detecta episódio NoFlix a partir do filmeId salvo (ex: 58566-t1e77). */
function parseNoflixEpId(filmeId) {
  const s = String(filmeId || "").trim();
  let m = s.match(/^(\d+)-t(\d+)e(\d+)$/i);
  if (m) return { idtmdb: m[1], temp: m[2], ep: m[3] };
  m = s.match(/^serie-(\d+)-(\d+)-(\d+)(?:-(dub|leg))?$/i);
  if (m) return { idtmdb: m[1], temp: m[2], ep: m[3], audio: m[4] || "dub" };
  return null;
}

/** Monta rota de detalhe/info a partir do item de favorito. */
function rotaFavorito(item) {
  const filmeId = String(item.filmeId || item.id || "").trim();
  const titulo = String(item.titulo || "").trim();
  const tipo = String(item.tipo || item.contentType || "").toLowerCase();
  let categoria = String(item.categoria || "").trim();
  let slug = String(item.slug || "").trim();
  const imagem = String(item.thumb || item.imagem || "").trim();

  // 1) Episódio NoFlix (id salvo no toggle)
  const nf = parseNoflixEpId(filmeId) || parseNoflixEpId(slug);
  if (nf || tipo === "episodio" || tipo === "episode") {
    if (nf) {
      return `#/episodio/noflix/${nf.idtmdb}/${nf.temp}/${nf.ep}?audio=${nf.audio || "dub"}`;
    }
    if (categoria && slug) {
      const q = new URLSearchParams({
        t: String(item.temporada || 1),
        e: String(item.episodio || 1),
        serieCategoria: item.serieCategoria || categoria,
        serieSlug: item.serieSlug || "",
        filmeId,
        thumb: imagem,
        titulo,
      });
      return `#/episodio/${encodeURIComponent(categoria)}/${encodeURIComponent(slug)}?${q}`;
    }
  }

  // 2) NoFlix filme/série por idtmdb numérico
  if (/^\d+$/.test(filmeId) && (tipo.includes("serie") || tipo.includes("séri") || tipo === "tv")) {
    return `#/noflix/serie/${filmeId}`;
  }
  if (/^\d+$/.test(filmeId) && (tipo.includes("filme") || tipo.includes("movie") || tipo === "noflix")) {
    // série noflix às vezes salva só o id — se título tem TxEy, trata como série
    if (/t\d+e\d+/i.test(titulo) || /s\d+e\d+/i.test(titulo)) {
      const m = titulo.match(/t(\d+)\s*e(\d+)/i) || titulo.match(/s(\d+)\s*e(\d+)/i);
      if (m) return `#/episodio/noflix/${filmeId}/${m[1]}/${m[2]}?audio=dub`;
      return `#/noflix/serie/${filmeId}`;
    }
    return `#/noflix/filme/${filmeId}`;
  }

  // 3) CONTENT com categoria/slug
  if (categoria && slug) {
    const isSerie = tipo.includes("serie") || tipo.includes("séri") || tipo.includes("tv");
    return `#/titulo/${isSerie ? "serie" : "filme"}/${encodeURIComponent(categoria)}/${encodeURIComponent(slug)}`;
  }

  // 4) Fallback: rotaDetalhe genérica
  return rotaDetalhe({
    ...item,
    filmeId,
    titulo,
    imagem,
    categoria,
    slug,
    tipo: tipo || "Filme",
    link_detalhe: undefined,
    link_assistir: undefined,
  });
}

/**
 * Favoritos como seção do app (SPA) — não abre Activity nativa.
 */
export default async function paginaFavoritos(raiz) {
  const page = el("div", { class: "page page-favoritos" });
  page.append(
    el("h1", { class: "page-title pad" }, "Minha lista"),
    el("p", { class: "sub pad", style: "padding-top:0" }, "Títulos que você marcou como favorito"),
  );
  const grid = el("div", { class: "grid pad", style: "margin-top:12px" });
  for (let i = 0; i < 6; i++) grid.append(skeletonCard());
  page.append(grid);
  raiz.append(page);

  try {
    if (!window.AndroidPlayer?.getFavorites) {
      limpar(grid);
      grid.append(el("p", { class: "sub" }, "Favoritos disponíveis apenas no app."));
      return page;
    }
    const raw = JSON.parse(window.AndroidPlayer.getFavorites() || "{}");
    const lista = Array.isArray(raw.favoritos) ? raw.favoritos : Array.isArray(raw) ? raw : [];
    if (!lista.length) {
      limpar(grid);
      grid.append(
        el("div", { class: "empty-state" }, [
          el("p", { class: "sub" }, "Sua lista está vazia."),
          el("a", { class: "btn primary", href: "#/" }, "Explorar catálogo"),
        ]),
      );
      return page;
    }

    const cards = await Promise.all(
      lista.map(async (item) => {
        const titulo = String(item.titulo || "").trim();
        const filmeId = String(item.filmeId || item.id || "").trim();
        let categoria = String(item.categoria || "").trim();
        let slug = String(item.slug || "").trim();
        let imagem = String(item.thumb || item.imagem || "").trim();
        let tipo = String(item.tipo || item.contentType || "Filme");

        // Completa categoria/slug via busca só se ainda faltar e não for ep NoFlix
        const nf = parseNoflixEpId(filmeId) || parseNoflixEpId(slug);
        if ((!categoria || !slug) && !nf && (titulo || filmeId)) {
          try {
            const busca = await buscar(titulo || filmeId);
            const resultados = Array.isArray(busca?.resultados) ? busca.resultados : [];
            const hit =
              resultados.find((r) => {
                const id = String(r.filmeId || r.id || "").trim();
                return (filmeId && id === filmeId) ||
                  (titulo && String(r.titulo || "").toLowerCase() === titulo.toLowerCase());
              }) || resultados[0];
            if (hit) {
              const p = parseLink(hit.link_assistir);
              if (!categoria) categoria = hit.categoria || p.categoria || "";
              if (!slug) slug = hit.slug || p.slug || "";
              if (!imagem) imagem = hit.imagem || hit.capa || hit.thumb || "";
              if (!tipo || tipo === "Filme") tipo = hit.tipo || tipo;
            }
          } catch (_) {}
        }

        const base = {
          titulo,
          filmeId,
          categoria,
          slug,
          imagem,
          thumb: imagem,
          tipo,
          contentType: tipo,
          temporada: item.temporada,
          episodio: item.episodio,
          serieCategoria: item.serieCategoria,
          serieSlug: item.serieSlug,
          isEpisode: Boolean(nf) || /episodio|episode/i.test(tipo),
        };
        const href = rotaFavorito(base);
        return {
          ...base,
          link_detalhe: href,
          link_assistir: href,
        };
      }),
    );

    // Progresso (continuar assistindo)
    let progressoMap = {};
    const pctDe = (item) => {
      let p = Number(item.percent ?? item.progresso ?? 0);
      if (p > 0) return Math.min(99, Math.round(p));
      let pos = Number(item.positionMs || 0);
      let dur = Number(item.durationMs || 0);
      if ((!pos || !dur) && (item.positionSeconds || item.durationSeconds)) {
        pos = Number(item.positionSeconds || 0) * 1000;
        dur = Number(item.durationSeconds || 0) * 1000;
      }
      if (pos > 0 && dur > 0) return Math.min(99, Math.max(1, Math.round((pos * 100) / dur)));
      return 0;
    };
    try {
      const cw = JSON.parse(window.AndroidPlayer?.getContinueWatching?.() || "[]");
      (Array.isArray(cw) ? cw : []).forEach((item) => {
        const key = `${item.categoria || ""}:${item.slug || item.filmeId || ""}`.toLowerCase();
        const key2 = String(item.filmeId || "").toLowerCase();
        const key3 = String(item.slug || "").toLowerCase();
        const key4 = String(item.titulo || "").trim().toLowerCase();
        const percent = pctDe(item);
        if (percent > 0) {
          if (key) progressoMap[key] = percent;
          if (key2) progressoMap[key2] = percent;
          if (key3) progressoMap[key3] = percent;
          if (key4) progressoMap[key4] = percent;
        }
      });
    } catch (_) {}

    cards.forEach((c) => {
      const k1 = `${c.categoria || ""}:${c.slug || c.filmeId || ""}`.toLowerCase();
      const k2 = String(c.filmeId || "").toLowerCase();
      const k3 = String(c.slug || "").toLowerCase();
      const k4 = String(c.titulo || "").trim().toLowerCase();
      const p = progressoMap[k1] || progressoMap[k2] || progressoMap[k3] || progressoMap[k4] || 0;
      if (p > 0) {
        c.progresso = p;
        c.continuarTexto = `${p}% assistido`;
      }
    });

    limpar(grid);
    const frag = document.createDocumentFragment();
    cards.forEach((c) => frag.append(cardTitulo(c, { size: "md", eager: true })));
    grid.append(frag);
  } catch (e) {
    limpar(grid);
    grid.append(el("p", { class: "sub" }, "Não foi possível carregar os favoritos."));
  }

  return page;
}
