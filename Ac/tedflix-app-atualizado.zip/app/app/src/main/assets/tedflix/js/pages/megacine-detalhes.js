import { el, limpar } from "../dom.js";
import {
  getMegacineDossier,
  enriquecerComTmdb,
} from "../api.js";
import { poster, backdrop } from "../img.js";
import { lerFavorito, toggleFavorito, abrirPlayerNativo, lerProgresso } from "../playback.js";

function botaoVoltar() {
  // Seta agora fica na topbar (no lugar da logo) — não renderiza no conteúdo
  return el("span", { class: "detail-back", "aria-hidden": "true", hidden: true });
}

function playMegacineNativo({ tipo, slug, titulo, thumb, filmeId, episodeId, temp, ep }) {
  // Preferir serie-slug-T-E (estável). ep-{id} só se não tiver temporada/ep.
  let nativeSlug = `${tipo}-${slug}`;
  if (tipo === "serie" && temp != null && ep != null) {
    nativeSlug = `serie-${slug}-${temp}-${ep}`;
  } else if (episodeId) {
    nativeSlug = `ep-${episodeId}`;
  }
  return abrirPlayerNativo({
    categoria: "megacine",
    slug: nativeSlug,
    titulo: titulo || slug,
    filmeId: filmeId || `cine-${tipo}-${slug}`,
    thumb: thumb || "",
    tipo: episodeId || (temp != null && ep != null) ? "episodio" : tipo,
    serieSlug: tipo === "serie" ? slug : "",
    serieCategoria: "megacine",
  });
}

export default async function paginaMegacineDetalhe(raiz, { tipo = "filme", slug = "" } = {}) {
  const page = el("div", { class: "page page-detail" });
  raiz.append(page);
  page.append(el("div", { class: "center" }, [el("div", { class: "spinner" })]));

  const t = String(tipo || "filme").toLowerCase().includes("serie") ? "serie" : "filme";
  const s = decodeURIComponent(String(slug || "").trim());
  if (!s) {
    limpar(page);
    page.append(el("p", { class: "center" }, "Título inválido."));
    return page;
  }

  let dados;
  try {
    dados = await getMegacineDossier(t, s);
  } catch (e) {
    limpar(page);
    page.append(el("p", { class: "center" }, "Não foi possível carregar este título."));
    return page;
  }
  if (!dados) {
    limpar(page);
    page.append(el("p", { class: "center" }, "Título não encontrado."));
    return page;
  }

  if (!dados.capa && !dados.imagem) {
    try {
      const enr = await enriquecerComTmdb(
        {
          titulo: dados.titulo || s,
          nome: dados.titulo || s,
          tipo: t === "serie" ? "serie" : "filme",
          ano: dados.ano,
        },
        t === "serie" ? "serie" : "filme",
      );
      if (enr) {
        if (enr.capa || enr.poster || enr.imagem) dados.capa = enr.capa || enr.poster || enr.imagem;
        if (enr.banner || enr.backdrop) dados.banner = enr.banner || enr.backdrop;
        if (enr.sinopse && !dados.sinopse) dados.sinopse = enr.sinopse;
        if (enr.nota != null && dados.nota == null) dados.nota = enr.nota;
      }
    } catch (_) {}
  }

  limpar(page);
const capa = dados.capa || dados.imagem || "";
  const filmeId = `cine-${t}-${s}`;
  let favorito = lerFavorito(filmeId, s, "megacine");

  const btnFav = el("button", {
    type: "button",
    class: `btn ghost${favorito ? " on" : ""}`,
  }, favorito ? "♥ Na lista" : "♡ Favorito");

  btnFav.addEventListener("click", () => {
    const r = toggleFavorito(
      filmeId,
      dados.titulo || "Tedflix",
      capa,
      t === "serie" ? "series" : "movie",
    );
    if (r && r.success !== false) {
      favorito = typeof r.favorito === "boolean" ? r.favorito : !favorito;
      btnFav.textContent = favorito ? "♥ Na lista" : "♡ Favorito";
      btnFav.classList.toggle("on", favorito);
    }
  });

  const prog = lerProgresso({ categoria: "megacine", slug: s, filmeId });

  function assistirFilme() {
    const ok = playMegacineNativo({
      tipo: "filme",
      slug: s,
      titulo: dados.titulo || s,
      thumb: capa,
      filmeId,
    });
    if (!ok) alert("Player indisponível.");
  }

  async function assistirEp(ep, tempNum) {
    const episodeId = ep.episode_id || ep.id || "";
    const num = ep.numero != null ? ep.numero : (ep.episode != null ? ep.episode : 1);
    const tituloEp = ep.titulo || `${dados.titulo} · T${tempNum}E${num}`;
    try {
      const ok = playMegacineNativo({
        tipo: "serie",
        slug: s,
        titulo: tituloEp,
        thumb: capa,
        filmeId: episodeId ? `cine-ep-${episodeId}` : filmeId,
        episodeId,
        temp: tempNum,
        ep: num,
      });
      if (!ok) alert("Player indisponível.");
    } catch (_) {
      alert("Falha ao abrir o episódio.");
    }
  }

  const btnPlay = el("button", {
    type: "button",
    class: "btn primary",
    html:
      '<svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M8 5v14l11-7z"/></svg> ' +
      (t === "filme"
        ? prog.percent > 0
          ? `Continuar · ${prog.percent}%`
          : "Assistir"
        : "Episódios abaixo"),
  });
  if (t === "filme") {
    btnPlay.addEventListener("click", assistirFilme);
  } else {
    btnPlay.addEventListener("click", () => {
      const lista = page.querySelector(".cine-eps");
      if (lista) lista.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }

  const gens = Array.isArray(dados.generos)
    ? dados.generos.map((g) => (typeof g === "string" ? g : g.nome || g.slug)).filter(Boolean)
    : [];
  const meta = [
    dados.nota != null ? `★ ${Number(dados.nota).toFixed(1)}` : null,
    t === "serie" ? "Série" : "Filme",
    dados.ano || null,
    dados.total_temporadas ? `${dados.total_temporadas} temp.` : null,
    gens.slice(0, 3).join(" · ") || null,
  ].filter(Boolean);

  const hero = el("div", { class: "detail-hero" }, [
    capa
      ? el("img", {
          src: backdrop(capa, 780) || poster(capa, "lg") || capa,
          alt: dados.titulo || "",
          decoding: "async",
        })
      : null,
    el("div", { class: "veil" }),
  ]);

  page.append(
    hero,
    el("div", { class: "pad detail-body" }, [
      el("h1", { class: "detail-title" }, dados.titulo || s),
      el("p", { class: "sub" }, meta.join(" · ")),
      el("div", { class: "detail-actions", style: "display:flex;gap:10px;flex-wrap:wrap;margin:14px 0" }, [
        btnPlay,
        btnFav,
      ]),
      dados.sinopse || dados.descricao
        ? el("p", { class: "detail-sinopse" }, dados.sinopse || dados.descricao)
        : null,
    ]),
  );

  if (t === "serie") {
    const temporadas = Array.isArray(dados.temporadas) ? dados.temporadas : [];
    const wrap = el("div", { class: "pad cine-eps", style: "padding-top:8px" });
    if (!temporadas.length) {
      wrap.append(el("p", { class: "sub" }, "Episódios ainda não disponíveis para esta série."));
    } else {
      wrap.append(el("h2", { style: "margin:8px 0 12px;font-size:18px" }, "Episódios"));

      const tabs = el("div", { class: "chips", style: "padding:0 0 12px;margin:0" });
      const lista = el("div", { class: "cine-ep-list" });

      function renderTemp(idx) {
        [...tabs.children].forEach((c, i) => c.classList.toggle("on", i === idx));
        limpar(lista);
        const temp = temporadas[idx] || {};
        const numT = temp.numero || idx + 1;
        const eps = Array.isArray(temp.episodios) ? temp.episodios : [];
        if (!eps.length) {
          lista.append(el("p", { class: "sub" }, "Nenhum episódio nesta temporada."));
          return;
        }
        eps.forEach((ep) => {
          const num = ep.numero != null ? ep.numero : (ep.episode != null ? ep.episode : "?");
          const titulo = ep.titulo || `Episódio ${num}`;
          const episodeId = ep.episode_id || ep.id || "";
          const epSlug = episodeId ? `ep-${episodeId}` : `serie-${s}-${numT}-${num}`;
          const progEp = lerProgresso({
            categoria: "megacine",
            slug: epSlug,
            filmeId: episodeId ? `cine-ep-${episodeId}` : "",
          });
          const pct = progEp && progEp.percent > 0 ? progEp.percent : 0;
          const infoKids = [
            el(
              "span",
              {
                style:
                  "font-weight:600;font-size:14px;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis",
              },
              titulo,
            ),
          ];
          if (pct > 0) {
            infoKids.push(
              el(
                "div",
                {
                  style:
                    "margin-top:6px;height:3px;border-radius:2px;background:rgba(255,255,255,.12);overflow:hidden",
                },
                [
                  el("div", {
                    style: `height:100%;width:${Math.min(100, pct)}%;background:#e50914;border-radius:2px`,
                  }),
                ],
              ),
            );
          }
          const epCapa = ep.imagem || ep.thumb || ep.still || ep.capa || capa || "";
          const row = el(
            "button",
            {
              type: "button",
              class: "cine-ep-row",
              style:
                "display:flex;width:100%;align-items:center;gap:12px;padding:12px 4px;background:transparent;border:none;border-bottom:1px solid rgba(255,255,255,.08);color:inherit;text-align:left;cursor:pointer",
            },
            [
              epCapa
                ? el("img", {
                    src: epCapa,
                    alt: "",
                    loading: "lazy",
                    style:
                      "flex:0 0 72px;width:72px;height:42px;object-fit:cover;border-radius:6px;background:rgba(255,255,255,.06)",
                  })
                : el(
                    "span",
                    { style: "flex:0 0 40px;font-weight:800;opacity:.7;font-size:14px" },
                    `E${num}`,
                  ),
              el("div", { style: "flex:1;min-width:0" }, infoKids),
              el("span", {
                style:
                  "flex:0 0 auto;width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.12);display:grid;place-items:center",
                html: '<svg viewBox="0 0 24 24" width="14" height="14"><path fill="currentColor" d="M8 5v14l11-7z"/></svg>',
              }),
            ],
          );
          row.addEventListener("click", () => assistirEp(ep, numT));
          lista.append(row);
        });
      }

      temporadas.forEach((temp, idx) => {
        const num = temp.numero || idx + 1;
        const chip = el(
          "button",
          {
            type: "button",
            class: `chip${idx === 0 ? " on" : ""}`,
            style: "cursor:pointer;border:none",
          },
          `T${num}`,
        );
        chip.addEventListener("click", () => renderTemp(idx));
        tabs.append(chip);
      });

      wrap.append(tabs, lista);
      renderTemp(0);
    }
    page.append(wrap);
  }

  return page;
}
