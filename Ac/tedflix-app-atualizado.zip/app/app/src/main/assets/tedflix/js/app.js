import { el, svgIcone, limpar } from "./dom.js";
import { resolveTituloParaRota, resolveEpisodioPorTitulo } from "./resolve.js";
import { NAV, CATEGORIAS } from "./config.js";
import { getFilmes, getSeries, getGenero, getLancamentos, buscar, buscarNoflix, ehSerie, parseLink, limparCacheCatalogo } from "./api.js";
import paginaInicio from "./pages/home.js";
import { paginaCatalogo } from "./pages/catalogo.js";
import paginaCategorias from "./pages/categorias.js";
import paginaAgenda from "./pages/agenda.js";
import paginaCanais, { paginaCanal, paginaEvento } from "./pages/canais.js";
import paginaBusca from "./pages/busca.js";
import paginaDetalhe from "./pages/detalhes.js";
import paginaAssistir from "./pages/assistir.js";
import paginaConfiguracoes from "./pages/configuracoes.js";
import paginaFavoritos from "./pages/favoritos.js";
import { paginaNoflixFilme, paginaNoflixSerie } from "./pages/noflix-detalhes.js";
import paginaEpisodioInfo from "./pages/episodio-info.js";
import paginaNoflixCatalogo from "./pages/noflix-catalogo.js";
import paginaMegacineDetalhe from "./pages/megacine-detalhes.js";
import paginaTedtopPorAno, {
  paginaTedtopPorLetra,
  paginaTedtopPorGenero,
  paginaTedtopRadar,
  paginaTedtopTelao,
  paginaTedtopBilheteria,
} from "./pages/tedtop-explorar.js";
import { limparPlayer } from "./components/player.js";
import { medirOcioso } from "./net.js";


function getAppRoot() {
  return document.getElementById("app");
}
function getTabbar() {
  return document.getElementById("tabbar");
}
let atual = null;

/* ---------- navegação inferior ---------- */
(function initTabbar() {
  const tabbar = getTabbar();
  if (!tabbar) return;
  try {
    NAV.forEach((n) => {
      const a = el("a", { href: n.href, "data-href": n.href });
      a.innerHTML = `${svgIcone(n.icon)}<span>${n.label}</span>`;
      tabbar.append(a);
    });
  } catch (e) {
    console.error("tabbar", e);
  }
})();

function marcarNav(rota) {
  const semQuery = rota.split("?")[0];
  const base = "#/" + (semQuery.split("/")[1] || "");
  [...tabbar.children].forEach((a) =>
    a.classList.toggle("active", a.dataset.href === (base === "#/" ? "#/" : base)),
  );
}

/* ---------- rotas ---------- */
function resolver(hash) {
  const rota = (hash || "#/").replace(/^#/, "") || "/";
  const [caminho, queryString = ""] = rota.split("?");
  const p = caminho.split("/").filter(Boolean);

  if (!p.length) return (r) => paginaInicio(r);
  // Rotas internas de pull-to-refresh (não renderizam tela)
  if (p[0] === "_ptr" || p[0] === "_refresh") return (r) => paginaInicio(r);
  if (p[0] === "filmes")
    return (r) => paginaNoflixCatalogo(r, { tipo: "filme", titulo: "Filmes" });
  if (p[0] === "lancamentos")
    return (r) => paginaCatalogo(r, { titulo: "Lançamentos", carregar: getLancamentos });
  if (p[0] === "series")
    return (r) => paginaNoflixCatalogo(r, { tipo: "serie", titulo: "Séries" });
  // Catálogo legado Tedflix (sem filtro DUB/LEG)
  if (p[0] === "filmes-ted")
    return (r) => paginaCatalogo(r, { titulo: "Filmes (Tedflix)", carregar: getFilmes });
  if (p[0] === "series-ted")
    return (r) => paginaCatalogo(r, { titulo: "Séries (Tedflix)", carregar: getSeries });
  if (p[0] === "categorias") return (r) => paginaCategorias(r);
  if (p[0] === "categoria" && p[1]) {
    if (p[1] === "lancamentos") return (r) => paginaCatalogo(r, { titulo: "Lançamentos", carregar: getLancamentos });
    const cat = CATEGORIAS.find((c) => c.slug === p[1]);
    return (r) =>
      paginaCatalogo(r, { titulo: cat ? cat.label : p[1], carregar: () => getGenero(p[1]) });
  }
  if (p[0] === "agenda") return (r) => paginaAgenda(r);
  if (p[0] === "busca") return (r) => paginaBusca(r);
  if (p[0] === "favoritos") return (r) => paginaFavoritos(r);
  // Resolve favorito/filme por título (resolve.js)
  if (p[0] === "favorito" && (p[1] === "resolve" || !p[1])) {
    const params = new URLSearchParams(queryString);
    const titulo = params.get("titulo") || "";
    return async (r) => {
      if (!titulo) {
        r.append(el("p", { class: "center" }, "Favorito sem título disponível."));
        return null;
      }
      r.append(el("div", { class: "center" }, [el("div", { class: "spinner" })]));
      try {
        const dest = await resolveTituloParaRota({ titulo });
        if (dest) {
          location.replace(dest);
          return null;
        }
        limpar(r);
        r.append(
          el("div", { class: "pad center" }, [
            el("p", { class: "sub" }, "Não foi possível localizar este título no catálogo."),
            el("a", { class: "btn ghost", href: "#/favoritos" }, "Voltar à lista"),
          ]),
        );
        return null;
      } catch (_) {
        limpar(r);
        r.append(el("p", { class: "center" }, "Não foi possível abrir este favorito agora."));
        return null;
      }
    };
  }

  // Resolve episódio só com título + T/E (resolve.js)
  if (p[0] === "episodio" && p[1] === "resolve") {
    const params = new URLSearchParams(queryString);
    const titulo = params.get("titulo") || "";
    const temp = params.get("t") || "1";
    const ep = params.get("e") || "1";
    return async (r) => {
      r.append(el("div", { class: "center" }, [el("div", { class: "spinner" })]));
      try {
        const dest = await resolveEpisodioPorTitulo({ titulo, temp, ep });
        if (dest) {
          location.replace(dest);
          return null;
        }
        limpar(r);
        r.append(
          el("div", { class: "pad center" }, [
            el("p", { class: "sub" }, `Não encontramos "${titulo}" para abrir o episódio T${temp}E${ep}.`),
            el("a", { class: "btn ghost", href: "#/favoritos" }, "Voltar à lista"),
            el("a", { class: "btn primary", href: `#/busca?q=${encodeURIComponent(titulo)}` }, "Buscar no catálogo"),
          ]),
        );
        return null;
      } catch (_) {
        limpar(r);
        r.append(el("p", { class: "center" }, "Falha ao resolver este episódio."));
        return null;
      }
    };
  }

  if (p[0] === "titulo" && p.length >= 4)
    return (r) => paginaDetalhe(r, { tipo: p[1], categoria: p[2], slug: p[3] });
  // Informações de episódio (antes do player)
  if (p[0] === "episodio" && p[1] === "noflix" && p.length >= 5) {
    const params = new URLSearchParams(queryString);
    return (r) =>
      paginaEpisodioInfo(r, {
        fonte: "noflix",
        idtmdb: decodeURIComponent(p[2]),
        temporada: p[3],
        episodio: p[4],
        audio: params.get("audio") || "dub",
      });
  }
  if (p[0] === "episodio" && p.length >= 3) {
    const params = new URLSearchParams(queryString);
    return (r) =>
      paginaEpisodioInfo(r, {
        fonte: "content",
        categoria: decodeURIComponent(p[1]),
        slug: decodeURIComponent(p[2]),
        temporada: params.get("t") || params.get("temporada") || 1,
        episodio: params.get("e") || params.get("episodio") || 1,
        serieCategoria: params.get("serieCategoria") || "",
        serieSlug: params.get("serieSlug") || "",
        serieTitulo: params.get("titulo") || "",
        filmeId: params.get("filmeId") || "",
        thumb: params.get("thumb") || "",
      });
  }
  if (p[0] === "assistir" && p.length >= 3) {
    const params = new URLSearchParams(queryString);
    const lerLista = (nome) => {
      try {
        const valor = params.get(nome);
        const lista = valor ? JSON.parse(valor) : [];
        return Array.isArray(lista) ? lista : [];
      } catch (_) { return []; }
    };
    const fila = lerLista("fila");
    return (r) => paginaAssistir(r, {
      categoria: p[1],
      slug: p[2],
      fila,
      filmeId: params.get("filmeId") || "",
      thumb: params.get("thumb") || "",
      tipo: params.get("tipo") || "",
      serieCategoria: params.get("serieCategoria") || "",
      serieSlug: params.get("serieSlug") || "",
      episodios: lerLista("episodios"),
      recomendados: lerLista("recomendados"),
    });
  }
  if (p[0] === "tedtop" && p[1] === "telao") return (r) => paginaTedtopTelao(r);
  if (p[0] === "tedtop" && p[1] === "bilheteria") return (r) => paginaTedtopBilheteria(r);
  if (p[0] === "tedtop" && p[1] === "ano")
    return (r) => paginaTedtopPorAno(r, { ano: p[2] || "2026" });
  if (p[0] === "tedtop" && p[1] === "letra")
    return (r) => paginaTedtopPorLetra(r, { letra: p[2] || "A" });
  if (p[0] === "tedtop" && p[1] === "genero")
    return (r) => paginaTedtopPorGenero(r, { genero: p[2] || "acao" });
  if (p[0] === "tedtop" && p[1] === "radar") return (r) => paginaTedtopRadar(r);
  // Catálogo NoFlix (listas extras — não remove Tedflix legado)
  if (p[0] === "noflix" && (p[1] === "filmes" || p[1] === "cinema")) {
    const modo = p[2] || "lista"; // lista | top | ano | genero
    return (r) => paginaNoflixCatalogo(r, { tipo: "filme", titulo: "Filmes", modoInicial: modo });
  }
  if (p[0] === "noflix" && (p[1] === "series" || p[1] === "seriados")) {
    const modo = p[2] || "lista"; // lista | top | estreias | eps | ano | genero
    return (r) => paginaNoflixCatalogo(r, { tipo: "serie", titulo: "Séries", modoInicial: modo });
  }
    // MegaCine
  if (p[0] === "cine" && p[1] === "filme" && p[2])
    return (r) => paginaMegacineDetalhe(r, { tipo: "filme", slug: decodeURIComponent(p[2]) });
  if (p[0] === "cine" && p[1] === "serie" && p[2])
    return (r) => paginaMegacineDetalhe(r, { tipo: "serie", slug: decodeURIComponent(p[2]) });

if (p[0] === "noflix" && p[1] === "filme" && p[2])
    return (r) => paginaNoflixFilme(r, { idtmdb: decodeURIComponent(p[2]) });
  if (p[0] === "noflix" && p[1] === "serie" && p[2])
    return (r) => paginaNoflixSerie(r, { idtmdb: decodeURIComponent(p[2]) });
  if (p[0] === "canais" || p[0] === "canal") return (r) => { location.hash = "#/"; return Promise.resolve(); };
  if (p[0] === "evento" && p[1]) return (r) => paginaEvento(r, { id: decodeURIComponent(p[1]) });
  if (p[0] === "config") return (r) => paginaConfiguracoes(r);


  return (r) => {
    r.append(el("p", { class: "center" }, "Página não encontrada."));
    return null;
  };
}

let _homePageCache = null;
let _homePageCacheAt = 0;
const HOME_PAGE_TTL = 90 * 1000; // 90s — evita home “congelada” com capas quebradas

/** Barra superior contextual: transparente com banner, sólida sem. */

function ensureTopbarBack() {
  let back = document.getElementById("topbar-back");
  if (back) return back;
  const bar = document.getElementById("topbar");
  if (!bar) return null;
  back = document.createElement("button");
  back.type = "button";
  back.className = "icon-btn topbar-back";
  back.id = "topbar-back";
  back.setAttribute("aria-label", "Voltar");
  back.hidden = true;
  back.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>';
  back.addEventListener("click", (e) => {
    e.preventDefault();
    if (window.history.length > 1) history.back();
    else location.hash = "#/";
  });
  const brand = document.getElementById("topbar-brand") || bar.querySelector(".brand");
  if (brand && brand.nextSibling) bar.insertBefore(back, brand.nextSibling);
  else if (brand) brand.after(back);
  else bar.prepend(back);
  return back;
}

function rotaEhDetalhe(rota) {
  const r = rota || location.hash || "#/";
  // Qualquer tela de título / episódio / player web
  if (r.startsWith("#/titulo/")) return true;
  if (r.startsWith("#/noflix/")) return true;
  if (r.startsWith("#/cine/")) return true;
  if (r.startsWith("#/episodio")) return true;
  if (r.startsWith("#/assistir")) return true;
  if (r.startsWith("#/favorito/")) return true;
  return false;
}

function rotaTemBanner(rota) {
  const r = rota || location.hash || "#/";
  if (r === "#/" || r === "#" || r.startsWith("#/_")) return true; // home
  if (r.startsWith("#/busca")) return true;
  // detalhes com hero/banner
  if (r.startsWith("#/titulo/") || r.startsWith("#/noflix/") || r.startsWith("#/cine/")) return true;
  if (r.startsWith("#/episodio/")) return true;
  return false;
}

function atualizarTopbar(rota) {
  const bar = document.getElementById("topbar");
  if (!bar) return;
  const clear = typeof rotaTemBanner === "function" ? rotaTemBanner(rota) : false;
  const detalhe = typeof rotaEhDetalhe === "function" ? rotaEhDetalhe(rota) : false;
  bar.classList.toggle("topbar-clear", clear);
  bar.classList.toggle("topbar-solid", !clear);
  bar.classList.toggle("topbar-detail", detalhe);
  document.body.classList.toggle("topbar-over-banner", clear);
  if (!clear) bar.classList.remove("topbar-scrolled");
  const back = ensureTopbarBack() || document.getElementById("topbar-back");
  const brand = document.getElementById("topbar-brand") || bar.querySelector(".brand");
  if (back) {
    if (detalhe) back.removeAttribute("hidden");
    else back.setAttribute("hidden", "");
  }
  if (brand) {
    brand.style.display = detalhe ? "none" : "";
  }
}

function onAppScroll() {
  const bar = document.getElementById("topbar");
  if (!bar || !bar.classList.contains("topbar-clear")) return;
  const y = window.scrollY || document.documentElement.scrollTop || 0;
  bar.classList.toggle("topbar-scrolled", y > 24);
}

async function navegar() {
  const root = getAppRoot();
  if (!root) {
    console.error("Tedflix: #app não encontrado");
    return;
  }

  const rota = location.hash || "#/";
  try {
    atualizarTopbar(rota);
  } catch (e) {
    console.warn("topbar", e);
  }

  const isHome = !rota || rota === "#" || rota === "#/" || rota === "#/_ptr" || rota === "#/_refresh";

  // Home em cache
  if (isHome && _homePageCache && Date.now() - _homePageCacheAt < HOME_PAGE_TTL) {
    try { limparPlayer(); } catch (_) {}
    if (atual && atual !== _homePageCache && atual.destruir) {
      try { atual.destruir(); } catch (_) {}
    }
    while (root.firstChild) root.removeChild(root.firstChild);
    root.appendChild(_homePageCache);
    atual = _homePageCache;
    document.title = tituloDaRota("#/");
    marcarNav("/");
    return;
  }

  try { limparPlayer(); } catch (_) {}
  if (atual && atual.destruir) try { atual.destruir(); } catch (_) {}
  if (atual === _homePageCache) {
    if (atual && atual.parentNode) {
      try { atual.parentNode.removeChild(atual); } catch (_) {}
    }
  }

  marcarNav(rota.replace(/^#/, ""));
  document.title = tituloDaRota(rota);

  // Limpa boot / tela anterior NA HORA
  root.classList.add("page-switching");
  root.innerHTML = "";
  root.setAttribute("data-ready", "1");
  try { window.scrollTo(0, 0); } catch (_) {}

  // Rotas leves (busca, config, favoritos): abre no mesmo frame — sem esperar rAF
  const rotaLeve = /^#\/(busca|config|favoritos)(\/|\?|$)/.test(rota);
  if (!rotaLeve) {
    await new Promise((r) => requestAnimationFrame(() => r()));
  }

  try {
    const pageFn = resolver(rota);
    atual = (await pageFn(root)) || null;
    if (isHome && atual) {
      _homePageCache = atual;
      _homePageCacheAt = Date.now();
    } else if (isHome && !atual) {
      _homePageCache = null;
      _homePageCacheAt = 0;
    }
    if (!atual && root && !root.firstChild) {
      root.appendChild(el("div", { class: "center pad" }, "Não foi possível carregar esta tela."));
    }
  } catch (err) {
    console.error("Tedflix navegar", rota, err);
    _homePageCache = null;
    _homePageCacheAt = 0;
    try {
      root.innerHTML = "";
      const msg = String((err && err.message) || err || "erro desconhecido");
      root.appendChild(
        el("div", { class: "center pad", style: "padding:24px;color:#fff" }, [
          el("p", { style: "font-weight:700;margin-bottom:8px" }, "Erro ao abrir a tela"),
          el("p", { class: "sub", style: "word-break:break-word" }, msg),
          el(
            "button",
            {
              type: "button",
              class: "btn primary",
              style: "margin-top:16px",
            },
            "Recarregar",
          ),
        ]),
      );
      const btn = root.querySelector("button");
      if (btn) btn.addEventListener("click", () => location.reload());
    } catch (e2) {
      root.textContent = "Erro: " + String(err);
    }
  } finally {
    requestAnimationFrame(() => {
      try { root.classList.remove("page-switching"); } catch (_) {}
    });
  }
}

function tituloDaRota(hash) {
  const caminho = hash.replace(/^#\//, "").split("?")[0];
  const p = caminho.split("/").filter(Boolean);
  if (!p.length) return "TEDFLIX — Filmes e séries online";
  const mapa = {
    filmes: "Filmes",
    series: "Séries",
    categorias: "Categorias",
    agenda: "Agenda de episódios",
    canais: "Canais ao vivo",
    tedtop: "Explorar TEDTOP",
    canal: "Canal ao vivo",
    evento: "Evento ao vivo",
    busca: "Buscar",
    favoritos: "Minha lista",
    favorito: "Favorito",
    titulo: "Detalhes",
    assistir: "Assistir",
  };
  return `${mapa[p[0]] || "TEDFLIX"} — TEDFLIX`;
}

window.addEventListener("scroll", onAppScroll, { passive: true });

/* Seta de voltar na topbar (detalhes) — no lugar da logo */
(function bindTopbarBack() {
  const back = document.getElementById("topbar-back");
  if (!back || back.dataset.bound) return;
  back.dataset.bound = "1";
  back.addEventListener("click", (e) => {
    e.preventDefault();
    if (window.history.length > 1) history.back();
    else location.hash = "#/";
  });
})();

window.addEventListener("hashchange", () => {
  navegar().catch((e) => console.error("hashchange navegar", e));
});
navegar().catch((e) => {
  console.error("boot navegar", e);
  const root = getAppRoot();
  if (root) {
    root.innerHTML = "";
    const d = document.createElement("div");
    d.style.cssText = "color:#fff;padding:24px;text-align:center";
    d.innerHTML = "<p><b>Falha ao iniciar</b></p><p style=\"opacity:.7;word-break:break-word\">" +
      String((e && e.message) || e) +
      "</p><p style=\"margin-top:12px;opacity:.5;font-size:12px\">Reinicie o app</p>";
    root.appendChild(d);
  }
});


/* ---------- puxar para atualizar o catálogo ---------- */
(function setupPullToRefresh() {
  let startY = 0;
  let pulling = false;
  let refreshing = false;
  const limiar = 70;

  function rotaCatalogo() {
    const h = (location.hash || "#/").replace(/^#/, "") || "/";
    const base = h.split("?")[0].split("/").filter(Boolean)[0] || "";
    // Home e listas de catálogo
    return !base || ["", "filmes", "series", "lancamentos", "categorias", "categoria", "agenda"].includes(base);
  }

  function mostrarToast(msg) {
    let t = document.getElementById("ptr-toast");
    if (!t) {
      t = document.createElement("div");
      t.id = "ptr-toast";
      t.className = "ptr-toast";
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add("on");
    clearTimeout(t._hide);
    t._hide = setTimeout(() => t.classList.remove("on"), 1800);
  }

  async function atualizarCatalogo() {
    if (refreshing) return;
    refreshing = true;
    mostrarToast("Atualizando catálogo…");
    try {
      limparCacheCatalogo();
      _homePageCache = null;
      _homePageCacheAt = 0;
      // Re-dispara a rota atual (ou home) para buscar dados novos
      const atual = location.hash || "#/";
      const alvo = (!atual || atual === "#" || atual === "#/_refresh") ? "#/" : atual;
      if (location.hash === "#/_ptr") {
        location.hash = alvo;
      } else {
        location.hash = "#/_ptr";
        await new Promise((r) => requestAnimationFrame(r));
        location.hash = alvo === "#/_ptr" ? "#/" : alvo;
      }
      mostrarToast("Catálogo atualizado");
    } catch (_) {
      mostrarToast("Falha ao atualizar");
    } finally {
      setTimeout(() => { refreshing = false; }, 800);
    }
  }

  document.addEventListener(
    "touchstart",
    (e) => {
      if (refreshing) return;
      if (window.scrollY > 4) return;
      if (!rotaCatalogo()) return;
      startY = e.touches[0].clientY;
      pulling = true;
    },
    { passive: true },
  );

  document.addEventListener(
    "touchmove",
    (e) => {
      if (!pulling || refreshing) return;
      const dy = e.touches[0].clientY - startY;
      if (dy > 24 && window.scrollY <= 4) {
        document.body.classList.add("ptr-pulling");
      }
    },
    { passive: true },
  );

  document.addEventListener(
    "touchend",
    (e) => {
      if (!pulling) return;
      pulling = false;
      document.body.classList.remove("ptr-pulling");
      const dy = (e.changedTouches[0]?.clientY || 0) - startY;
      if (dy > limiar && window.scrollY <= 4 && rotaCatalogo()) {
        atualizarCatalogo();
      }
    },
    { passive: true },
  );
})();
