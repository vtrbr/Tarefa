import { el, limpar } from "../dom.js";
import { getAgenda, getMegacineCronograma } from "../api.js";

/** Parse "T8 E9" / "S2E4" → { t, e } */
function parseEpLabel(label) {
  const s = String(label || "");
  const m = s.match(/T\s*(\d+)\s*E\s*(\d+)/i) || s.match(/S\s*(\d+)\s*E\s*(\d+)/i);
  if (m) return { t: Number(m[1]), e: Number(m[2]) };
  return null;
}

export default async function paginaAgenda(raiz) {
  const page = el("div", { class: "page page-agenda" });
  const corpo = el("div", { class: "agenda-corpo" });
  page.append(el("h1", { class: "page-title" }, "Agenda"), corpo);
  raiz.append(page);

  corpo.append(el("div", { class: "center" }, [el("div", { class: "spinner" })]));

  try {
    let dias = [];
    try {
      dias = await getMegacineCronograma();
    } catch (_) {}
    if (!Array.isArray(dias) || !dias.length) {
      try {
        dias = await getAgenda();
      } catch (_) {}
    }
    if (!Array.isArray(dias)) dias = [];

    // normaliza formato legado CONTENT (nome + episodios) e MegaCine
    dias = dias
      .map((dia) => {
        const eps = dia.episodios || dia.itens || [];
        return {
          nome: dia.nome || dia.rotulo || dia.data || "",
          data: dia.data || "",
          episodios: (Array.isArray(eps) ? eps : []).map((ep) => ({
            titulo: ep.titulo || ep.serie || "",
            serie: ep.serie || ep.titulo || "",
            episodio: ep.episodio || ep.epLabel || "",
            horario: ep.horario || ep.hora || "",
            slug: ep.slug || "",
            tipo: ep.tipo || "serie",
            imagem: ep.imagem || ep.capa || "",
            link_detalhe:
              ep.link_detalhe ||
              (ep.slug ? `#/cine/serie/${encodeURIComponent(ep.slug)}` : ""),
          })),
        };
      })
      .filter((d) => d.episodios.length > 0);

    limpar(corpo);
    if (!dias.length) {
      corpo.append(
        el("p", { class: "center" }, "Nenhum episódio agendado nos próximos dias."),
      );
      return page;
    }

    dias.forEach((dia) => {
      const bloco = el("section", { class: "agenda-dia" });
      bloco.append(
        el("div", { class: "agenda-dia-head" }, [
          el("h2", {}, dia.nome || dia.data || "Dia"),
          el("span", { class: "agenda-dia-count" }, `${dia.episodios.length} ep.`),
        ]),
      );

      const lista = el("div", { class: "agenda-lista" });
      dia.episodios.forEach((ep) => {
        const parsed = parseEpLabel(ep.episodio);
        let href = ep.link_detalhe || "";
        // deep link opcional com temporada (usuário cai na ficha; play no ep)
        if (ep.slug) {
          href = `#/cine/serie/${encodeURIComponent(ep.slug)}`;
        }

        const row = el(
          href ? "a" : "div",
          {
            class: "agenda-item",
            href: href || undefined,
          },
          [
            el("div", { class: "agenda-hora" }, ep.horario || "—"),
            el("div", { class: "agenda-info" }, [
              el("p", { class: "agenda-titulo" }, ep.serie || ep.titulo || "Série"),
              el(
                "p",
                { class: "agenda-meta" },
                [ep.episodio, parsed ? `T${parsed.t}E${parsed.e}` : null]
                  .filter(Boolean)
                  .filter((v, i, a) => a.indexOf(v) === i)
                  .join(" · ") || "Episódio",
              ),
            ]),
            el("span", { class: "agenda-chevron", "aria-hidden": "true" }, "›"),
          ],
        );
        lista.append(row);
      });
      bloco.append(lista);
      corpo.append(bloco);
    });
  } catch (e) {
    limpar(corpo);
    corpo.append(
      el("p", { class: "center" }, "Não foi possível carregar a agenda. Puxe para atualizar."),
    );
  }

  return page;
}
