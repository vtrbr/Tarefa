import { el, limpar, svgIcone } from "../dom.js";
import {
  enriquecerComTmdb,
  getTmdbEpisodiosTemporada,
  extrairTmdbId,
  lookupTmdbById,
  limparTituloTmdb,
  getNoflixEpisodios,
  getEpisodios,
} from "../api.js";
import { backdrop, poster } from "../img.js";
import { abrirPlayerNativo, lerProgresso, lerFavorito, toggleFavorito } from "../playback.js";

function botaoVoltar() {
  // Seta agora fica na topbar (no lugar da logo) — não renderiza no conteúdo
  return el("span", { class: "detail-back", "aria-hidden": "true", hidden: true });
}


/** Monta itens no formato que o PlayerActivity espera. */
function montarFilaNoflix(idtmdb, temp, eps, fromIndex, audio) {
  const a = audio || "dub";
  return (eps || []).map((ep) => ({
    categoria: "noflix",
    slug: `serie-${idtmdb}-${temp}-${ep.numero}-${a}`,
    titulo: `${ep.numero}. ${ep.titulo || "Episódio " + ep.numero}`,
    filmeId: `${idtmdb}-t${temp}e${ep.numero}`,
    thumb: ep.imagem || "",
    tipo: "episodio",
    duracao: ep.runtime ? `${ep.runtime}min` : "",
  }));
}

function montarFilaContent(eps, fromIndex) {
  return (eps || []).map((ep) => ({
    categoria: ep.categoria || "",
    slug: ep.slug || "",
    titulo: ep.titulo || ep.nome || "Episódio",
    filmeId: ep.filmeId || ep.slug || "",
    thumb: ep.imagem || ep.thumb || "",
    tipo: "episodio",
    duracao: ep.duracao || "",
  }));
}

/**
 * Tela de informações de um episódio (NoFlix ou CONTENT).
 * Reprodução só após toque explícito em Assistir / Continuar.
 */
export default async function paginaEpisodioInfo(raiz, params) {
  const {
    fonte = "noflix",
    idtmdb = "",
    temporada = 1,
    episodio = 1,
    audio = "dub",
    categoria = "",
    slug = "",
    serieCategoria = "",
    serieSlug = "",
    serieTitulo = "",
    filmeId = "",
    thumb = "",
  } = params || {};

  const page = el("div", { class: "page page-ep-info" });
  raiz.append(page);

  // Voltar sempre visível desde o 1º frame
  const voltar = el("button", {
    class: "back",
    type: "button",
    "aria-label": "Voltar",
    onclick: () => {
      if (fonte === "noflix" && idtmdb) {
        location.hash = `#/noflix/serie/${encodeURIComponent(idtmdb)}`;
        return;
      }
      if (serieCategoria && serieSlug) {
        location.hash = `#/titulo/serie/${encodeURIComponent(serieCategoria)}/${encodeURIComponent(serieSlug)}`;
        return;
      }
      history.back();
    },
  });
  voltar.innerHTML = svgIcone("back");
  page.append(voltar);
  page.append(el("div", { class: "center detail-loading" }, [el("div", { class: "spinner" })]));

  const temp = Number(temporada) || 1;
  const epn = Number(episodio) || 1;
  let tituloSerie = serieTitulo || "";
  let tituloEp = `Episódio ${epn}`;
  let sinopse = "";
  let capa = thumb || "";
  let banner = "";
  let nota = null;
  let runtime = null;

  // Resolve meta
  try {
    if (fonte === "noflix" && idtmdb) {
      const sid = Number(idtmdb);
      const [serieMeta, eps] = await Promise.all([
        lookupTmdbById(sid, "serie").catch(() => null),
        getTmdbEpisodiosTemporada(sid, temp).catch(() => []),
      ]);
      if (serieMeta) {
        tituloSerie = serieMeta.titulo || tituloSerie;
        if (!capa) capa = serieMeta.capa || "";
        banner = serieMeta.banner || capa;
      }
      const hit = (eps || []).find((e) => Number(e.numero) === epn);
      if (hit) {
        if (hit.titulo) tituloEp = hit.titulo;
        if (hit.imagem) capa = hit.imagem;
        // sinopse não vem na rota enxuta — ok
      }
      if (!tituloSerie) tituloSerie = "Série";
    } else {
      // CONTENT: tenta TMDB pelo título da série
      const base = {
        titulo: serieTitulo || slug,
        slug: serieSlug || slug,
        tipo: "serie",
      };
      await enriquecerComTmdb(base, "serie");
      tituloSerie = limparTituloTmdb(base.titulo || serieTitulo || "", serieSlug || slug) || "Série";
      if (!capa) capa = base.imagem || base.capa || "";
      banner = base.banner || capa;
      const tid = extrairTmdbId(base);
      if (tid) {
        const eps = await getTmdbEpisodiosTemporada(tid, temp).catch(() => []);
        const hit = (eps || []).find((e) => Number(e.numero) === epn);
        if (hit) {
          if (hit.titulo) tituloEp = hit.titulo;
          if (hit.imagem) capa = hit.imagem;
        }
      }
    }
  } catch (_) {}

  const playCategoria = fonte === "noflix" ? "noflix" : categoria || serieCategoria || "";
  const playSlug =
    fonte === "noflix"
      ? `serie-${idtmdb}-${temp}-${epn}-${audio || "dub"}`
      : slug;
  const playFilmeId =
    fonte === "noflix" ? `${idtmdb}-t${temp}e${epn}` : filmeId || slug;
  const prog = lerProgresso({
    categoria: playCategoria,
    slug: playSlug,
    filmeId: playFilmeId,
  });

  limpar(page);
  page.append(botaoVoltar());
  page.append(voltar);

  const heroSrc = banner || capa;
  const hero = el("div", { class: "detail-hero ep-hero" });
  if (heroSrc) {
    hero.append(
      el("img", {
        src: backdrop(heroSrc, 780) || poster(capa, "lg") || heroSrc,
        alt: "",
        loading: "eager",
        onerror: "this.remove()",
      }),
    );
  } else {
    hero.append(el("div", { class: "thumb-placeholder thumb-placeholder--hero", "aria-hidden": "true" }));
  }
  hero.append(el("div", { class: "detail-hero-fade" }));
  page.append(hero);

  const corpo = el("div", { class: "pad ep-info-body" });
  corpo.append(el("p", { class: "sub" }, tituloSerie));
  corpo.append(
    el("h1", {}, `T${temp}E${epn} · ${tituloEp}`),
  );
  if (nota != null) corpo.append(el("p", { class: "tags" }, `★ ${nota}`));
  if (sinopse) corpo.append(el("p", { class: "sub", style: "line-height:1.45;margin-top:8px" }, sinopse));
  else corpo.append(el("p", { class: "sub", style: "margin-top:8px" }, "Sinopse indisponível para este episódio."));

  if (prog.percent > 0) {
    corpo.append(
      el("div", { class: "ep-progress-block", style: "margin-top:16px" }, [
        el("p", { class: "sub" }, `${prog.percent}% assistido`),
        el("div", { class: "ep-progress ep-progress--lg" }, [
          el("span", { style: `width:${prog.percent}%` }),
        ]),
      ]),
    );
  }

  let favorito = lerFavorito(playFilmeId, playSlug);
  const favoritoBtn = el(
    "button",
    {
      class: `btn ghost${favorito ? " ativo" : ""}`,
      type: "button",
    },
    favorito ? "♥ Favorito" : "♡ Favoritar",
  );
  favoritoBtn.addEventListener("click", async () => {
    if (!window.AndroidPlayer?.toggleFavorite) return;
    try {
      const resposta = JSON.parse(
        window.AndroidPlayer.toggleFavorite(
          playFilmeId,
          `${tituloSerie} T${temp}E${epn}`,
          capa || "",
          "episodio",
        ) || "{}",
      );
      if (!resposta.success) throw new Error(resposta.error || "Erro ao salvar");
      favorito = typeof resposta.favorito === "boolean" ? resposta.favorito : !favorito;
      favoritoBtn.textContent = favorito ? "♥ Favorito" : "♡ Favoritar";
      favoritoBtn.classList.toggle("ativo", favorito);
    } catch (e) {
      favoritoBtn.textContent = e.message || "Erro";
      setTimeout(() => {
        favoritoBtn.textContent = favorito ? "♥ Favorito" : "♡ Favoritar";
      }, 1600);
    }
  });

  const playLabel = prog.percent > 0 ? "▶ Continuar assistindo" : "▶ Assistir";
  const playBtn = el("button", { class: "btn primary", type: "button" }, playLabel);
  playBtn.addEventListener("click", async () => {
    const tituloPlay = `${tituloSerie} T${temp}E${epn}`;
    playBtn.disabled = true;
    playBtn.textContent = "Abrindo…";
    let todos = [];
    let fila = [];
    try {
      if (fonte === "noflix" && idtmdb) {
        const eps = await getNoflixEpisodios(idtmdb, temp).catch(() => []);
        todos = montarFilaNoflix(idtmdb, temp, eps, 0, audio || "dub");
        const idx = todos.findIndex((x) => String(x.slug).includes(`-${temp}-${epn}-`));
        fila = idx >= 0 ? todos.slice(idx + 1) : todos.filter((x) => {
          const m = String(x.slug).match(/-(\d+)-(\d+)-(?:dub|leg)/);
          return m && Number(m[2]) > epn;
        });
      } else if (serieCategoria && serieSlug) {
        const eps = await getEpisodios(serieCategoria, serieSlug, temp).catch(() => []);
        const mapped = (eps || []).map((ep) => {
          const link = ep.link || ep.link_assistir || "";
          let cat = serieCategoria, sl = "";
          try {
            const parts = String(link).replace(/^https?:\/\/[^/]+/, "").split("/").filter(Boolean);
            cat = parts[parts.length - 2] || serieCategoria;
            sl = parts[parts.length - 1] || "";
          } catch (_) {}
          return {
            categoria: cat,
            slug: sl,
            titulo: `${ep.numero || ""}. ${ep.titulo || ep.nome || "Episódio"}`,
            filmeId: sl,
            thumb: ep.imagem || "",
            tipo: "episodio",
            duracao: ep.duracao || "",
            numero: Number(ep.numero) || 0,
          };
        }).filter((x) => x.slug);
        todos = mapped;
        const idx = mapped.findIndex((x) => x.numero === epn || x.slug === slug);
        fila = idx >= 0 ? mapped.slice(idx + 1) : [];
      }
    } catch (_) {}
    if (
      abrirPlayerNativo({
        categoria: playCategoria,
        slug: playSlug,
        titulo: tituloPlay,
        thumb: capa || "",
        tipo: "episodio",
        filmeId: playFilmeId,
        serieCategoria: serieCategoria || categoria || "",
        serieSlug: serieSlug || "",
        fila,
        episodios: todos,
      })
    ) {
      playBtn.disabled = false;
      playBtn.textContent = playLabel;
      return;
    }
    location.hash = `#/assistir/${encodeURIComponent(playCategoria)}/${encodeURIComponent(playSlug)}`;
    playBtn.disabled = false;
    playBtn.textContent = playLabel;
  });

  corpo.append(
    el("div", { class: "ep-info-actions", style: "display:flex;gap:12px;margin-top:20px;flex-wrap:wrap;padding-bottom:24px" }, [
      playBtn,
      favoritoBtn,
    ]),
  );
  page.append(corpo);
  return page;
}
