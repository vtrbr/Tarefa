import { el, limpar, svgIcone } from "../dom.js";
import {
  getTedv2Movie,
  getTedv2Series,
  getTedv2Season,
} from "../api.js";
import { lerFavorito, toggleFavorito, abrirPlayerNativo, lerProgresso } from "../playback.js";

/**
 * Detalhe TEDFLIX API v2
 * Filme: catalog/movie/:tmdb → stream/movie/:imdb
 * Série: catalog/series/:tmdb → seasons → stream/series/:imdb/season/t/episode/e
 *
 * Player nativo: categoria "tedv2"
 *   slug filme: filme-{imdb}-{dub|sub}
 *   slug ep:    serie-{imdb}-{temp}-{ep}-{dub|sub}
 */

function playTedv2({ imdb, titulo, thumb, filmeId, lang = "dub", temp, ep, tipo }) {
  const a = lang === "leg" || lang === "sub" ? "sub" : "dub";
  const id = String(imdb || "").trim();
  if (!id) return false;
  let slug;
  if (tipo === "serie" || (temp != null && ep != null)) {
    slug = `serie-${id}-${temp}-${ep}-${a}`;
  } else {
    slug = `filme-${id}-${a}`;
  }
  return abrirPlayerNativo({
    categoria: "tedv2",
    slug,
    titulo: titulo || "",
    filmeId: filmeId || slug,
    thumb: thumb || "",
    tipo: temp != null ? "episodio" : "filme",
    serieCategoria: "tedv2",
    serieSlug: id,
  });
}

export async function paginaTedv2Filme(raiz, tmdbId) {
  const page = el("div", { class: "page page-detail page-tedv2" });
  raiz.append(page);
  page.append(el("div", { class: "center detail-loading" }, [el("div", { class: "spinner" })]));

  let dados;
  try {
    dados = await getTedv2Movie(tmdbId);
  } catch (_) {
    dados = null;
  }
  limpar(page);
  if (!dados) {
    page.append(el("p", { class: "center pad" }, "Não foi possível carregar este filme."));
    return page;
  }

  const imdb = dados.imdb || "";
  const titulo = dados.titulo || dados.title || "Filme";
  const capa = dados.banner || dados.backdrop || dados.capa || dados.poster || "";
  const filmeId = `tedv2-${dados.tmdb || tmdbId}`;
  let favorito = lerFavorito(filmeId, String(dados.tmdb || tmdbId), "tedv2");

  const hero = el("div", { class: "detail-hero" });
  if (capa) {
    hero.append(el("img", { src: capa, alt: titulo, class: "detail-hero-img", decoding: "async" }));
  }
  hero.append(el("div", { class: "veil" }));
  page.append(hero);

  const info = el("div", { class: "detail-info pad" });
  info.append(el("h1", {}, titulo));
  const meta = [
    dados.vote_average != null ? `★ ${Number(dados.vote_average).toFixed(1)}` : "",
    "Filme",
    dados.year || dados.ano || "",
    dados.runtime ? `${dados.runtime}min` : "",
  ]
    .filter(Boolean)
    .join(" · ");
  if (meta) info.append(el("p", { class: "sub" }, meta));

  const acoes = el("div", { class: "detail-actions" });
  const btnDub = el("button", { type: "button", class: "btn primary" }, "▶ Assistir dublado");
  const btnLeg = el("button", { type: "button", class: "btn ghost" }, "▶ Assistir legendado");
  const btnFav = el(
    "button",
    { type: "button", class: "btn ghost" },
    favorito ? "♥ Na lista" : "♡ Favorito",
  );

  btnDub.addEventListener("click", () => {
    if (!imdb) {
      alert("Este título ainda não tem ID IMDb para reproduzir.");
      return;
    }
    const ok = playTedv2({
      imdb,
      titulo,
      thumb: capa,
      filmeId,
      lang: "dub",
      tipo: "filme",
    });
    if (!ok) alert("Player indisponível neste aparelho.");
  });
  btnLeg.addEventListener("click", () => {
    if (!imdb) {
      alert("Este título ainda não tem ID IMDb para reproduzir.");
      return;
    }
    const ok = playTedv2({
      imdb,
      titulo,
      thumb: capa,
      filmeId,
      lang: "sub",
      tipo: "filme",
    });
    if (!ok) alert("Player indisponível neste aparelho.");
  });
  btnFav.addEventListener("click", () => {
    favorito = toggleFavorito({
      filmeId,
      slug: String(dados.tmdb || tmdbId),
      categoria: "tedv2",
      titulo,
      thumb: capa,
      tipo: "filme",
    });
    btnFav.textContent = favorito ? "♥ Na lista" : "♡ Favorito";
  });

  if (imdb) acoes.append(btnDub, btnLeg);
  else acoes.append(el("p", { class: "sub" }, "Reprodução indisponível (sem IMDb)."));
  acoes.append(btnFav);
  info.append(acoes);

  if (dados.sinopse || dados.overview) {
    info.append(el("p", { class: "detail-sinopse" }, dados.sinopse || dados.overview));
  }
  if (Array.isArray(dados.genres) && dados.genres.length) {
    const tags = el("div", { class: "detail-tags" });
    dados.genres.forEach((g) => {
      tags.append(el("span", { class: "tag" }, g.name || g));
    });
    info.append(tags);
  }
  if (Array.isArray(dados.cast) && dados.cast.length) {
    info.append(el("h2", {}, "Elenco"));
    const rail = el("div", { class: "cast-rail" });
    dados.cast.slice(0, 12).forEach((c) => {
      const card = el("div", { class: "cast-card" });
      if (c.profile) card.append(el("img", { src: c.profile, alt: c.name || "", loading: "lazy" }));
      card.append(el("strong", {}, c.name || ""));
      if (c.character) card.append(el("small", {}, c.character));
      rail.append(card);
    });
    info.append(rail);
  }
  page.append(info);
  return page;
}

export async function paginaTedv2Serie(raiz, tmdbId) {
  const page = el("div", { class: "page page-detail page-tedv2" });
  raiz.append(page);
  page.append(el("div", { class: "center detail-loading" }, [el("div", { class: "spinner" })]));

  let dados;
  try {
    dados = await getTedv2Series(tmdbId);
  } catch (_) {
    dados = null;
  }
  limpar(page);
  if (!dados) {
    page.append(el("p", { class: "center pad" }, "Não foi possível carregar esta série."));
    return page;
  }

  const imdb = dados.imdb || "";
  const titulo = dados.titulo || dados.title || "Série";
  const capa = dados.banner || dados.backdrop || dados.capa || dados.poster || "";
  const filmeId = `tedv2-${dados.tmdb || tmdbId}`;
  let favorito = lerFavorito(filmeId, String(dados.tmdb || tmdbId), "tedv2");

  const hero = el("div", { class: "detail-hero" });
  if (capa) {
    hero.append(el("img", { src: capa, alt: titulo, class: "detail-hero-img", decoding: "async" }));
  }
  hero.append(el("div", { class: "veil" }));
  page.append(hero);

  const info = el("div", { class: "detail-info pad" });
  info.append(el("h1", {}, titulo));
  const meta = [
    dados.vote_average != null ? `★ ${Number(dados.vote_average).toFixed(1)}` : "",
    "Série",
    dados.year || dados.ano || "",
    dados.number_of_seasons ? `${dados.number_of_seasons} temp.` : "",
  ]
    .filter(Boolean)
    .join(" · ");
  if (meta) info.append(el("p", { class: "sub" }, meta));

  const btnFav = el(
    "button",
    { type: "button", class: "btn ghost" },
    favorito ? "♥ Na lista" : "♡ Favorito",
  );
  btnFav.addEventListener("click", () => {
    favorito = toggleFavorito({
      filmeId,
      slug: String(dados.tmdb || tmdbId),
      categoria: "tedv2",
      titulo,
      thumb: capa,
      tipo: "serie",
    });
    btnFav.textContent = favorito ? "♥ Na lista" : "♡ Favorito";
  });
  info.append(el("div", { class: "detail-actions" }, [btnFav]));

  if (dados.sinopse || dados.overview) {
    info.append(el("p", { class: "detail-sinopse" }, dados.sinopse || dados.overview));
  }
  page.append(info);

  // Temporadas / episódios
  const seasons = (dados.seasons || []).filter((s) => Number(s.season_number) > 0);
  const epSection = el("div", { class: "pad detail-eps" });
  epSection.append(el("h2", {}, "Episódios"));
  const tabs = el("div", { class: "season-tabs" });
  const list = el("div", { class: "ep-list" });
  epSection.append(tabs, list);
  page.append(epSection);

  let currentSeason = seasons[0]?.season_number || 1;

  async function carregarTemp(n) {
    currentSeason = n;
    [...tabs.children].forEach((b) => {
      b.classList.toggle("ativo", Number(b.dataset.s) === n);
    });
    limpar(list);
    list.append(el("div", { class: "center" }, [el("div", { class: "spinner" })]));
    let eps = [];
    try {
      const data = await getTedv2Season(tmdbId, n);
      eps = data.episodes || [];
    } catch (_) {
      eps = [];
    }
    limpar(list);
    if (!eps.length) {
      list.append(el("p", { class: "sub" }, "Nenhum episódio encontrado."));
      return;
    }
    eps.forEach((ep) => {
      const num = ep.episode_number != null ? ep.episode_number : "?";
      const nome = ep.name || `Episódio ${num}`;
      const row = el("div", { class: "ep-row" });
      if (ep.still) {
        row.append(
          el("img", {
            class: "ep-thumb",
            src: ep.still,
            alt: "",
            loading: "lazy",
          }),
        );
      }
      const body = el("div", { class: "ep-body" });
      body.append(el("strong", {}, `E${num} · ${nome}`));
      if (ep.overview) body.append(el("p", { class: "sub" }, String(ep.overview).slice(0, 120)));
      row.append(body);
      const play = el("button", { type: "button", class: "btn icon-play", "aria-label": "Assistir" }, "▶");
      play.addEventListener("click", () => {
        if (!imdb) {
          alert("Esta série ainda não tem ID IMDb para reproduzir.");
          return;
        }
        const ok = playTedv2({
          imdb,
          titulo: `${titulo} — T${n}E${num}`,
          thumb: ep.still || capa,
          filmeId: `tedv2-${tmdbId}-t${n}e${num}`,
          lang: "dub",
          temp: n,
          ep: num,
          tipo: "serie",
        });
        if (!ok) alert("Player indisponível neste aparelho.");
      });
      row.append(play);
      list.append(row);
    });
  }

  seasons.forEach((s) => {
    const n = s.season_number;
    const b = el("button", { type: "button", class: "season-tab", "data-s": String(n) }, `T${n}`);
    b.addEventListener("click", () => carregarTemp(n));
    tabs.append(b);
  });
  if (seasons.length) carregarTemp(currentSeason);
  else list.append(el("p", { class: "sub" }, "Sem temporadas."));

  return page;
}

export default async function paginaTedv2Detalhe(raiz, { tipo, id }) {
  if (tipo === "serie" || tipo === "series") return paginaTedv2Serie(raiz, id);
  return paginaTedv2Filme(raiz, id);
}
