import { el, limpar, aoAparecer } from "../dom.js";
import { cardTitulo, cardTop10, skeletonCard } from "./card.js";
import { prefetchImagens } from "../img.js";
import { enriquecerListaTmdb } from "../api.js";

/**
 * Fileira horizontal preguiçosa estilo Netflix.
 * variante: "continuar" | "tedtop" | default
 */
export function fileira({ titulo, verTudo, carregar, limite = 20, variante = "" }) {
  const rail = el("div", {
    class: `rail${variante ? ` rail--${variante}` : ""}`,
    role: "region",
    "aria-label": titulo,
  });
  for (let i = 0; i < 6; i++) rail.append(skeletonCard());

  const secao = el("section", {
    class: `section${variante ? ` section--${variante}` : ""}`,
  }, [
    el("div", { class: "section-head" }, [
      el("h2", {}, titulo),
      verTudo ? el("a", { href: verTudo }, "Ver tudo ›") : null,
    ]),
    rail,
  ]);

  let carregada = false;
  const carregarRail = async () => {
    if (carregada) return;
    carregada = true;
    try {
      const itens = (await carregar()) || [];
      limpar(rail);
      if (!itens.length) {
        // Fileiras TEDTOP/continuar vazias: remove a seção inteira
        if (variante === "continuar" || variante === "tedtop") {
          secao.remove();
          return;
        }
        rail.append(el("p", { class: "sub" }, "Nada por aqui agora."));
        return;
      }
      const lista = itens.slice(0, limite);
      // Capa faltando: tenta TMDB rápido (não bloqueia se falhar)
      const semCapa = lista.filter((i) => !String(i.imagem || i.capa || i.thumb || "").trim());
      if (semCapa.length) {
        try {
          await Promise.race([
            enriquecerListaTmdb(semCapa, variante === "continuar" ? "filme" : "filme"),
            new Promise((r) => setTimeout(r, 3500)),
          ]);
          // copia capa de volta se o enriquecimento mutou os objetos
          semCapa.forEach((i) => {
            if (!i.imagem && i.capa) i.imagem = i.capa;
          });
        } catch (_) {}
      }
      const primeiros = document.createDocumentFragment();
      lista.slice(0, 10).forEach((item) =>
        primeiros.append(cardTitulo(item, { eager: true, size: variante === "continuar" ? "md" : "sm" })),
      );
      rail.append(primeiros);

      const agenda = window.requestIdleCallback || ((f) => setTimeout(f, 60));
      agenda(() => {
        const frag = document.createDocumentFragment();
        lista.slice(6).forEach((item) =>
          frag.append(cardTitulo(item, { size: variante === "continuar" ? "md" : "sm" })),
        );
        rail.append(frag);
        prefetchImagens(
          itens.slice(0, limite + 10).map((i) => i.imagem || i.capa || i.thumb || i.poster).filter(Boolean),
        );
      });
    } catch (e) {
      limpar(rail);
      if (variante === "tedtop" || variante === "continuar") {
        secao.remove();
        return;
      }
      rail.append(
        el("div", { class: "rail-error" }, [
          el("p", { class: "sub" }, "Não foi possível carregar esta fileira."),
          el("button", {
            class: "btn ghost",
            type: "button",
            onclick: () => {
              carregada = false;
              limpar(rail);
              for (let i = 0; i < 6; i++) rail.append(skeletonCard());
              carregarRail();
            },
          }, "Tentar de novo"),
        ]),
      );
    }
  };
  aoAparecer(secao, carregarRail, "1800px");
  // Continuar e TEDTOP: carregar mais cedo (destaque na home)
  setTimeout(carregarRail, variante === "continuar" || variante === "tedtop" ? 200 : 1200);

  return secao;
}


/**
 * Fileira Top 10 com números grandes (estilo Netflix).
 */
export function fileiraTop10({ titulo, carregar, limite = 10 }) {
  const rail = el("div", {
    class: "rail rail--top10",
    role: "region",
    "aria-label": titulo,
  });
  for (let i = 0; i < 5; i++) rail.append(skeletonCard());

  const secao = el("section", { class: "section section--top10" }, [
    el("div", { class: "section-head" }, [el("h2", {}, titulo)]),
    rail,
  ]);

  let carregada = false;
  const carregarRail = async () => {
    if (carregada) return;
    carregada = true;
    try {
      const itens = (await carregar()) || [];
      limpar(rail);
      if (!itens.length) {
        secao.remove();
        return;
      }
      const lista = itens.slice(0, limite);
      const frag = document.createDocumentFragment();
      lista.forEach((item, idx) => {
        frag.append(cardTop10(item, item.rank || idx + 1, { eager: idx < 4 }));
      });
      rail.append(frag);
      prefetchImagens(
        lista.map((i) => i.imagem || i.capa || i.thumb || i.poster).filter(Boolean),
      );
    } catch (e) {
      limpar(rail);
      secao.remove();
    }
  };

  aoAparecer(secao, carregarRail);
  // carrega cedo (está no topo da home)
  requestAnimationFrame(() => carregarRail());
  return secao;
}
