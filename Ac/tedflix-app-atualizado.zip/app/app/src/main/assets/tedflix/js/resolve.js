/**
 * resolve.js — resolve título/favorito para rota de detalhe ou episódio.
 * Um único fluxo para #/favorito e #/episodio/resolve.
 */
import { buscar, buscarNoflix, ehSerie, parseLink } from "./api.js";

function scoreTitulo(itemTitulo, nome) {
  const t = String(itemTitulo || "").toLowerCase().replace(/[^a-z0-9]+/gi, "");
  const n = String(nome || "").toLowerCase().replace(/[^a-z0-9]+/gi, "");
  if (!t || !n) return 0;
  if (t === n) return 3;
  if (t.includes(n) || n.includes(t)) return 2;
  return 0;
}

/** Busca NoFlix por título. Retorna { series, filmes }. */
export async function buscarNoflixPorTitulo(titulo, limite = 16) {
  const nx = await buscarNoflix(titulo, limite);
  const lista = Array.isArray(nx?.resultados) ? nx.resultados : [];
  const series = lista
    .filter((i) => /serie|séri|tv/i.test(String(i.tipo || "")) || i.total_temporadas)
    .sort((a, b) => scoreTitulo(b.titulo, titulo) - scoreTitulo(a.titulo, titulo));
  const filmes = lista
    .filter((i) => !/serie|séri|tv/i.test(String(i.tipo || "")))
    .sort((a, b) => scoreTitulo(b.titulo, titulo) - scoreTitulo(a.titulo, titulo));
  return { series, filmes, lista };
}

/**
 * Resolve um favorito/filme por título → hash de destino ou null.
 * @param {{ titulo: string, preferSerie?: boolean }}
 */
export async function resolveTituloParaRota({ titulo, preferSerie = false } = {}) {
  const t = String(titulo || "").trim();
  if (!t) return null;

  try {
    const { series, filmes } = await buscarNoflixPorTitulo(t, 16);
    const hitS = series.find((i) => scoreTitulo(i.titulo, t) > 0) || null;
    const hitF = filmes.find((i) => scoreTitulo(i.titulo, t) > 0) || null;
    if (preferSerie && hitS?.idtmdb) return `#/noflix/serie/${hitS.idtmdb}`;
    if (hitS?.idtmdb && (preferSerie || !hitF)) return `#/noflix/serie/${hitS.idtmdb}`;
    if (hitF?.idtmdb) return `#/noflix/filme/${hitF.idtmdb}`;
    if (hitS?.idtmdb) return `#/noflix/serie/${hitS.idtmdb}`;
  } catch (_) {}

  try {
    const resposta = await buscar(t);
    const itens = resposta.resultados || [];
    const normalizado = t.toLowerCase();
    const item =
      itens.find((i) => (i.titulo || "").trim().toLowerCase() === normalizado) ||
      itens.find((i) => (i.titulo || "").toLowerCase().includes(normalizado)) ||
      itens[0];
    if (!item) return null;
    if (item.idtmdb && /noflix/i.test(String(item.fonte || item.tipo || ""))) {
      return ehSerie(item)
        ? `#/noflix/serie/${item.idtmdb}`
        : `#/noflix/filme/${item.idtmdb}`;
    }
    const link = parseLink(item.link_assistir);
    const categoria = item.categoria || link.categoria;
    const slug = item.slug || link.slug;
    if (!categoria || !slug) return null;
    return `#/titulo/${ehSerie(item) ? "serie" : "filme"}/${encodeURIComponent(categoria)}/${encodeURIComponent(slug)}`;
  } catch (_) {
    return null;
  }
}

/**
 * Resolve episódio só com nome da série + T/E.
 * @returns hash ou null
 */
export async function resolveEpisodioPorTitulo({ titulo, temp = 1, ep = 1 } = {}) {
  const t = String(titulo || "").trim();
  if (!t) return null;
  const temporada = String(temp || 1);
  const episodio = String(ep || 1);

  try {
    const { series } = await buscarNoflixPorTitulo(t, 20);
    const hit = series.find((s) => scoreTitulo(s.titulo, t) > 0) || series[0];
    if (hit?.idtmdb) {
      return `#/episodio/noflix/${hit.idtmdb}/${temporada}/${episodio}?audio=dub`;
    }
  } catch (_) {}

  try {
    const resposta = await buscar(t);
    const itens = resposta.resultados || [];
    const item =
      itens.find((i) => ehSerie(i) && scoreTitulo(i.titulo, t) > 0) ||
      itens.find((i) => ehSerie(i)) ||
      itens[0];
    if (!item) return null;
    const link = parseLink(item.link_assistir);
    const categoria = item.categoria || link.categoria;
    const slug = item.slug || link.slug;
    if (!categoria || !slug) return null;
    const q = new URLSearchParams({
      t: temporada,
      e: episodio,
      serieCategoria: categoria,
      serieSlug: slug,
      titulo: item.titulo || t,
    });
    return `#/episodio/${encodeURIComponent(categoria)}/${encodeURIComponent(slug)}?${q}`;
  } catch (_) {
    return null;
  }
}
