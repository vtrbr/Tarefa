import { NOFLIX_ENABLED } from "../config.js";
import { el, limpar } from "../dom.js";
import { hero } from "../components/hero.js";
import { fileira, fileiraTop10 } from "../components/row.js";
import {
  getCarousel,
  getUltimosFilmes,
  buscar,
  parseLink,
  getLancamentos,
  getSeries,
  getGenero,
  getTedtopTelao,
  getTedtopBilheteria,
  getNoflixTopFilmes,
  getNoflixTopSeries,
  getMegacinePainel,
  enriquecerMegacineCapa,
  getMegacinePelicula,
  enriquecerListaTmdb,
  enriquecerComTmdb,
  limparTituloTmdb,
  getTmdbEpisodiosTemporada,
  extrairTmdbId,
  resolverTmdbMeta,
  getNoflixFilmes,
  getNoflixSeries,
  getNoflixSeriesEstreias,
  getNoflixUltimosEps,
  getMegacineSerial,
  getNoflixFilmesGenero,
  getTedv2Home,
  getTedv2PopularMovies,
  getTedv2PopularSeries,
  getTedv2Trending,
  getMegacineGenero,
  getNoflixSeriesGenero,
} from "../api.js";
import { CATEGORIAS } from "../config.js";

/**
 * Home estilo Netflix:
 * 1. Hero / destaques
 * 2. Continuar assistindo (destaque)
 * 3. Em cartaz / Bilheteria (TEDTOP)
 * 4. Lançamentos, séries, gêneros (CONTENT)
 */
let _homeContinuarCache = { t: 0, lista: null };
const HOME_CONTINUAR_TTL = 3 * 60 * 1000; // 3 min em memória

export default async function paginaInicio(raiz) {
  const page = el("div", { class: "page home-netflix" });
  const topo = el("div", { class: "hero skel" });
  page.append(topo);
  raiz.append(page);

  // Placeholder do Continuar — nunca bloqueia a pintura do restante da home
  const slotContinuar = el("div", { class: "home-continuar-slot" });
  page.append(slotContinuar);

  const inserirContinuar = (lista) => {
    if (!Array.isArray(lista) || !lista.length || !page.isConnected) return;
    try {
      limpar(slotContinuar);
      slotContinuar.append(
        fileira({
          titulo: "Continuar assistindo",
          carregar: async () => lista,
          limite: 20,
          variante: "continuar",
        }),
      );
    } catch (_) {}
  };

  const agora = Date.now();
  if (_homeContinuarCache.lista && agora - _homeContinuarCache.t < HOME_CONTINUAR_TTL) {
    inserirContinuar(_homeContinuarCache.lista);
  } else {
    // background — timeout curto; home já está visível com Top 10 / seções
    Promise.race([
      carregarContinuarAssistindo().catch(() => []),
      new Promise((resolve) => setTimeout(() => resolve([]), 3500)),
    ])
      .then((lista) => {
        if (Array.isArray(lista) && lista.length) {
          _homeContinuarCache = { t: Date.now(), lista };
          inserirContinuar(lista);
        }
      })
      .catch(() => {});
  }

  // Top 10 NoFlix (Em alta) — logo abaixo de Continuar assistindo
  page.append(
    fileiraTop10({
      titulo: "Top 10 · Em alta",
      carregar: () => (!NOFLIX_ENABLED ? Promise.resolve(null) : getNoflixTopFilmes)(10),
      limite: 10,
    }),
    fileiraTop10({
      titulo: "Top 10 · Séries em alta",
      carregar: () => (!NOFLIX_ENABLED ? Promise.resolve(null) : getNoflixTopSeries)(10),
      limite: 10,
    }),
  );

  // TEDFLIX API v2 — catálogo TMDB (capas oficiais)
  page.append(
    fileira({
      titulo: "Em alta agora",
      carregar: async () => {
        try {
          const t = await getTedv2Trending("week");
          if (t && t.length) return t;
          const h = await getTedv2Home();
          return (h.rows && h.rows[0] && h.rows[0].itens) || [];
        } catch (_) {
          return [];
        }
      },
      limite: 20,
    }),
    fileira({
      titulo: "Filmes populares",
      carregar: async () => {
        try {
          return (await getTedv2PopularMovies(1)) || [];
        } catch (_) {
          return [];
        }
      },
      limite: 20,
    }),
    fileira({
      titulo: "Séries populares",
      carregar: async () => {
        try {
          return (await getTedv2PopularSeries(1)) || [];
        } catch (_) {
          return [];
        }
      },
      limite: 20,
    }),
  );

  // Lançamentos (MegaCine) — badge DESTACADO nos primeiros
  page.append(
    fileira({
      titulo: "Lançamentos",
      carregar: async () => {
        try {
          const painel = await getMegacinePainel();
          const sec = (painel.secoes || []).find(
            (s) => s.key === "lancamentos" || /lançamento/i.test(String(s.titulo || "")),
          );
          let itens = sec?.itens || [];
          // capa se faltar
          await Promise.race([
            Promise.all(itens.slice(0, 10).map((it) => enriquecerMegacineCapa(it))),
            new Promise((r) => setTimeout(r, 5000)),
          ]);
          itens = itens.map((it, idx) => ({
            ...it,
            badgeExtra: idx < 6 ? "DESTACADO" : it.badgeExtra || null,
          }));
          return itens;
        } catch (_) {
          return [];
        }
      },
      limite: 20,
    }),
  );

  // TEDTOP — Em cartaz / bilheteria (segunda API visível na home)
  page.append(
    fileira({
      titulo: "Em cartaz",
      carregar: async () => { const d = await getTedtopTelao(1); return d.itens || []; },
      limite: 18,
      variante: "tedtop",
    }),
    fileira({
      titulo: "Bilheteria",
      carregar: async () => normalizarTedtop(await getTedtopBilheteria()),
      limite: 18,
      variante: "tedtop",
    }),
  );

  // Helper: mistura listas sem repetir título
  const homeSeenGlobal = new Set();
  const misturar = (...listas) => {
    const seen = new Set();
    const out = [];
    for (const lista of listas) {
      for (const it of lista || []) {
        const k = String(it.titulo || it.name || "")
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "");
        if (!k || seen.has(k)) continue;
        seen.add(k);
        out.push(it);
      }
    }
    return out;
  };

  // Catálogo amplo — várias fontes, sem repetir a fileira "Lançamentos"
  page.append(
    fileira({
      titulo: "Filmes pra você",
      verTudo: "#/filmes",
      carregar: async () => {
        const [a, b, c] = await Promise.allSettled([
          (!NOFLIX_ENABLED ? Promise.resolve(null) : getNoflixFilmes)({ limite: 30 }),
          getMegacinePelicula(1),
          getUltimosFilmes(),
        ]);
        return misturar(
          a.status === "fulfilled" ? a.value : [],
          b.status === "fulfilled" ? b.value : [],
          c.status === "fulfilled" ? c.value : [],
        ).slice(0, 28);
      },
      limite: 24,
    }),
    fileira({
      titulo: "Séries pra você",
      verTudo: "#/series",
      carregar: async () => {
        const [a, b, c] = await Promise.allSettled([
          (!NOFLIX_ENABLED ? Promise.resolve(null) : getNoflixSeries)({ limite: 30 }),
          getMegacineSerial(1),
          getSeries(),
        ]);
        return misturar(
          a.status === "fulfilled" ? a.value : [],
          b.status === "fulfilled" ? b.value : [],
          c.status === "fulfilled" ? c.value : [],
        ).slice(0, 28);
      },
      limite: 24,
    }),
    fileira({
      titulo: "Estreias de séries",
      carregar: async () => {
        try {
          return (await (!NOFLIX_ENABLED ? Promise.resolve(null) : getNoflixSeriesEstreias)(24)) || [];
        } catch (_) {
          return [];
        }
      },
      limite: 20,
    }),
    fileira({
      titulo: "Episódios recentes",
      carregar: async () => {
        try {
          return (await (!NOFLIX_ENABLED ? Promise.resolve(null) : getNoflixUltimosEps)(24)) || [];
        } catch (_) {
          return [];
        }
      },
      limite: 20,
    }),
    fileira({
      titulo: "Novidades do catálogo",
      verTudo: "#/categoria/lancamentos",
      carregar: async () => {
        try {
          return (await getLancamentos()) || [];
        } catch (_) {
          return [];
        }
      },
      limite: 24,
    }),
  );

  // Gêneros — fontes variadas + anti-repetição GLOBAL entre fileiras
  const generoSeenGlobal = new Set();
  const chaveTitulo = (it) =>
    String(it.titulo || it.name || "")
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "");

  CATEGORIAS.forEach((c, idx) => {
    page.append(
      fileira({
        titulo: c.label,
        verTudo: `#/categoria/${c.slug}`,
        carregar: async () => {
          try {
            const jobs = [
              (!NOFLIX_ENABLED ? Promise.resolve(null) : getNoflixFilmesGenero)(c.slug, 40),
              (!NOFLIX_ENABLED ? Promise.resolve(null) : getNoflixSeriesGenero)(c.slug, 24),
              getGenero(c.slug),
            ];
            // MegaCine por gênero quando existir
            if (typeof getMegacineGenero === "function") {
              jobs.push(getMegacineGenero(c.slug, 1));
            }
            const results = await Promise.allSettled(jobs);
            const listas = results.map((r) => {
              if (r.status !== "fulfilled") return [];
              const v = r.value;
              if (Array.isArray(v)) return v;
              if (v && Array.isArray(v.itens)) return v.itens;
              if (v && Array.isArray(v.filmes)) return v.filmes;
              return [];
            });
            // Alterna ordem por índice da categoria p/ variar o que sobe primeiro
            if (idx % 2 === 1) listas.reverse();
            const pool = misturar(...listas);
            const fresh = [];
            const reuse = [];
            for (const it of pool) {
              const k = chaveTitulo(it);
              if (!k) continue;
              if (generoSeenGlobal.has(k)) reuse.push(it);
              else {
                generoSeenGlobal.add(k);
                fresh.push(it);
              }
              if (fresh.length >= 20) break;
            }
            // Só reusa já vistos se a fileira ficar pobre demais
            if (fresh.length < 10) {
              for (const it of reuse) {
                fresh.push(it);
                if (fresh.length >= 16) break;
              }
            }
            return fresh.slice(0, 20);
          } catch (_) {
            return [];
          }
        },
        limite: 20,
      }),
    );
  });

  try {
    // Banner principal: MegaCine /painel hero (com capa via dossier se faltar)
    let destaques = [];
    try {
      const painel = await getMegacinePainel();
      destaques = Array.isArray(painel.hero) ? painel.hero.slice(0, 12) : [];
      // enriquece capa dos primeiros (paralelo, timeout)
      await Promise.race([
        Promise.all(destaques.slice(0, 6).map((it) => enriquecerMegacineCapa(it))),
        new Promise((r) => setTimeout(r, 6000)),
      ]);
    } catch (_) {}
    if (!destaques.length) {
      try { destaques = await getCarousel(); } catch (_) {}
    }
    const h = hero(destaques.length ? destaques : []);
    topo.replaceWith(h);
    page.destruir = () => h.destruir?.();
  } catch (e) {
    topo.classList.remove("skel");
    topo.append(el("div", { class: "center" }, "Não foi possível carregar os destaques."));
  }

  return page;
}

/** Normaliza itens TEDTOP para o card (slug + imagem https + rota de detalhe). */
function normalizarTedtop(lista) {
  const itens = Array.isArray(lista) ? lista : [];
  return itens
    .map((item) => {
      const slug = String(item.slug || "").trim();
      let imagem = String(item.imagem || item.thumb || item.poster || "").trim();
      if (imagem.startsWith("//")) imagem = `https:${imagem}`;
      const categoria = String(item.categoria || "destaque").trim() || "destaque";
      return {
        ...item,
        titulo: item.titulo || slug,
        slug,
        categoria,
        imagem,
        tipo: item.tipo || "Filme",
        ano: item.ano || "",
        link_assistir: item.link_assistir || `#/titulo/filme/${categoria}/${slug}`,
        origem: "tedtop",
        badgeExtra: item.trailer || item.tem_trailer ? "Trailer" : null,
      };
    })
    .filter((i) => i.slug || i.titulo);
}

async function carregarContinuarAssistindo() {
  try {
    if (!window.AndroidPlayer?.getContinueWatching) return [];

    const CACHE_CAPAS = "tedflix:cw-covers:v1";
    const lerCapas = () => {
      try {
        return JSON.parse(localStorage.getItem(CACHE_CAPAS) || "{}") || {};
      } catch (_) {
        return {};
      }
    };
    const salvarCapas = (map) => {
      try {
        const keys = Object.keys(map);
        // limita a 80 capas
        const slim = {};
        keys.slice(0, 80).forEach((k) => {
          slim[k] = map[k];
        });
        localStorage.setItem(CACHE_CAPAS, JSON.stringify(slim));
      } catch (_) {}
    };
    const capas = lerCapas();

    const calcProgresso = (item) => {
      const percent = Number(item.percent ?? item.progresso ?? 0);
      if (Number.isFinite(percent) && percent > 0) return Math.min(99, Math.round(percent));

      let pos = Number(item.positionMs ?? 0);
      let dur = Number(item.durationMs ?? 0);
      // fallback: segundos
      if ((!pos || !dur) && (item.positionSeconds || item.durationSeconds)) {
        pos = Number(item.positionSeconds || 0) * 1000;
        dur = Number(item.durationSeconds || 0) * 1000;
      }
      // fallback: tempo "H:MM:SS" ou "MM:SS" ou segundos puros
      if ((!pos || pos <= 0) && item.tempo) {
        const t = String(item.tempo).trim();
        if (/^\d+$/.test(t)) {
          pos = Number(t) * 1000;
        } else if (t.includes(":")) {
          const p = t.split(":").map((x) => Number(x) || 0);
          if (p.length === 3) pos = (p[0] * 3600 + p[1] * 60 + p[2]) * 1000;
          else if (p.length === 2) pos = (p[0] * 60 + p[1]) * 1000;
        }
      }
      if (pos > 0 && dur > 0) return Math.min(99, Math.max(1, Math.round((pos * 100) / dur)));
      // sem duração conhecida: mostra barra mínima se já assistiu algo
      if (pos >= 10_000) return 5;
      return 0;
    };

    const lerSnapshot = () => {
      try {
        const valor = JSON.parse(window.AndroidPlayer.getContinueWatching() || "[]");
        return Array.isArray(valor) ? valor : [];
      } catch (_) {
        return [];
      }
    };

    const localSnapshot = lerSnapshot();
    let itens = localSnapshot;
    if (window.AndroidPlayer.refreshContinueWatching) {
      await new Promise((resolve) => {
        let finalizado = false;
        const concluir = () => {
          if (finalizado) return;
          finalizado = true;
          window.__tedflixHistoryReady = null;
          resolve();
        };
        window.__tedflixHistoryReady = concluir;
        try {
          window.AndroidPlayer.refreshContinueWatching();
        } catch (_) {
          concluir();
        }
        // um pouco mais de tempo: refresh agora busca progresso por item
        setTimeout(concluir, 4500);
      });
      const remotoMesclado = lerSnapshot();
      if (remotoMesclado.length) itens = remotoMesclado;
    }

    if (!itens.length) return [];

    const humanizarSlug = (s) =>
      String(s || "")
        .replace(/[-_]+/g, " ")
        .replace(/\b\w/g, (c) => c.toUpperCase())
        .trim();

    const extrairEpMeta = (item) => {
      let temporada = Number(item.temporada || 0) || 0;
      let episodio = Number(item.episodio || 0) || 0;
      const titulo = String(item.titulo || "");
      const slug = String(item.slug || "");
      const epLabelReady = String(item.epLabel || "").trim();

      const tryPatterns = (src) => {
        const patterns = [
          /s(\d{1,2})\s*e(\d{1,3})/i,
          /t(\d{1,2})\s*e(\d{1,3})/i,
          /(\d{1,2})[x×](\d{1,3})/,
        ];
        for (const p of patterns) {
          const m = src.match(p);
          if (m) return { t: Number(m[1]) || 0, e: Number(m[2]) || 0 };
        }
        return null;
      };

      if (!temporada || !episodio) {
        const hit = tryPatterns(titulo) || tryPatterns(slug);
        if (hit) {
          if (!temporada) temporada = hit.t;
          if (!episodio) episodio = hit.e;
        }
      }
      if (!episodio) {
        const m = titulo.match(/^(\d{1,3})\.\s+\S/);
        if (m) episodio = Number(m[1]) || 0;
      }

      let epLabel = epLabelReady;
      if (!epLabel) {
        if (temporada > 0 && episodio > 0) epLabel = `S${temporada}E${episodio}`;
        else if (episodio > 0) epLabel = `E${episodio}`;
      }

      const isEpisode =
        item.isEpisode === true ||
        /epis/i.test(String(item.tipo || "")) ||
        Boolean(item.serieSlug || item.serieCategoria) ||
        episodio > 0;

      // Nome limpo do episódio (sem "4. ")
      let epNome = titulo.replace(/^\d{1,3}\.\s+/, "").trim();
      // Título da série
      let serieTitulo =
        String(item.serieTitulo || "").trim() ||
        (item.serieSlug ? humanizarSlug(item.serieSlug) : "");

      return { temporada, episodio, epLabel, isEpisode, epNome, serieTitulo };
    };

    const montados = await Promise.all(
      itens
        .filter((item) => item && (item.categoria || item.slug || item.titulo || item.filmeId))
        .slice(0, 30)
        .map(async (item) => {
          let categoria = String(item.categoria || "").trim();
          let slug = String(item.slug || "").trim();
          let detalhe = null;
          const cacheKey = `${categoria}:${slug || item.filmeId || item.titulo || ""}`.toLowerCase();
          const meta = extrairEpMeta(item);

          if ((!categoria || !slug) && (item.titulo || item.filmeId)) {
            try {
              const busca = await buscar(item.titulo || item.filmeId);
              const resultados = Array.isArray(busca?.resultados) ? busca.resultados : [];
              const tituloBusca = String(item.titulo || "").trim().toLowerCase();
              const id = String(item.filmeId || "").trim();
              const encontrado =
                resultados.find((candidato) => {
                  const candidatoId = String(
                    candidato.filmeId || candidato.id || candidato._id || "",
                  ).trim();
                  return (
                    (id && candidatoId === id) ||
                    (tituloBusca &&
                      String(candidato.titulo || "").trim().toLowerCase() === tituloBusca)
                  );
                }) || resultados[0];
              if (encontrado) {
                const partes = parseLink(encontrado.link_assistir);
                categoria = categoria || encontrado.categoria || partes.categoria;
                slug = slug || encontrado.slug || partes.slug;
                detalhe = encontrado;
              }
            } catch (_) {}
          }

          const progresso = calcProgresso(item);
          const tipoRaw = item.tipo || detalhe?.tipo || "Filme";
          const isEp = meta.isEpisode || /epis/i.test(String(tipoRaw));

          let titulo = item.titulo || detalhe?.titulo || slug || "Continuar";
          // Card de série: nome da série em destaque; episódio no meta
          if (isEp) {
            titulo =
              meta.serieTitulo ||
              (item.serieSlug ? humanizarSlug(item.serieSlug) : "") ||
              meta.epNome ||
              titulo;
          }

          let imagem =
            item.thumb || item.imagem || detalhe?.imagem || detalhe?.thumb || capas[cacheKey] || "";
          if (imagem && imagem.startsWith("//")) imagem = "https:" + imagem;
          if (!imagem && titulo && titulo !== "Continuar") {
            try {
              const busca = await buscar(meta.serieTitulo || titulo);
              const hit = (busca?.resultados || [])[0];
              imagem = hit?.imagem || hit?.thumb || "";
              if (imagem.startsWith("//")) imagem = "https:" + imagem;
            } catch (_) {}
          }
          if (imagem && cacheKey) capas[cacheKey] = imagem;

          const serieCategoria = String(item.serieCategoria || "").trim();
          const serieSlug = String(item.serieSlug || "").trim();

          // Link: sempre tela de informações (nunca player direto)
          let link_assistir;
          if (isEp && String(categoria).toLowerCase() === "noflix") {
            const m = String(slug || "").match(/^serie-(\d+)-(\d+)-(\d+)(?:-(dub|leg))?/i);
            if (m) {
              link_assistir = `#/episodio/noflix/${m[1]}/${m[2]}/${m[3]}?audio=${m[4] || "dub"}`;
            } else if (meta.temporada && meta.episodio) {
              const id = String(item.filmeId || "").split("-")[0] || slug;
              link_assistir = `#/episodio/noflix/${encodeURIComponent(id)}/${meta.temporada}/${meta.episodio}?audio=dub`;
            } else {
              link_assistir = `#/noflix/serie/${encodeURIComponent(item.filmeId || slug)}`;
            }
          } else if (isEp && categoria && slug) {
            const q = new URLSearchParams({
              t: String(meta.temporada || 1),
              e: String(meta.episodio || 1),
              serieCategoria: serieCategoria || categoria,
              serieSlug: serieSlug || "",
              filmeId: String(item.filmeId || slug),
              thumb: imagem || "",
              titulo: titulo || "",
            });
            link_assistir = `#/episodio/${encodeURIComponent(categoria)}/${encodeURIComponent(slug)}?${q}`;
          } else if (categoria && slug) {
            link_assistir = `#/titulo/filme/${categoria}/${slug}`;
          } else {
            link_assistir = item.link_assistir || "#/";
          }
          const link_detalhe = link_assistir;

          // Meta: "S2E4 · 45% assistido" ou só porcentagem
          const partesMeta = [];
          if (isEp && meta.epLabel) partesMeta.push(meta.epLabel);
          if (isEp && meta.epNome && meta.epNome !== titulo) {
            // opcional: nome curto do ep
          }
          if (progresso > 0) partesMeta.push(`${progresso}% assistido`);
          else partesMeta.push("Continuar");

          return {
            titulo,
            imagem,
            categoria: categoria || "filme",
            slug: slug || String(item.filmeId || "").trim(),
            filmeId: item.filmeId || slug,
            tipo: isEp ? "episodio" : tipoRaw,
            progresso,
            continuarTexto: partesMeta.join(" · "),
            badgeExtra: isEp && meta.epLabel ? meta.epLabel : null,
            link_assistir,
            link_detalhe,
            serieCategoria,
            serieSlug,
            temporada: meta.temporada,
            episodio: meta.episodio,
            epLabel: meta.epLabel,
            isEpisode: isEp,
            updatedAt: Number(item.updatedAt || 0),
          };
        }),
    );

    // Dedup forte: série por serieSlug/titulo; filme por slug/filmeId/titulo
    const vistos = new Set();
    const cards = [];
    // ordena por updatedAt desc (mais recente primeiro)
    const ordenados = [...montados].sort(
      (a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0),
    );
    for (const c of ordenados) {
      if (!c || !(c.slug || c.filmeId || c.titulo)) continue;
      const tituloNorm = String(c.titulo || "")
        .toLowerCase()
        .replace(/\s+/g, " ")
        .trim();
      const keys = [];
      if (c.isEpisode || c.tipo === "episodio") {
        if (c.serieSlug) keys.push(`serie:${c.serieSlug}`);
        if (tituloNorm) keys.push(`serie-titulo:${tituloNorm}`);
        if (c.filmeId) keys.push(`serie-fid:${c.filmeId}`);
      } else {
        if (c.categoria && c.slug) keys.push(`item:${c.categoria}:${c.slug}`);
        if (c.filmeId) keys.push(`fid:${c.filmeId}`);
        if (c.slug) keys.push(`slug:${c.slug}`);
        if (tituloNorm) keys.push(`titulo:${tituloNorm}`);
      }
      if (!keys.length) keys.push(`raw:${c.slug || c.filmeId || tituloNorm}`);
      if (keys.some((k) => vistos.has(k.toLowerCase()))) continue;
      keys.forEach((k) => vistos.add(k.toLowerCase()));
      cards.push(c);
    }

    // Limpa títulos e enriquece capas (com timeout — nunca trava a home)
    for (const c of cards) {
      if (c.titulo) {
        const limpo = limparTituloTmdb(c.titulo, c.serieSlug || c.slug);
        if (limpo && limpo !== c.titulo) c.titulo = limpo;
      }
      // Agrupa visualmente: "Nome da série · S2E4" (um card por série)
      if (c.isEpisode || c.tipo === "episodio" || Number(c.temporada) > 0) {
        const epLabel =
          c.epLabel ||
          (Number(c.temporada) > 0 && Number(c.episodio) > 0
            ? `S${c.temporada}E${c.episodio}`
            : "");
        // Remove sufixo T1E5 / S1E5 do título se existir
        let nome = String(c.titulo || "")
          .replace(/\s*[Tt]\s*\d+\s*[Ee]\s*\d+.*$/u, "")
          .replace(/\s*[Ss]\s*\d+\s*[Ee]\s*\d+.*$/u, "")
          .replace(/\s*[-–—:]\s*$/u, "")
          .trim();
        if (epLabel && nome) {
          c.titulo = `${nome} · ${epLabel}`;
          c.badgeExtra = epLabel;
          c.continuarTexto = c.progresso
            ? `${c.progresso}% · ${epLabel}`
            : epLabel;
        }
        c.tipo = "serie";
        c.isEpisode = true;
      }
    }

    const withTimeout = (p, ms) =>
      Promise.race([
        p,
        new Promise((resolve) => setTimeout(() => resolve(null), ms)),
      ]);

    try {
      await withTimeout(enriquecerListaTmdb(cards, "filme"), 8000);
    } catch (_) {}

    // Capas de episódio via /tmdb/serie/:id/temporada/:n (limitado)
    try {
      const semCapa = cards.filter(
        (c) =>
          c &&
          !String(c.imagem || "").trim() &&
          (c.isEpisode || c.tipo === "episodio" || (Number(c.temporada) > 0 && Number(c.episodio) > 0)),
      ).slice(0, 6);
      for (const c of semCapa) {
        let sid = extrairTmdbId(c);
        if (!sid) {
          const meta = await withTimeout(
            resolverTmdbMeta(
              { titulo: c.titulo, slug: c.serieSlug || c.slug, serieSlug: c.serieSlug },
              "serie",
            ),
            5000,
          );
          sid = meta?.tmdb_id || 0;
          if (sid) {
            c.tmdb_id = sid;
            c.idtmdb = sid;
          }
        }
        if (!sid) continue;
        const temp = Number(c.temporada) || 1;
        const epn = Number(c.episodio) || 0;
        if (!epn) continue;
        const eps = await withTimeout(getTmdbEpisodiosTemporada(sid, temp), 5000);
        const hit = (eps || []).find((e) => Number(e.numero) === epn);
        if (hit?.imagem) {
          c.imagem = hit.imagem;
          c.thumb = hit.imagem;
        }
        if (
          hit?.titulo &&
          (/^\d/.test(String(c.titulo || "")) || /epis[oó]dio/i.test(String(c.titulo || "")))
        ) {
          c.titulo = hit.titulo;
        }
      }
    } catch (_) {}

    // Fallback final Continuar: capa da série se o ep ainda estiver sem arte
    for (const c of cards) {
      if (String(c.imagem || "").trim()) continue;
      const serieKey = `${c.serieCategoria || c.categoria || ""}:${c.serieSlug || ""}`.toLowerCase();
      const fromCache =
        (c.serieSlug && capas[serieKey]) ||
        capas[`${c.categoria || ""}:${c.serieSlug || ""}`.toLowerCase()] ||
        "";
      // se enriquecerListaTmdb/resolverTmdbMeta já setou capa no item "série", usa
      if (fromCache) {
        c.imagem = fromCache;
        c.thumb = fromCache;
      }
    }

    for (const c of cards) {
      if (c.imagem && (c.slug || c.filmeId)) {
        const ck = `${c.categoria || ""}:${c.slug || c.filmeId}`.toLowerCase();
        capas[ck] = c.imagem;
      }
    }

    salvarCapas(capas);
    return cards;
  } catch (_) {
    return [];
  }
}
