import { el } from "../dom.js";
import { hero } from "../components/hero.js";
import { fileira } from "../components/row.js";
import {
  getCarousel,
  getUltimosFilmes,
  buscar,
  parseLink,
  getLancamentos,
  getSeries,
  getGenero,
  getTedtopTelao,
  getTedtopBilheteria,
  enriquecerListaTmdb,
  enriquecerComTmdb,
  limparTituloTmdb,
} from "../api.js";
import { CATEGORIAS } from "../config.js";

/**
 * Home estilo Netflix:
 * 1. Hero / destaques
 * 2. Continuar assistindo (destaque)
 * 3. Em cartaz / Bilheteria (TEDTOP)
 * 4. Lançamentos, séries, gêneros (CONTENT)
 */
export default async function paginaInicio(raiz) {
  const page = el("div", { class: "page home-netflix" });
  const topo = el("div", { class: "hero skel" });
  page.append(topo);
  raiz.append(page);

  // Continuar assistindo — prioridade Netflix (logo abaixo do hero)
  const continuar = await carregarContinuarAssistindo();
  if (continuar.length) {
    page.append(
      fileira({
        titulo: "Continuar assistindo",
        carregar: async () => continuar,
        limite: 20,
        variante: "continuar",
      }),
    );
  }

  // TEDTOP — Em cartaz / bilheteria (segunda API visível na home)
  page.append(
    fileira({
      titulo: "Em cartaz",
      carregar: async () => { const d = await getTedtopTelao(1); return d.itens || []; },
      limite: 18,
      variante: "tedtop",
    }),
    fileira({
      titulo: "Bilheteria",
      carregar: async () => normalizarTedtop(await getTedtopBilheteria()),
      limite: 18,
      variante: "tedtop",
    }),
  );

  // CONTENT — catálogo principal
  page.append(
    fileira({ titulo: "Últimos filmes", carregar: getUltimosFilmes, limite: 24 }),
    fileira({
      titulo: "Lançamentos",
      verTudo: "#/categoria/lancamentos",
      carregar: getLancamentos,
      limite: 24,
    }),
    fileira({
      titulo: "Séries",
      verTudo: "#/series",
      carregar: async () => (await getSeries()).slice(0, 24),
      limite: 24,
    }),
  );

  CATEGORIAS.slice(0, 6).forEach((c) => {
    page.append(
      fileira({
        titulo: c.label,
        verTudo: `#/categoria/${c.slug}`,
        carregar: async () => (await getGenero(c.slug)).slice(0, 24),
        limite: 24,
      }),
    );
  });

  try {
    const destaques = await getCarousel();
    const h = hero(destaques);
    topo.replaceWith(h);
    page.destruir = () => h.destruir?.();
  } catch (e) {
    topo.classList.remove("skel");
    topo.append(el("div", { class: "center" }, "Não foi possível carregar os destaques."));
  }

  return page;
}

/** Normaliza itens TEDTOP para o card (slug + imagem https + rota de detalhe). */
function normalizarTedtop(lista) {
  const itens = Array.isArray(lista) ? lista : [];
  return itens
    .map((item) => {
      const slug = String(item.slug || "").trim();
      let imagem = String(item.imagem || item.thumb || item.poster || "").trim();
      if (imagem.startsWith("//")) imagem = `https:${imagem}`;
      const categoria = String(item.categoria || "destaque").trim() || "destaque";
      return {
        ...item,
        titulo: item.titulo || slug,
        slug,
        categoria,
        imagem,
        tipo: item.tipo || "Filme",
        ano: item.ano || "",
        link_assistir: item.link_assistir || `#/titulo/filme/${categoria}/${slug}`,
        origem: "tedtop",
        badgeExtra: item.trailer || item.tem_trailer ? "Trailer" : null,
      };
    })
    .filter((i) => i.slug || i.titulo);
}

async function carregarContinuarAssistindo() {
  try {
    if (!window.AndroidPlayer?.getContinueWatching) return [];

    const CACHE_CAPAS = "tedflix:cw-covers:v1";
    const lerCapas = () => {
      try {
        return JSON.parse(localStorage.getItem(CACHE_CAPAS) || "{}") || {};
      } catch (_) {
        return {};
      }
    };
    const salvarCapas = (map) => {
      try {
        const keys = Object.keys(map);
        // limita a 80 capas
        const slim = {};
        keys.slice(0, 80).forEach((k) => {
          slim[k] = map[k];
        });
        localStorage.setItem(CACHE_CAPAS, JSON.stringify(slim));
      } catch (_) {}
    };
    const capas = lerCapas();

    const calcProgresso = (item) => {
      const percent = Number(item.percent ?? item.progresso ?? 0);
      if (Number.isFinite(percent) && percent > 0) return Math.min(99, Math.round(percent));

      let pos = Number(item.positionMs ?? 0);
      let dur = Number(item.durationMs ?? 0);
      // fallback: segundos
      if ((!pos || !dur) && (item.positionSeconds || item.durationSeconds)) {
        pos = Number(item.positionSeconds || 0) * 1000;
        dur = Number(item.durationSeconds || 0) * 1000;
      }
      // fallback: tempo "H:MM:SS" ou "MM:SS" ou segundos puros
      if ((!pos || pos <= 0) && item.tempo) {
        const t = String(item.tempo).trim();
        if (/^\d+$/.test(t)) {
          pos = Number(t) * 1000;
        } else if (t.includes(":")) {
          const p = t.split(":").map((x) => Number(x) || 0);
          if (p.length === 3) pos = (p[0] * 3600 + p[1] * 60 + p[2]) * 1000;
          else if (p.length === 2) pos = (p[0] * 60 + p[1]) * 1000;
        }
      }
      if (pos > 0 && dur > 0) return Math.min(99, Math.max(1, Math.round((pos * 100) / dur)));
      // sem duração conhecida: mostra barra mínima se já assistiu algo
      if (pos >= 10_000) return 5;
      return 0;
    };

    const lerSnapshot = () => {
      try {
        const valor = JSON.parse(window.AndroidPlayer.getContinueWatching() || "[]");
        return Array.isArray(valor) ? valor : [];
      } catch (_) {
        return [];
      }
    };

    const localSnapshot = lerSnapshot();
    let itens = localSnapshot;
    if (window.AndroidPlayer.refreshContinueWatching) {
      await new Promise((resolve) => {
        let finalizado = false;
        const concluir = () => {
          if (finalizado) return;
          finalizado = true;
          window.__tedflixHistoryReady = null;
          resolve();
        };
        window.__tedflixHistoryReady = concluir;
        try {
          window.AndroidPlayer.refreshContinueWatching();
        } catch (_) {
          concluir();
        }
        // um pouco mais de tempo: refresh agora busca progresso por item
        setTimeout(concluir, 4500);
      });
      const remotoMesclado = lerSnapshot();
      if (remotoMesclado.length) itens = remotoMesclado;
    }

    if (!itens.length) return [];

    const humanizarSlug = (s) =>
      String(s || "")
        .replace(/[-_]+/g, " ")
        .replace(/\b\w/g, (c) => c.toUpperCase())
        .trim();

    const extrairEpMeta = (item) => {
      let temporada = Number(item.temporada || 0) || 0;
      let episodio = Number(item.episodio || 0) || 0;
      const titulo = String(item.titulo || "");
      const slug = String(item.slug || "");
      const epLabelReady = String(item.epLabel || "").trim();

      const tryPatterns = (src) => {
        const patterns = [
          /s(\d{1,2})\s*e(\d{1,3})/i,
          /t(\d{1,2})\s*e(\d{1,3})/i,
          /(\d{1,2})[x×](\d{1,3})/,
        ];
        for (const p of patterns) {
          const m = src.match(p);
          if (m) return { t: Number(m[1]) || 0, e: Number(m[2]) || 0 };
        }
        return null;
      };

      if (!temporada || !episodio) {
        const hit = tryPatterns(titulo) || tryPatterns(slug);
        if (hit) {
          if (!temporada) temporada = hit.t;
          if (!episodio) episodio = hit.e;
        }
      }
      if (!episodio) {
        const m = titulo.match(/^(\d{1,3})\.\s+\S/);
        if (m) episodio = Number(m[1]) || 0;
      }

      let epLabel = epLabelReady;
      if (!epLabel) {
        if (temporada > 0 && episodio > 0) epLabel = `S${temporada}E${episodio}`;
        else if (episodio > 0) epLabel = `E${episodio}`;
      }

      const isEpisode =
        item.isEpisode === true ||
        /epis/i.test(String(item.tipo || "")) ||
        Boolean(item.serieSlug || item.serieCategoria) ||
        episodio > 0;

      // Nome limpo do episódio (sem "4. ")
      let epNome = titulo.replace(/^\d{1,3}\.\s+/, "").trim();
      // Título da série
      let serieTitulo =
        String(item.serieTitulo || "").trim() ||
        (item.serieSlug ? humanizarSlug(item.serieSlug) : "");

      return { temporada, episodio, epLabel, isEpisode, epNome, serieTitulo };
    };

    const montados = await Promise.all(
      itens
        .filter((item) => item && (item.categoria || item.slug || item.titulo || item.filmeId))
        .slice(0, 30)
        .map(async (item) => {
          let categoria = String(item.categoria || "").trim();
          let slug = String(item.slug || "").trim();
          let detalhe = null;
          const cacheKey = `${categoria}:${slug || item.filmeId || item.titulo || ""}`.toLowerCase();
          const meta = extrairEpMeta(item);

          if ((!categoria || !slug) && (item.titulo || item.filmeId)) {
            try {
              const busca = await buscar(item.titulo || item.filmeId);
              const resultados = Array.isArray(busca?.resultados) ? busca.resultados : [];
              const tituloBusca = String(item.titulo || "").trim().toLowerCase();
              const id = String(item.filmeId || "").trim();
              const encontrado =
                resultados.find((candidato) => {
                  const candidatoId = String(
                    candidato.filmeId || candidato.id || candidato._id || "",
                  ).trim();
                  return (
                    (id && candidatoId === id) ||
                    (tituloBusca &&
                      String(candidato.titulo || "").trim().toLowerCase() === tituloBusca)
                  );
                }) || resultados[0];
              if (encontrado) {
                const partes = parseLink(encontrado.link_assistir);
                categoria = categoria || encontrado.categoria || partes.categoria;
                slug = slug || encontrado.slug || partes.slug;
                detalhe = encontrado;
              }
            } catch (_) {}
          }

          const progresso = calcProgresso(item);
          const tipoRaw = item.tipo || detalhe?.tipo || "Filme";
          const isEp = meta.isEpisode || /epis/i.test(String(tipoRaw));

          let titulo = item.titulo || detalhe?.titulo || slug || "Continuar";
          // Card de série: nome da série em destaque; episódio no meta
          if (isEp) {
            titulo =
              meta.serieTitulo ||
              (item.serieSlug ? humanizarSlug(item.serieSlug) : "") ||
              meta.epNome ||
              titulo;
          }

          let imagem =
            item.thumb || item.imagem || detalhe?.imagem || detalhe?.thumb || capas[cacheKey] || "";
          if (imagem && imagem.startsWith("//")) imagem = "https:" + imagem;
          if (!imagem && titulo && titulo !== "Continuar") {
            try {
              const busca = await buscar(meta.serieTitulo || titulo);
              const hit = (busca?.resultados || [])[0];
              imagem = hit?.imagem || hit?.thumb || "";
              if (imagem.startsWith("//")) imagem = "https:" + imagem;
            } catch (_) {}
          }
          if (imagem && cacheKey) capas[cacheKey] = imagem;

          const serieCategoria = String(item.serieCategoria || "").trim();
          const serieSlug = String(item.serieSlug || "").trim();

          // Link: episódio → player; filme → detalhe
          let link_assistir;
          if (isEp && categoria && slug) {
            const q = new URLSearchParams({
              filmeId: String(item.filmeId || slug),
              thumb: imagem || "",
              tipo: "episodio",
              serieCategoria: serieCategoria || categoria,
              serieSlug: serieSlug || "",
            });
            if (meta.temporada) q.set("temporada", String(meta.temporada));
            if (meta.episodio) q.set("episodio", String(meta.episodio));
            link_assistir = `#/assistir/${encodeURIComponent(categoria)}/${encodeURIComponent(slug)}?${q}`;
          } else if (categoria && slug) {
            link_assistir = `#/titulo/filme/${categoria}/${slug}`;
          } else {
            link_assistir = item.link_assistir || "#/";
          }

          // Meta: "S2E4 · 45% assistido" ou só porcentagem
          const partesMeta = [];
          if (isEp && meta.epLabel) partesMeta.push(meta.epLabel);
          if (isEp && meta.epNome && meta.epNome !== titulo) {
            // opcional: nome curto do ep
          }
          if (progresso > 0) partesMeta.push(`${progresso}% assistido`);
          else partesMeta.push("Continuar");

          return {
            titulo,
            imagem,
            categoria: categoria || "filme",
            slug: slug || String(item.filmeId || "").trim(),
            filmeId: item.filmeId || slug,
            tipo: isEp ? "episodio" : tipoRaw,
            progresso,
            continuarTexto: partesMeta.join(" · "),
            badgeExtra: isEp && meta.epLabel ? meta.epLabel : null,
            link_assistir,
            serieCategoria,
            serieSlug,
            temporada: meta.temporada,
            episodio: meta.episodio,
            epLabel: meta.epLabel,
            isEpisode: isEp,
            updatedAt: Number(item.updatedAt || 0),
          };
        }),
    );

    // Dedup forte: série por serieSlug/titulo; filme por slug/filmeId/titulo
    const vistos = new Set();
    const cards = [];
    // ordena por updatedAt desc (mais recente primeiro)
    const ordenados = [...montados].sort(
      (a, b) => Number(b.updatedAt || 0) - Number(a.updatedAt || 0),
    );
    for (const c of ordenados) {
      if (!c || !(c.slug || c.filmeId || c.titulo)) continue;
      const tituloNorm = String(c.titulo || "")
        .toLowerCase()
        .replace(/\s+/g, " ")
        .trim();
      const keys = [];
      if (c.isEpisode || c.tipo === "episodio") {
        if (c.serieSlug) keys.push(`serie:${c.serieSlug}`);
        if (tituloNorm) keys.push(`serie-titulo:${tituloNorm}`);
        if (c.filmeId) keys.push(`serie-fid:${c.filmeId}`);
      } else {
        if (c.categoria && c.slug) keys.push(`item:${c.categoria}:${c.slug}`);
        if (c.filmeId) keys.push(`fid:${c.filmeId}`);
        if (c.slug) keys.push(`slug:${c.slug}`);
        if (tituloNorm) keys.push(`titulo:${tituloNorm}`);
      }
      if (!keys.length) keys.push(`raw:${c.slug || c.filmeId || tituloNorm}`);
      if (keys.some((k) => vistos.has(k.toLowerCase()))) continue;
      keys.forEach((k) => vistos.add(k.toLowerCase()));
      cards.push(c);
    }

    // Limpa títulos sujos e busca capa no TMDB
    for (const c of cards) {
      if (c.titulo) {
        const limpo = limparTituloTmdb(c.titulo, c.serieSlug || c.slug);
        if (limpo && limpo !== c.titulo) c.titulo = limpo;
      }
    }
    await enriquecerListaTmdb(
      cards.map((c) => {
        // força tipo série quando for episódio
        if (c.isEpisode || c.tipo === "episodio") return Object.assign(c, { tipo: "serie" });
        return c;
      }),
      "filme",
    );
    for (const c of cards) {
      if (c.imagem && (c.slug || c.filmeId)) {
        const ck = `${c.categoria || ""}:${c.slug || c.filmeId}`.toLowerCase();
        capas[ck] = c.imagem;
      }
    }

    salvarCapas(capas);
    return cards;
  } catch (_) {
    return [];
  }
}
