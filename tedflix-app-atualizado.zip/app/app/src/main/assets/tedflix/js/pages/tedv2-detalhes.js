import { el, limpar, svgIcone } from "../dom.js";
import {
  getTedv2Movie,
  getTedv2Series,
  getTedv2Season,
} from "../api.js";
import { lerFavorito, toggleFavorito, abrirPlayerNativo } from "../playback.js";

/**
 * Detalhe TEDFLIX API v2
 * Filme: catalog/movie/:tmdb → stream/movie/:imdb
 * Série: catalog/series/:tmdb → seasons → stream/series/:imdb/season/t/episode/e
 *
 * Player: categoria "tedv2"
 *   filme-{imdb}-{dub|sub}
 *   serie-{imdb}-{temp}-{ep}-{dub|sub}
 */

function playTedv2({ imdb, titulo, thumb, filmeId, lang = "dub", temp, ep, tipo }) {
  const a = lang === "leg" || lang === "sub" ? "sub" : "dub";
  const id = String(imdb || "").trim();
  if (!id) return false;
  let slug;
  if (tipo === "serie" || (temp != null && ep != null)) {
    slug = `serie-${id}-${temp}-${ep}-${a}`;
  } else {
    slug = `filme-${id}-${a}`;
  }
  return abrirPlayerNativo({
    categoria: "tedv2",
    slug,
    titulo: titulo || "",
    filmeId: filmeId || slug,
    thumb: thumb || "",
    tipo: temp != null ? "episodio" : "filme",
    serieCategoria: "tedv2",
    serieSlug: id,
  });
}

function metaLinha(parts) {
  return parts.filter(Boolean).join(" · ");
}

function blocoGeneros(genres) {
  const list = Array.isArray(genres) ? genres : [];
  if (!list.length) return null;
  const wrap = el("div", { class: "tedv2-tags" });
  list.forEach((g) => {
    const nome = typeof g === "string" ? g : g?.name || "";
    if (!nome) return;
    wrap.append(el("span", { class: "tedv2-tag" }, nome));
  });
  return wrap.childNodes.length ? wrap : null;
}

function blocoElenco(cast) {
  const list = Array.isArray(cast) ? cast : [];
  if (!list.length) return null;
  const section = el("div", { class: "tedv2-cast-section" });
  section.append(el("h2", { class: "tedv2-section-title" }, "Elenco"));
  const rail = el("div", { class: "tedv2-cast-rail" });
  list.slice(0, 14).forEach((c) => {
    const card = el("div", { class: "tedv2-cast-card" });
    if (c.profile) {
      card.append(
        el("img", {
          class: "tedv2-cast-photo",
          src: c.profile,
          alt: c.name || "",
          loading: "lazy",
          decoding: "async",
        }),
      );
    } else {
      card.append(el("div", { class: "tedv2-cast-photo tedv2-cast-photo--empty" }));
    }
    card.append(el("p", { class: "tedv2-cast-name" }, c.name || "—"));
    if (c.character) {
      card.append(el("p", { class: "tedv2-cast-role" }, c.character));
    }
    rail.append(card);
  });
  section.append(rail);
  return section;
}

export async function paginaTedv2Filme(raiz, tmdbId) {
  const page = el("div", { class: "page page-detail page-tedv2" });
  raiz.append(page);
  page.append(el("div", { class: "center detail-loading" }, [el("div", { class: "spinner" })]));

  let dados;
  try {
    dados = await getTedv2Movie(tmdbId);
  } catch (_) {
    dados = null;
  }
  limpar(page);
  if (!dados) {
    page.append(el("p", { class: "center pad" }, "Não foi possível carregar este filme."));
    return page;
  }

  const imdb = dados.imdb || "";
  const titulo = dados.titulo || dados.title || "Filme";
  const capa = dados.banner || dados.backdrop || dados.capa || dados.poster || "";
  const filmeId = `tedv2-${dados.tmdb || tmdbId}`;
  let favorito = lerFavorito(filmeId, String(dados.tmdb || tmdbId), "tedv2");

  const hero = el("div", { class: "detail-hero" });
  if (capa) {
    hero.append(
      el("img", {
        src: capa,
        alt: titulo,
        class: "detail-hero-img",
        decoding: "async",
      }),
    );
  }
  hero.append(el("div", { class: "veil" }));
  page.append(hero);

  const info = el("div", { class: "detail-info pad" });
  info.append(el("h1", {}, titulo));
  info.append(
    el(
      "p",
      { class: "sub tedv2-meta" },
      metaLinha([
        dados.vote_average != null ? `★ ${Number(dados.vote_average).toFixed(1)}` : "",
        "Filme",
        dados.year || dados.ano || "",
        dados.runtime ? `${dados.runtime} min` : "",
      ]),
    ),
  );

  const acoes = el("div", { class: "detail-actions tedv2-actions" });
  const btnDub = el("button", { type: "button", class: "btn primary" }, "▶ Assistir dublado");
  const btnLeg = el("button", { type: "button", class: "btn ghost" }, "▶ Assistir legendado");
  const btnFav = el(
    "button",
    { type: "button", class: "btn ghost" },
    favorito ? "♥ Na lista" : "♡ Favorito",
  );

  btnDub.addEventListener("click", () => {
    if (!imdb) {
      alert("Este título ainda não tem ID IMDb para reproduzir.");
      return;
    }
    if (!playTedv2({ imdb, titulo, thumb: capa, filmeId, lang: "dub", tipo: "filme" })) {
      alert("Player indisponível neste aparelho.");
    }
  });
  btnLeg.addEventListener("click", () => {
    if (!imdb) {
      alert("Este título ainda não tem ID IMDb para reproduzir.");
      return;
    }
    if (!playTedv2({ imdb, titulo, thumb: capa, filmeId, lang: "sub", tipo: "filme" })) {
      alert("Player indisponível neste aparelho.");
    }
  });
  btnFav.addEventListener("click", () => {
    favorito = toggleFavorito({
      filmeId,
      slug: String(dados.tmdb || tmdbId),
      categoria: "tedv2",
      titulo,
      thumb: capa,
      tipo: "filme",
    });
    btnFav.textContent = favorito ? "♥ Na lista" : "♡ Favorito";
  });

  if (imdb) acoes.append(btnDub, btnLeg);
  else acoes.append(el("p", { class: "sub" }, "Reprodução indisponível (sem IMDb)."));
  acoes.append(btnFav);
  info.append(acoes);

  if (dados.sinopse || dados.overview) {
    info.append(el("p", { class: "detail-sinopse" }, dados.sinopse || dados.overview));
  }

  const gens = blocoGeneros(dados.genres);
  if (gens) info.append(gens);

  const elenco = blocoElenco(dados.cast);
  if (elenco) info.append(elenco);

  page.append(info);
  return page;
}

export async function paginaTedv2Serie(raiz, tmdbId) {
  const page = el("div", { class: "page page-detail page-tedv2" });
  raiz.append(page);
  page.append(el("div", { class: "center detail-loading" }, [el("div", { class: "spinner" })]));

  let dados;
  try {
    dados = await getTedv2Series(tmdbId);
  } catch (_) {
    dados = null;
  }
  limpar(page);
  if (!dados) {
    page.append(el("p", { class: "center pad" }, "Não foi possível carregar esta série."));
    return page;
  }

  const imdb = dados.imdb || "";
  const titulo = dados.titulo || dados.title || "Série";
  const capa = dados.banner || dados.backdrop || dados.capa || dados.poster || "";
  const filmeId = `tedv2-${dados.tmdb || tmdbId}`;
  let favorito = lerFavorito(filmeId, String(dados.tmdb || tmdbId), "tedv2");

  const hero = el("div", { class: "detail-hero" });
  if (capa) {
    hero.append(
      el("img", {
        src: capa,
        alt: titulo,
        class: "detail-hero-img",
        decoding: "async",
      }),
    );
  }
  hero.append(el("div", { class: "veil" }));
  page.append(hero);

  const info = el("div", { class: "detail-info pad" });
  info.append(el("h1", {}, titulo));
  info.append(
    el(
      "p",
      { class: "sub tedv2-meta" },
      metaLinha([
        dados.vote_average != null ? `★ ${Number(dados.vote_average).toFixed(1)}` : "",
        "Série",
        dados.year || dados.ano || "",
        dados.number_of_seasons ? `${dados.number_of_seasons} temp.` : "",
      ]),
    ),
  );

  const btnFav = el(
    "button",
    { type: "button", class: "btn ghost" },
    favorito ? "♥ Na lista" : "♡ Favorito",
  );
  btnFav.addEventListener("click", () => {
    favorito = toggleFavorito({
      filmeId,
      slug: String(dados.tmdb || tmdbId),
      categoria: "tedv2",
      titulo,
      thumb: capa,
      tipo: "serie",
    });
    btnFav.textContent = favorito ? "♥ Na lista" : "♡ Favorito";
  });
  info.append(el("div", { class: "detail-actions tedv2-actions" }, [btnFav]));

  if (dados.sinopse || dados.overview) {
    info.append(el("p", { class: "detail-sinopse" }, dados.sinopse || dados.overview));
  }

  const gens = blocoGeneros(dados.genres);
  if (gens) info.append(gens);

  const elenco = blocoElenco(dados.cast);
  if (elenco) info.append(elenco);

  page.append(info);

  // Temporadas
  const seasons = (dados.seasons || []).filter((s) => Number(s.season_number) > 0);
  const epSection = el("div", { class: "pad detail-eps tedv2-eps" });
  epSection.append(el("h2", { class: "tedv2-section-title" }, "Episódios"));
  const tabs = el("div", { class: "tedv2-season-tabs", role: "tablist" });
  const list = el("div", { class: "tedv2-ep-list" });
  epSection.append(tabs, list);
  page.append(epSection);

  let currentSeason = seasons[0]?.season_number || 1;

  async function carregarTemp(n) {
    currentSeason = n;
    [...tabs.querySelectorAll(".tedv2-season-tab")].forEach((b) => {
      b.classList.toggle("ativo", Number(b.dataset.s) === n);
      b.setAttribute("aria-selected", Number(b.dataset.s) === n ? "true" : "false");
    });
    limpar(list);
    list.append(el("div", { class: "center" }, [el("div", { class: "spinner" })]));
    let eps = [];
    try {
      const data = await getTedv2Season(tmdbId, n);
      eps = data.episodes || [];
    } catch (_) {
      eps = [];
    }
    limpar(list);
    if (!eps.length) {
      list.append(el("p", { class: "sub" }, "Nenhum episódio encontrado."));
      return;
    }
    eps.forEach((ep) => {
      const num = ep.episode_number != null ? ep.episode_number : "?";
      const nome = ep.name || `Episódio ${num}`;
      const row = el("div", { class: "tedv2-ep-row" });
      const still = ep.still || capa || "";
      if (still) {
        row.append(
          el("img", {
            class: "tedv2-ep-thumb",
            src: still,
            alt: "",
            loading: "lazy",
          }),
        );
      }
      const body = el("div", { class: "tedv2-ep-body" });
      body.append(el("strong", { class: "tedv2-ep-title" }, `E${num} · ${nome}`));
      if (ep.overview) {
        body.append(
          el("p", { class: "sub tedv2-ep-overview" }, String(ep.overview).slice(0, 140)),
        );
      }
      row.append(body);
      const play = el(
        "button",
        { type: "button", class: "tedv2-ep-play", "aria-label": "Assistir" },
        "▶",
      );
      play.addEventListener("click", () => {
        if (!imdb) {
          alert("Esta série ainda não tem ID IMDb para reproduzir.");
          return;
        }
        if (
          !playTedv2({
            imdb,
            titulo: `${titulo} — T${n}E${num}`,
            thumb: ep.still || capa,
            filmeId: `tedv2-${tmdbId}-t${n}e${num}`,
            lang: "dub",
            temp: n,
            ep: num,
            tipo: "serie",
          })
        ) {
          alert("Player indisponível neste aparelho.");
        }
      });
      row.append(play);
      list.append(row);
    });
  }

  seasons.forEach((s) => {
    const n = s.season_number;
    const b = el(
      "button",
      {
        type: "button",
        class: "tedv2-season-tab",
        "data-s": String(n),
        role: "tab",
        "aria-selected": "false",
      },
      `T${n}`,
    );
    b.addEventListener("click", () => carregarTemp(n));
    tabs.append(b);
  });
  if (seasons.length) carregarTemp(currentSeason);
  else list.append(el("p", { class: "sub" }, "Sem temporadas."));

  return page;
}

export default async function paginaTedv2Detalhe(raiz, { tipo, id }) {
  if (tipo === "serie" || tipo === "series") return paginaTedv2Serie(raiz, id);
  return paginaTedv2Filme(raiz, id);
}
