import { el, limpar, svgIcone } from "../dom.js";
import {
  enriquecerComTmdb,
  getTmdbEpisodiosTemporada,
  extrairTmdbId,
  lookupTmdbById,
  limparTituloTmdb,
} from "../api.js";
import { backdrop, poster } from "../img.js";

function abrirPlayerNativo(opts) {
  if (window.AndroidPlayer && typeof window.AndroidPlayer.openPlayer === "function") {
    window.AndroidPlayer.openPlayer(
      opts.categoria || "",
      opts.slug || "",
      opts.titulo || "",
      "[]",
      opts.filmeId || opts.slug || "",
      opts.thumb || "",
      opts.tipo || "",
      opts.serieCategoria || "",
      opts.serieSlug || "",
      "[]",
      "[]",
    );
    return true;
  }
  return false;
}

function lerProgressoEp({ categoria, slug, filmeId }) {
  try {
    const itens = JSON.parse(window.AndroidPlayer?.getContinueWatching?.() || "[]");
    const list = Array.isArray(itens) ? itens : [];
    const hit = list.find((i) => {
      if (categoria && slug && i.categoria === categoria && i.slug === slug) return true;
      if (filmeId && String(i.filmeId || "") === String(filmeId)) return true;
      return false;
    });
    if (!hit) return { percent: 0, positionMs: 0, durationMs: 0 };
    let percent = Number(hit.percent ?? hit.progresso ?? 0);
    const pos = Number(hit.positionMs || 0);
    const dur = Number(hit.durationMs || 0);
    if ((!percent || percent <= 0) && pos > 0 && dur > 0) {
      percent = Math.min(99, Math.max(1, Math.round((pos * 100) / dur)));
    }
    return { percent: Math.min(99, Math.max(0, percent)), positionMs: pos, durationMs: dur };
  } catch (_) {
    return { percent: 0, positionMs: 0, durationMs: 0 };
  }
}

function lerFavorito(filmeId, slug = "") {
  try {
    const resposta = JSON.parse(window.AndroidPlayer?.getFavorites?.() || "{}");
    const lista = resposta.favoritos || resposta.favorites || [];
    if (!Array.isArray(lista)) return false;
    const id = String(filmeId || "").trim();
    const s = String(slug || "").trim().toLowerCase();
    return lista.some((item) => {
      const iid = String(item.filmeId || item.contentId || item.id || "").trim();
      const is = String(item.slug || "").trim().toLowerCase();
      if (id && iid && id === iid) return true;
      if (s && is && s === is) return true;
      return false;
    });
  } catch (_) {
    return false;
  }
}

/**
 * Tela de informações de um episódio (NoFlix ou CONTENT).
 * Reprodução só após toque explícito em Assistir / Continuar.
 */
export default async function paginaEpisodioInfo(raiz, params) {
  const {
    fonte = "noflix",
    idtmdb = "",
    temporada = 1,
    episodio = 1,
    audio = "dub",
    categoria = "",
    slug = "",
    serieCategoria = "",
    serieSlug = "",
    serieTitulo = "",
    filmeId = "",
    thumb = "",
  } = params || {};

  const page = el("div", { class: "page page-ep-info" });
  raiz.append(page);

  // Voltar sempre visível desde o 1º frame
  const voltar = el("button", {
    class: "back",
    type: "button",
    "aria-label": "Voltar",
    onclick: () => {
      if (fonte === "noflix" && idtmdb) {
        location.hash = `#/noflix/serie/${encodeURIComponent(idtmdb)}`;
        return;
      }
      if (serieCategoria && serieSlug) {
        location.hash = `#/titulo/serie/${encodeURIComponent(serieCategoria)}/${encodeURIComponent(serieSlug)}`;
        return;
      }
      history.back();
    },
  });
  voltar.innerHTML = svgIcone("back");
  page.append(voltar);
  page.append(el("div", { class: "center detail-loading" }, [el("div", { class: "spinner" })]));

  const temp = Number(temporada) || 1;
  const epn = Number(episodio) || 1;
  let tituloSerie = serieTitulo || "";
  let tituloEp = `Episódio ${epn}`;
  let sinopse = "";
  let capa = thumb || "";
  let banner = "";
  let nota = null;
  let runtime = null;

  // Resolve meta
  try {
    if (fonte === "noflix" && idtmdb) {
      const sid = Number(idtmdb);
      const [serieMeta, eps] = await Promise.all([
        lookupTmdbById(sid, "serie").catch(() => null),
        getTmdbEpisodiosTemporada(sid, temp).catch(() => []),
      ]);
      if (serieMeta) {
        tituloSerie = serieMeta.titulo || tituloSerie;
        if (!capa) capa = serieMeta.capa || "";
        banner = serieMeta.banner || capa;
      }
      const hit = (eps || []).find((e) => Number(e.numero) === epn);
      if (hit) {
        if (hit.titulo) tituloEp = hit.titulo;
        if (hit.imagem) capa = hit.imagem;
        // sinopse não vem na rota enxuta — ok
      }
      if (!tituloSerie) tituloSerie = "Série";
    } else {
      // CONTENT: tenta TMDB pelo título da série
      const base = {
        titulo: serieTitulo || slug,
        slug: serieSlug || slug,
        tipo: "serie",
      };
      await enriquecerComTmdb(base, "serie");
      tituloSerie = limparTituloTmdb(base.titulo || serieTitulo || "", serieSlug || slug) || "Série";
      if (!capa) capa = base.imagem || base.capa || "";
      banner = base.banner || capa;
      const tid = extrairTmdbId(base);
      if (tid) {
        const eps = await getTmdbEpisodiosTemporada(tid, temp).catch(() => []);
        const hit = (eps || []).find((e) => Number(e.numero) === epn);
        if (hit) {
          if (hit.titulo) tituloEp = hit.titulo;
          if (hit.imagem) capa = hit.imagem;
        }
      }
    }
  } catch (_) {}

  const playCategoria = fonte === "noflix" ? "noflix" : categoria || serieCategoria || "";
  const playSlug =
    fonte === "noflix"
      ? `serie-${idtmdb}-${temp}-${epn}-${audio || "dub"}`
      : slug;
  const playFilmeId =
    fonte === "noflix" ? `${idtmdb}-t${temp}e${epn}` : filmeId || slug;
  const prog = lerProgressoEp({
    categoria: playCategoria,
    slug: playSlug,
    filmeId: playFilmeId,
  });

  limpar(page);
  page.append(voltar);

  const heroSrc = banner || capa;
  const hero = el("div", { class: "detail-hero ep-hero" });
  if (heroSrc) {
    hero.append(
      el("img", {
        src: backdrop(heroSrc, 780) || poster(capa, "lg") || heroSrc,
        alt: "",
        loading: "eager",
        onerror: "this.remove()",
      }),
    );
  } else {
    hero.append(el("div", { class: "thumb-placeholder thumb-placeholder--hero", "aria-hidden": "true" }));
  }
  hero.append(el("div", { class: "detail-hero-fade" }));
  page.append(hero);

  const corpo = el("div", { class: "pad ep-info-body" });
  corpo.append(el("p", { class: "sub" }, tituloSerie));
  corpo.append(
    el("h1", {}, `T${temp}E${epn} · ${tituloEp}`),
  );
  if (nota != null) corpo.append(el("p", { class: "tags" }, `★ ${nota}`));
  if (sinopse) corpo.append(el("p", { class: "sub", style: "line-height:1.45;margin-top:8px" }, sinopse));
  else corpo.append(el("p", { class: "sub", style: "margin-top:8px" }, "Sinopse indisponível para este episódio."));

  if (prog.percent > 0) {
    corpo.append(
      el("div", { class: "ep-progress-block", style: "margin-top:16px" }, [
        el("p", { class: "sub" }, `${prog.percent}% assistido`),
        el("div", { class: "ep-progress ep-progress--lg" }, [
          el("span", { style: `width:${prog.percent}%` }),
        ]),
      ]),
    );
  }

  let favorito = lerFavorito(playFilmeId, playSlug);
  const favoritoBtn = el(
    "button",
    {
      class: `btn ghost${favorito ? " ativo" : ""}`,
      type: "button",
    },
    favorito ? "♥ Favorito" : "♡ Favoritar",
  );
  favoritoBtn.addEventListener("click", async () => {
    if (!window.AndroidPlayer?.toggleFavorite) return;
    try {
      const resposta = JSON.parse(
        window.AndroidPlayer.toggleFavorite(
          playFilmeId,
          `${tituloSerie} T${temp}E${epn}`,
          capa || "",
          "episodio",
        ) || "{}",
      );
      if (!resposta.success) throw new Error(resposta.error || "Erro ao salvar");
      favorito = typeof resposta.favorito === "boolean" ? resposta.favorito : !favorito;
      favoritoBtn.textContent = favorito ? "♥ Favorito" : "♡ Favoritar";
      favoritoBtn.classList.toggle("ativo", favorito);
    } catch (e) {
      favoritoBtn.textContent = e.message || "Erro";
      setTimeout(() => {
        favoritoBtn.textContent = favorito ? "♥ Favorito" : "♡ Favoritar";
      }, 1600);
    }
  });

  const playLabel = prog.percent > 0 ? "▶ Continuar assistindo" : "▶ Assistir";
  const playBtn = el("button", { class: "btn primary", type: "button" }, playLabel);
  playBtn.addEventListener("click", () => {
    const tituloPlay = `${tituloSerie} T${temp}E${epn}`;
    if (
      abrirPlayerNativo({
        categoria: playCategoria,
        slug: playSlug,
        titulo: tituloPlay,
        thumb: capa || "",
        tipo: fonte === "noflix" ? "noflix" : "episodio",
        filmeId: playFilmeId,
        serieCategoria: serieCategoria || categoria || "",
        serieSlug: serieSlug || "",
      })
    ) {
      return;
    }
    location.hash = `#/assistir/${encodeURIComponent(playCategoria)}/${encodeURIComponent(playSlug)}`;
  });

  corpo.append(
    el("div", { style: "display:flex;gap:10px;margin-top:18px;flex-wrap:wrap" }, [
      playBtn,
      favoritoBtn,
    ]),
  );
  page.append(corpo);
  return page;
}
