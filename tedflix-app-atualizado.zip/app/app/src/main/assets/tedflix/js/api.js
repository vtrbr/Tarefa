import { API_BASE, TEDTOP_API_BASE, LIVE_API_BASE, NOFLIX_API_BASE, TMDB_HELPER_BASE } from "./config.js";

/* Cache em memória + deduplicação de requisições.
   Os endpoints "/stream" devolvem o catálogo inteiro (megabytes), então
   nunca são baixados duas vezes na mesma sessão. */
const cache = new Map();
const emVoo = new Map();

const TTL_CURTO = 5 * 60 * 1000;
const TTL_LONGO = 30 * 60 * 1000;
const CACHE_PREFIX = "tedflix:catalog-cache:v2:";

/** Limpa cache de catálogo (memória + localStorage) para forçar dados frescos. */
export function limparCacheCatalogo() {
  cache.clear();
  try {
    const keys = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(CACHE_PREFIX)) keys.push(k);
    }
    keys.forEach((k) => localStorage.removeItem(k));
  } catch (_) {}
}

const CACHE_MAX_BYTES = 1_800_000;

function lerCachePersistente(chave) {
  try {
    const item = JSON.parse(localStorage.getItem(CACHE_PREFIX + chave) || "null");
    return item && item.t && item.v !== undefined ? item : null;
  } catch (_) { return null; }
}

function salvarCachePersistente(chave, valor) {
  try {
    const texto = JSON.stringify({ t: Date.now(), v: valor });
    if (texto.length <= CACHE_MAX_BYTES) localStorage.setItem(CACHE_PREFIX + chave, texto);
  } catch (_) { /* quota cheia: o cache em memória continua válido */ }
}

async function getJSON(caminho, ttl = TTL_CURTO, base = API_BASE) {
  const chave = `${base}${caminho}`;
  const agora = Date.now();
  const guardado = cache.get(chave);
  if (guardado && agora - guardado.t < ttl) return guardado.v;
  const persistido = lerCachePersistente(chave);
  if (persistido && agora - persistido.t < ttl) {
    cache.set(chave, persistido);
    return persistido.v;
  }
  if (emVoo.has(chave)) return emVoo.get(chave);

  const p = fetch(`${base}${caminho}`)
    .then((r) => {
      if (!r.ok) throw new Error(`Falha ao carregar (${r.status})`);
      return r.json();
    })
    .then((v) => {
      cache.set(chave, { t: Date.now(), v });
      salvarCachePersistente(chave, v);
      emVoo.delete(chave);
      return v;
    })
    .catch((e) => {
      emVoo.delete(chave);
      if (persistido?.v !== undefined) return persistido.v;
      throw e;
    });

  emVoo.set(chave, p);
  return p;
}

/** O scraper às vezes duplica o título ("XyzXyz") — limpa isso. */
export function limparTitulo(t) {
  const s = (t || "").trim();
  if (!s) return "";
  const meio = s.length / 2;
  if (s.length % 2 === 0 && s.slice(0, meio) === s.slice(meio)) return s.slice(0, meio);
  return s.replace(/^Assistir\s+/i, "").replace(/\s+Online Grátis$/i, "");
}

export function normalizar(item, tipoPadrao) {
  const tipo = item.tipo || tipoPadrao;
  let imagem = String(item.imagem || item.capa || item.thumb || item.poster || "").trim();
  if (imagem.startsWith("//")) imagem = "https:" + imagem;
  let banner = String(item.banner || "").trim();
  if (banner.startsWith("//")) banner = "https:" + banner;
  return {
    ...item,
    titulo: limparTitulo(item.titulo),
    imagem: imagem || item.imagem,
    capa: imagem || item.capa,
    thumb: imagem || item.thumb,
    banner: banner || imagem || item.banner,
    ...(tipo ? { tipo } : {}),
  };
}

export function parseLink(link) {
  if (!link) return { categoria: "", slug: "" };
  const partes = link.replace(/^https?:\/\/[^/]+/, "").split("/").filter(Boolean);
  return { categoria: partes[partes.length - 2] || "", slug: partes[partes.length - 1] || "" };
}

export function ehSerie(item) {
  const t = (item.tipo || "").toLowerCase();
  return t.includes("séri") || t.includes("serie");
}

/** Rota de detalhes de um item da API. */
export function rotaDetalhe(item) {
  // Alguns itens reconstruídos do histórico usam uma rota hash de fallback.
  // Respeite-a diretamente em vez de tentar interpretá-la como link de CDN.
  if (typeof item.link_assistir === "string" && item.link_assistir.startsWith("#/")) {
    return item.link_assistir;
  }
  const p = parseLink(item.link_assistir);
  const episodioDeSerie = Boolean(item.serieSlug || item.serieCategoria);
  const tipo = ehSerie(item) || episodioDeSerie ? "serie" : "filme";
  const categoria = episodioDeSerie ? item.serieCategoria : (item.categoria || p.categoria);
  const slug = episodioDeSerie ? item.serieSlug : (item.slug || p.slug);
  return `#/titulo/${tipo}/${categoria}/${slug}`;
}

/* ---------------- HOME ---------------- */

export const getCarousel = () =>
  getJSON("/home/carousel", TTL_LONGO).then((d) => (d.itens || []).map((i) => normalizar(i)));

export const getUltimosFilmes = async () => {
  try {
    const d = await getJSON("/home/ultimos-filmes", TTL_CURTO);
    const filmes = Array.isArray(d.filmes) ? d.filmes : Array.isArray(d.resultados) ? d.resultados : [];
    if (filmes.length) return filmes.map((i) => normalizar(i, "Filme"));
  } catch (_) {
    // Não baixar o catálogo inteiro (/filmes/stream) como fallback — é lento e pesado.
  }
  try {
    const d = await getJSON("/home/lancamentos", TTL_CURTO);
    const itens = d.lancamentos || d.filmes || d.resultados || d.itens || [];
    return (Array.isArray(itens) ? itens : []).slice(0, 30).map((i) => normalizar(i, "Filme"));
  } catch (_) {
    return [];
  }
};

export const getAgenda = () => getJSON("/home/agenda").then((d) => d.dias || []);

/* ---------------- CATÁLOGOS ---------------- */

export const getFilmes = () =>
  getJSON("/filmes/stream", TTL_LONGO).then((d) => (d.filmes || []).map((i) => normalizar(i, "Filme")));

export const getSeries = () =>
  getJSON("/series/stream", TTL_LONGO).then((d) => (d.series || []).map((i) => normalizar(i, "Série")));

export const getAnimacoes = () =>
  getJSON("/animacoes/stream", TTL_LONGO).then((d) =>
    (d.animacoes || d.resultados || []).map((i) => normalizar(i, "Filme")),
  );

export const getGenero = (slug) => {
  if (slug === "animacao") return getAnimacoes();
  return getJSON(`/genero/${slug}/stream`, TTL_LONGO).then((d) =>
    (d.resultados || []).map((i) => normalizar(i, "Filme")),
  );
};

/** Lançamentos oficiais da Home, retornados pelo endpoint dedicado. */
export const getLancamentos = () =>
  getJSON("/home/lancamentos", TTL_LONGO).then((d) => {
    const itens = d.lancamentos || d.filmes || d.resultados || d.itens || [];
    return (Array.isArray(itens) ? itens : []).map((item) => normalizar(item));
  });

/* ---------------- BUSCA ---------------- */

export const buscar = async (q, pagina = 1) => {
  const termo = String(q || "").trim();
  // Busca paralela: catálogo Tedflix + NoFlix (DUB/LEG)
  const [ted, nox] = await Promise.all([
    getJSON(`/buscar/${encodeURIComponent(termo)}?pagina=${pagina}`)
      .then((d) => ({
        resultados: (d.resultados || []).map((i) => normalizar(i)),
        totalPaginas: d.total_paginas || 1,
      }))
      .catch(() => ({ resultados: [], totalPaginas: 1 })),
    buscarNoflix(termo, 40).catch(() => ({ resultados: [] })),
  ]);
  const vistos = new Set();
  const resultados = [];
  // Tedflix primeiro, depois NoFlix (evita duplicar por título+ano)
  for (const item of [...(ted.resultados || []), ...(nox.resultados || [])]) {
    const key = `${String(item.titulo || "").toLowerCase()}|${item.ano || ""}|${item.fonte || "ted"}`;
    if (vistos.has(key)) continue;
    vistos.add(key);
    resultados.push(item);
  }
  return { resultados, totalPaginas: ted.totalPaginas || 1 };
};

/* ---------------- DETALHES ---------------- */

export const getTitulo = async (categoria, slug, tipo = "filme") => {
  if (String(tipo).toLowerCase().includes("séri") || String(tipo).toLowerCase().includes("serie")) {
    // CONTENT é a autoridade de séries/temporadas. Busca é complementar.
    const [temporadas, busca] = await Promise.all([
      getJSON(`/series/serie/${categoria}/${slug}/temporadas`, TTL_LONGO),
      buscar(slug).catch(() => ({ resultados: [] })),
    ]);
    const item =
      (busca.resultados || []).find((i) => String(i.link_assistir || "").includes(`/${slug}`)) ||
      (busca.resultados || []).find((i) => String(i.slug || "") === String(slug)) ||
      busca.resultados?.[0] ||
      {};
    return {
      ...item,
      titulo: limparTitulo(item.titulo || temporadas.serie || slug),
      categoria: temporadas.categoria || categoria,
      slug: temporadas.slug || slug,
      tipo: "Série",
      imagem: item.imagem || item.thumb || "",
      temporadas: temporadas.temporadas || [],
      total_temporadas: temporadas.total_temporadas || (temporadas.temporadas || []).length,
      recomendados: (item.recomendados || []).map((i) => normalizar(i)),
    };
  }
  return getJSON(`/filmes/filme/${categoria}/${slug}`, TTL_LONGO).then((d) => ({
    ...d,
    titulo: limparTitulo(d.titulo),
    categoria: d.categoria || categoria,
    slug: d.slug || slug,
    recomendados: (d.recomendados || []).map((i) => normalizar(i)),
  }));
};

export const getTemporadas = (categoria, slug) =>
  getJSON(`/series/serie/${categoria}/${slug}/temporadas`, TTL_LONGO).then((d) => d.temporadas || []);

export const getEpisodios = (categoria, slug, numero) =>
  getJSON(`/series/serie/${categoria}/${slug}/temporada/${numero}/episodios`, TTL_LONGO).then(
    (d) => d.episodios || [],
  );

/* ---------------- PLAYER (CONTENT API) ---------------- */

/** Texto puro do manifest .m3u8 (reprodução direta pelo CDN). */
export async function getManifesto(categoria, slug) {
  const r = await fetch(`${API_BASE}/filmes/filme-player/${categoria}/${slug}`);
  if (!r.ok) throw new Error("Este título está indisponível no momento.");
  const texto = await r.text();
  if (!texto.includes("#EXTM3U")) throw new Error("Fonte de vídeo inválida.");
  return texto;
}

/* ============================================================
   TEDTOP API — conteúdo complementar, trailers, ingresso
   Todas as rotas são públicas (sem autenticação).
   ============================================================ */

/** Extrai o videoId de uma URL de YouTube (vários formatos). */
export function extrairYoutubeId(url) {
  if (!url || typeof url !== "string") return null;
  const s = url.trim();
  // //www.youtube.com/watch?v=ID  |  https://www.youtube.com/watch?v=ID&t=10s
  // https://youtu.be/ID  |  https://www.youtube.com/embed/ID
  const m =
    s.match(/[?&]v=([^&#]+)/) ||
    s.match(/youtu\.be\/([^?&#]+)/) ||
    s.match(/youtube\.com\/embed\/([^?&#]+)/) ||
    s.match(/youtube\.com\/shorts\/([^?&#]+)/);
  return m ? m[1] : null;
}


/* ---------------- TEDTOP API (pública, sem auth) ---------------- */

/** Normaliza item TEDTOP para o card/detalhe interno. */
export function normalizarTedtopItem(item = {}) {
  let imagem = String(item.imagem || item.thumb || item.poster || "").trim();
  if (imagem.startsWith("//")) imagem = "https:" + imagem;
  const slug = String(item.slug || "").trim();
  const categoria = String(item.categoria || "destaque").trim() || "destaque";
  return {
    ...item,
    titulo: item.titulo || slug,
    slug,
    categoria,
    imagem,
    ano: item.ano || "",
    nota: item.nota != null ? Number(item.nota) : undefined,
    tipo: item.tipo || "Filme",
    genero: item.genero || item.genero_nome || "",
    link_assistir: item.link_assistir || `#/titulo/filme/${categoria}/${slug}`,
    origem: "tedtop",
  };
}

function listaTedtop(d) {
  const arr = d?.filmes || d?.destaques || d?.resultados || d?.itens || d?.data || [];
  return (Array.isArray(arr) ? arr : []).map(normalizarTedtopItem);
}

/** Telão / destaques */
export const getTedtopTelao = (pagina = 1) =>
  getJSON(`/telao?pagina=${pagina}`, TTL_LONGO, TEDTOP_API_BASE).then((d) => ({
    pagina: d.pagina || pagina,
    total: d.total,
    itens: listaTedtop(d),
  }));

/** Bilheteria */
export const getTedtopBilheteria = () =>
  getJSON(`/bilheteria`, TTL_LONGO, TEDTOP_API_BASE).then((d) => listaTedtop(d));

/** Por ano — GET /sessao/ano/:ano (não filtrar localmente) */
export const getTedtopPorAno = (ano, pagina = 1) =>
  getJSON(`/sessao/ano/${encodeURIComponent(ano)}?pagina=${pagina}`, TTL_LONGO, TEDTOP_API_BASE).then((d) => ({
    ano: d.ano || ano,
    pagina: d.pagina || pagina,
    total: d.total,
    itens: listaTedtop(d),
  }));

/** Por letra — GET /alfabeto/:letra (não usar /buscar) */
export const getTedtopPorLetra = (letra, pagina = 1) => {
  const L = String(letra || "A").toUpperCase().slice(0, 1);
  return getJSON(`/alfabeto/${encodeURIComponent(L)}?pagina=${pagina}`, TTL_LONGO, TEDTOP_API_BASE).then((d) => ({
    letra: d.letra || L,
    pagina: d.pagina || pagina,
    total: d.total,
    itens: listaTedtop(d),
  }));
};

/** Por gênero TEDTOP — GET /generos/:genero */
export const getTedtopPorGenero = (genero, pagina = 1) =>
  getJSON(`/generos/${encodeURIComponent(genero)}?pagina=${pagina}`, TTL_LONGO, TEDTOP_API_BASE).then((d) => ({
    genero: d.genero || genero,
    pagina: d.pagina || pagina,
    total: d.total,
    itens: listaTedtop(d),
  }));

/** Radar ao vivo — GET /radar/live/:termo */
export const getTedtopRadar = (termo) =>
  getJSON(`/radar/live/${encodeURIComponent(termo)}`, TTL_CURTO, TEDTOP_API_BASE).then((d) => {
    // API pode devolver string anti-leecher ou lista
    if (typeof d.resultados === "string") {
      return { termo: d.termo || termo, itens: [], aviso: d.resultados };
    }
    return { termo: d.termo || termo, itens: listaTedtop(d) };
  });

/** Detalhes TEDTOP — GET /filme/:slug */
export async function getTedtopFilme(slug) {
  if (!slug) return null;
  try {
    const d = await getJSON(`/filme/${encodeURIComponent(slug)}`, TTL_LONGO, TEDTOP_API_BASE);
    if (!d) return null;
    return normalizarTedtopItem({
      ...d,
      descricao: d.sinopse || d.descricao || "",
      trailer: d.trailer || "",
      recomendados: (d.recomendados || []).map(normalizarTedtopItem),
    });
  } catch (_) {
    return null;
  }
}

/**
 * Link direto TEDTOP (pode expirar). Não persistir.
 * GET /ingresso/:slug
 */
export async function getTedtopIngresso(slug) {
  if (!slug) return null;
  try {
    return await getJSON(`/ingresso/${encodeURIComponent(slug)}`, 5 * 60 * 1000, TEDTOP_API_BASE);
  } catch (_) {
    return null;
  }
}



/* ---------------- CANAIS AO VIVO — Rei dos Canais API v2 ----------------
 * Base: https://api.reidoscanais.st
 * Docs: GET /  → endpoints
 *   GET /channels
 *   GET /channels/{id}
 *   GET /channels/categories
 *   GET /channels?category={nome}
 *   GET /sports
 *   GET /sports/{id}
 *   GET /sports?status={upcoming|live|finished}
 *   GET /sports?category={nome}
 *   GET /search?q={termo}
 * Público, sem auth.
 * --------------------------------------------------------------------- */

function urlHttpValida(url) {
  try {
    const parsed = new URL(String(url || ""));
    return parsed.protocol === "http:" || parsed.protocol === "https:";
  } catch (_) {
    return false;
  }
}

function normalizarEmbeds(lista) {
  return (Array.isArray(lista) ? lista : [])
    .map((embed) => ({
      provider: String(embed?.provider || "Servidor"),
      quality: String(embed?.quality || "Automático"),
      embed_url: String(embed?.embed_url || "").trim(),
    }))
    .filter((embed) => urlHttpValida(embed.embed_url));
}

export function normalizarCanal(item = {}) {
  let logo = String(item.logo_url || item.logo || item.poster || "").trim();
  if (logo.startsWith("//")) logo = "https:" + logo;
  return {
    id: String(item.id || ""),
    titulo: String(item.name || item.title || "Canal ao vivo"),
    descricao: String(item.description || ""),
    logo,
    categoria: String(item.category || "Outros"),
    embeds: normalizarEmbeds(item.embeds),
    epg: item.epg || {},
    aoVivo: true,
    tipo: "canal",
  };
}

export function normalizarEvento(item = {}) {
  let logo = String(item.poster || item.logo || item.logo_url || "").trim();
  if (logo.startsWith("//")) logo = "https:" + logo;
  const status = String(item.status || "").toLowerCase();
  return {
    id: String(item.id || ""),
    titulo: String(item.title || "Evento"),
    descricao: String(item.description || ""),
    logo,
    categoria: String(item.category || item.competition || "Esportes"),
    embeds: normalizarEmbeds(item.embeds),
    epg: { current: { title: item.competition || item.title || "Evento" } },
    aoVivo: status === "live",
    status,
    teams: item.teams || null,
    start_time: item.start_time || "",
    tipo: "evento",
  };
}

/** Lista canais (opcionalmente por categoria nome exata da API). */
export const getCanais = (categoria = "") => {
  const caminho = categoria
    ? `/channels?category=${encodeURIComponent(categoria)}`
    : "/channels";
  // TTL curto: lista muda (canais novos)
  return getJSON(caminho, 2 * 60 * 1000, LIVE_API_BASE).then((d) =>
    (Array.isArray(d?.data) ? d.data : []).map(normalizarCanal),
  );
};

export const getCanalCategorias = () =>
  getJSON("/channels/categories", 10 * 60 * 1000, LIVE_API_BASE).then((d) =>
    (Array.isArray(d?.data) ? d.data : []).map((item) => ({
      id: String(item.id || item.name || ""),
      nome: String(item.name || "Outros"),
    })),
  );

export const getCanal = (id) =>
  getJSON(`/channels/${encodeURIComponent(id)}`, 2 * 60 * 1000, LIVE_API_BASE).then((d) => {
    const raw = d?.data && !Array.isArray(d.data) ? d.data : d?.channel || d;
    return normalizarCanal(raw || {});
  });

/** Eventos: live prioritário; se vazio, traz upcoming+todos. */
export const getEventosAoVivo = async () => {
  try {
    const live = await getJSON("/sports?status=live", 60 * 1000, LIVE_API_BASE);
    const listaLive = (Array.isArray(live?.data) ? live.data : []).map(normalizarEvento);
    if (listaLive.length) return listaLive;
  } catch (_) {}
  try {
    const all = await getJSON("/sports", 60 * 1000, LIVE_API_BASE);
    return (Array.isArray(all?.data) ? all.data : [])
      .map(normalizarEvento)
      .filter((e) => e.status === "live" || e.status === "upcoming" || e.embeds.length > 0);
  } catch (_) {
    return [];
  }
};

export const getEventos = (status = "") => {
  const caminho = status ? `/sports?status=${encodeURIComponent(status)}` : "/sports";
  return getJSON(caminho, 60 * 1000, LIVE_API_BASE).then((d) =>
    (Array.isArray(d?.data) ? d.data : []).map(normalizarEvento),
  );
};

/** Pesquisa global — GET /search?q= */
export const buscarCanais = (q) => {
  const termo = String(q || "").trim();
  if (!termo) return Promise.resolve([]);
  return getJSON(`/search?q=${encodeURIComponent(termo)}`, 60 * 1000, LIVE_API_BASE).then((d) => {
    const payload = d?.data;
    if (Array.isArray(payload)) return payload.map(normalizarCanal);
    const canais = Array.isArray(payload?.channels) ? payload.channels.map(normalizarCanal) : [];
    const eventos = Array.isArray(payload?.events)
      ? payload.events.map(normalizarEvento)
      : Array.isArray(payload?.sports)
        ? payload.sports.map(normalizarEvento)
        : [];
    return [...canais, ...eventos];
  });
};

/* ============================================================
   NOFLIX API — cinema/seriados com DUB/LEG e M3U8
   Base: NOFLIX_API_BASE (servidores-ted-apply3)
   ============================================================ */

/** Corrige texto UTF-8 lido como Latin-1 (Ã©, Ã§, etc.). */
export function corrigirTexto(s) {
  if (!s || typeof s !== "string") return s || "";
  if (!/[ÃÂ]/.test(s)) return s;
  try {
    return decodeURIComponent(escape(s));
  } catch (_) {
    return s;
  }
}

function audioFlags(audio) {
  const a = String(audio || "").toUpperCase();
  const dub = a.includes("DUB");
  const leg = a.includes("LEG");
  let label = "";
  if (dub && leg) label = "DUB e LEG";
  else if (dub) label = "DUB";
  else if (leg) label = "LEG";
  return { temDub: dub, temLeg: leg, label };
}

/** Cache em memória + sessionStorage — a API não busca por idtmdb. */
const _noflixMem = new Map();
const NOFLIX_SS_KEY = "tedflix:noflix:item:";

export function guardarNoflixItem(item) {
  if (!item || !item.idtmdb) return item;
  const id = String(item.idtmdb);
  _noflixMem.set(id, item);
  try {
    sessionStorage.setItem(NOFLIX_SS_KEY + id, JSON.stringify(item));
  } catch (_) {}
  return item;
}

export function lerNoflixItem(idtmdb) {
  const id = String(idtmdb || "").trim();
  if (!id) return null;
  if (_noflixMem.has(id)) return _noflixMem.get(id);
  try {
    const raw = sessionStorage.getItem(NOFLIX_SS_KEY + id);
    if (raw) {
      const parsed = JSON.parse(raw);
      _noflixMem.set(id, parsed);
      return parsed;
    }
  } catch (_) {}
  return null;
}

/** Normaliza item NoFlix para o formato interno do app. */
export function normalizarNoflix(item = {}, tipoForcado) {
  const tipoRaw = tipoForcado || item.tipo || "filme";
  const tipo = String(tipoRaw).toLowerCase().includes("serie") ? "serie" : "filme";
  const idtmdb = String(item.idtmdb || item.id || "").trim();
  const flags = audioFlags(item.audio);
  const titulo = corrigirTexto(item.titulo || "");
  const sinopse = corrigirTexto(item.sinopse || "");
  const categoria = corrigirTexto(item.categoria || "");
  const capa = item.capa || item.imagem || item.poster || "";
  const banner = item.banner || capa || "";
  const out = {
    ...item,
    fonte: "noflix",
    tipo,
    idtmdb,
    titulo,
    sinopse,
    descricao: sinopse,
    capa,
    imagem: capa,
    thumb: capa,
    poster: capa,
    banner,
    nota: item.rating != null && item.rating !== "" ? Number(item.rating) : null,
    ano: item.ano || "",
    categoria,
    audio: item.audio || "",
    temDub: flags.temDub || Boolean(item.player_dub),
    temLeg: flags.temLeg || Boolean(item.player_leg),
    audioLabel: flags.label || null,
    badgeExtra: flags.label || null,
    runtime: item.runtime,
    idioma: corrigirTexto(item.idioma || ""),
    produtora: corrigirTexto(item.produtora || ""),
    total_temporadas: item.total_temporadas,
    player_dub: item.player_dub || "",
    player_leg: item.player_leg || "",
    slug: idtmdb,
    link_assistir: tipo === "serie" ? `#/noflix/serie/${idtmdb}` : `#/noflix/filme/${idtmdb}`,
  };
  // Recomputa label se players existem sem campo audio
  if (!out.audioLabel) {
    if (out.temDub && out.temLeg) out.audioLabel = "DUB e LEG";
    else if (out.temDub) out.audioLabel = "DUB";
    else if (out.temLeg) out.audioLabel = "LEG";
    out.badgeExtra = out.audioLabel;
  }
  return guardarNoflixItem(out);
}

async function getNoflixJSON(caminho) {
  return getJSON(caminho, TTL_CURTO, NOFLIX_API_BASE);
}

export async function buscarNoflix(termo, limite = 40) {
  const q = String(termo || "").trim();
  if (q.length < 2) return { resultados: [] };
  const d = await getNoflixJSON(`/buscar/${encodeURIComponent(q)}?limite=${limite}`);
  const lista = (d.resultados || []).map((i) =>
    normalizarNoflix(i, i.tipo === "serie" ? "serie" : "filme"),
  );
  return { resultados: lista, total: d.total || lista.length };
}

export async function getNoflixFilmeMeta(idtmdb) {
  const id = String(idtmdb || "").trim();
  // 1) Cache (lista/busca já normalizou o item completo)
  const cached = lerNoflixItem(id);
  if (cached && cached.tipo !== "serie") return cached;

  // 2) Procurar por título do cache parcial
  const tituloHint = cached?.titulo;
  if (tituloHint) {
    try {
      const d = await getNoflixJSON(`/cinema/procurar/${encodeURIComponent(tituloHint)}?limite=20`);
      const hit = (d.resultados || d.filmes || []).find((i) => String(i.idtmdb) === id);
      if (hit) return normalizarNoflix(hit, "filme");
    } catch (_) {}
  }

  // 3) Varre listagens (a API não aceita idtmdb em /procurar)
  for (const path of [`/cinema?limite=120`, `/cinema?audio=dub&limite=120`, `/cinema?audio=leg&limite=120`, `/cinema/ted?limite=40`]) {
    try {
      const d = await getNoflixJSON(path);
      const hit = (d.filmes || []).find((i) => String(i.idtmdb) === id);
      if (hit) return normalizarNoflix(hit, "filme");
    } catch (_) {}
  }
  return cached || null;
}

export async function getNoflixSerieMeta(idtmdb) {
  const id = String(idtmdb || "").trim();
  const cached = lerNoflixItem(id);
  if (cached && String(cached.tipo).includes("serie")) return cached;

  // Confirma existência via temporadas (funciona com idtmdb)
  let temps = [];
  try {
    temps = await getNoflixTemporadas(id);
  } catch (_) {}

  const tituloHint = cached?.titulo;
  if (tituloHint) {
    try {
      const d = await getNoflixJSON(`/seriados/procurar/${encodeURIComponent(tituloHint)}?limite=20`);
      const hit = (d.series || d.resultados || []).find((i) => String(i.idtmdb) === id);
      if (hit) return normalizarNoflix(hit, "serie");
    } catch (_) {}
  }

  for (const path of [`/seriados?limite=120`, `/seriados?audio=dub&limite=120`, `/seriados/ted?limite=40`, `/seriados/estreias?limite=40`]) {
    try {
      const d = await getNoflixJSON(path);
      const hit = (d.series || []).find((i) => String(i.idtmdb) === id);
      if (hit) return normalizarNoflix(hit, "serie");
    } catch (_) {}
  }

  // Série existe (tem temporadas) mas sem meta rica — monta mínimo
  if (temps && temps.length) {
    return normalizarNoflix(
      {
        idtmdb: id,
        titulo: cached?.titulo || `Série ${id}`,
        capa: cached?.imagem || temps[0]?.capa || "",
        banner: cached?.banner || temps[0]?.capa || "",
        audio: cached?.audio || "DUB",
        total_temporadas: temps.length,
        tipo: "serie",
      },
      "serie",
    );
  }
  return cached || null;
}

export async function getNoflixTemporadas(idtmdb) {
  const d = await getNoflixJSON(`/seriados/${encodeURIComponent(idtmdb)}/temporadas`);
  return (d.temporadas || []).map((t) => ({
    ...t,
    numero: t.numero,
    titulo: corrigirTexto(t.titulo || `Temporada ${t.numero}`),
    sinopse: corrigirTexto(t.sinopse || ""),
    capa: t.capa || "",
  }));
}

export async function getNoflixEpisodios(idtmdb, temporada) {
  const d = await getNoflixJSON(
    `/seriados/${encodeURIComponent(idtmdb)}/temporada/${encodeURIComponent(temporada)}/episodios`,
  );
  return (d.episodios || []).map((ep) => {
    const flags = audioFlags(ep.audio || (ep.player_dub ? "DUB" : "") + (ep.player_leg ? "|LEG" : ""));
    const temDub = Boolean(ep.player_dub) || flags.temDub;
    const temLeg = Boolean(ep.player_leg) || flags.temLeg;
    let label = "";
    if (temDub && temLeg) label = "DUB e LEG";
    else if (temDub) label = "DUB";
    else if (temLeg) label = "LEG";
    return {
      ...ep,
      titulo: corrigirTexto(ep.titulo_episodio || ep.titulo || `Episódio ${ep.numero}`),
      sinopse: corrigirTexto(ep.sinopse || ""),
      imagem: ep.imagem || "",
      temDub,
      temLeg,
      audioLabel: label,
      runtime: ep.runtime,
    };
  });
}

/** URL do manifesto M3U8 no proxy NoFlix (filme). */
export function noflixFilmeStreamUrl(idtmdb, audio = "dub") {
  const a = String(audio).toLowerCase() === "leg" ? "leg" : "dub";
  return `${NOFLIX_API_BASE}/cinema/assistir/${encodeURIComponent(idtmdb)}/${a}`;
}

/** URL do manifesto M3U8 no proxy NoFlix (episódio). */
export function noflixEpStreamUrl(idtmdb, temporada, episodio, audio = "dub") {
  const a = String(audio || "").toLowerCase();
  const base = `${NOFLIX_API_BASE}/seriados/assistir/${encodeURIComponent(idtmdb)}/${encodeURIComponent(temporada)}/${encodeURIComponent(episodio)}`;
  if (a === "leg" || a === "dub") return `${base}/${a}`;
  return base;
}

/** Lista filmes NoFlix — GET /cinema?audio=dub|leg&limite= */
export async function getNoflixFilmes({ audio = "", limite = 120 } = {}) {
  const q = new URLSearchParams();
  if (limite) q.set("limite", String(limite));
  const a = String(audio || "").toLowerCase();
  if (a === "dub" || a === "leg") q.set("audio", a);
  const qs = q.toString();
  const d = await getNoflixJSON(`/cinema${qs ? `?${qs}` : ""}`);
  const lista = d.filmes || d.resultados || [];
  return lista.map((i) => normalizarNoflix(i, "filme"));
}

/** Lista séries NoFlix — GET /seriados?audio=dub|leg&limite= */
export async function getNoflixSeries({ audio = "", limite = 120 } = {}) {
  const q = new URLSearchParams();
  if (limite) q.set("limite", String(limite));
  const a = String(audio || "").toLowerCase();
  if (a === "dub" || a === "leg") q.set("audio", a);
  const qs = q.toString();
  const d = await getNoflixJSON(`/seriados${qs ? `?${qs}` : ""}`);
  const lista = d.series || d.resultados || [];
  return lista.map((i) => normalizarNoflix(i, "serie"));
}

/** Top / estreias / ano / gênero (extras úteis) */
export async function getNoflixFilmesTed(limite = 15) {
  const d = await getNoflixJSON(`/cinema/ted?limite=${limite}`);
  return (d.filmes || []).map((i) => normalizarNoflix(i, "filme"));
}
export async function getNoflixSeriesTed(limite = 20) {
  const d = await getNoflixJSON(`/seriados/ted?limite=${limite}`);
  return (d.series || []).map((i) => normalizarNoflix(i, "serie"));
}
export async function getNoflixSeriesEstreias(limite = 20) {
  const d = await getNoflixJSON(`/seriados/estreias?limite=${limite}`);
  return (d.series || []).map((i) => normalizarNoflix(i, "serie"));
}

export async function getNoflixFilmesAno(ano, limite = 40) {
  const d = await getNoflixJSON(`/cinema/ano/${encodeURIComponent(ano)}?limite=${limite}`);
  return (d.filmes || []).map((i) => normalizarNoflix(i, "filme"));
}

export async function getNoflixSeriesAno(ano, limite = 40) {
  const d = await getNoflixJSON(`/seriados/ano/${encodeURIComponent(ano)}?limite=${limite}`);
  return (d.series || []).map((i) => normalizarNoflix(i, "serie"));
}

export async function getNoflixFilmesGenero(categoria, limite = 48) {
  const d = await getNoflixJSON(`/cinema/genero/${encodeURIComponent(categoria)}?limite=${limite}`);
  return (d.filmes || []).map((i) => normalizarNoflix(i, "filme"));
}

export async function getNoflixSeriesGenero(categoria, limite = 48) {
  const d = await getNoflixJSON(`/seriados/genero/${encodeURIComponent(categoria)}?limite=${limite}`);
  return (d.series || []).map((i) => normalizarNoflix(i, "serie"));
}

/** Últimos episódios lançados — GET /seriados/ultimos-eps */
export async function getNoflixUltimosEps(limite = 40) {
  const d = await getNoflixJSON(`/seriados/ultimos-eps?limite=${limite}`);
  return (d.episodios || []).map((ep) => {
    const idtmdb = String(ep.idtmdb || "");
    const tituloSerie = corrigirTexto(ep.titulo || "").replace(/\s+\d+x\d+\s*$/i, "").trim();
    const epLabel = `T${ep.temporada}E${ep.numero}`;
    return {
      fonte: "noflix",
      tipo: "serie",
      isEpisode: true,
      idtmdb,
      titulo: corrigirTexto(ep.titulo_episodio || ep.titulo || epLabel),
      tituloSerie: tituloSerie || "Série",
      imagem: ep.imagem || "",
      banner: ep.imagem || "",
      sinopse: corrigirTexto(ep.sinopse || ""),
      temporada: ep.temporada,
      episodioNumero: ep.numero,
      runtime: ep.runtime,
      badgeExtra: epLabel,
      link_assistir: `#/noflix/serie/${idtmdb}`,
      slug: idtmdb,
    };
  });
}

export async function procurarNoflixFilmes(titulo, limite = 40) {
  const d = await getNoflixJSON(`/cinema/procurar/${encodeURIComponent(titulo)}?limite=${limite}`);
  return (d.resultados || d.filmes || []).map((i) => normalizarNoflix(i, "filme"));
}

export async function procurarNoflixSeries(nome, limite = 40) {
  const d = await getNoflixJSON(`/seriados/procurar/${encodeURIComponent(nome)}?limite=${limite}`);
  return (d.series || d.resultados || []).map((i) => normalizarNoflix(i, "serie"));
}


/* ============================================================
   TMDB HELPER — fallback de capa/banner/sinopse
   Base: TMDB_HELPER_BASE (servidor-tmdb.onrender.com)
   Só chama quando a fonte original não trouxe imagem.
   ============================================================ */

const TMDB_LS_KEY = "tedflix:tmdb:meta:v1";
const TMDB_MEM = new Map();

function tmdbCacheKey(titulo, ano, tipo) {
  const t = String(titulo || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim();
  return `${tipo || "filme"}:${t}:${ano || ""}`;
}

function lerTmdbLocal() {
  try {
    return JSON.parse(localStorage.getItem(TMDB_LS_KEY) || "{}") || {};
  } catch (_) {
    return {};
  }
}

function salvarTmdbLocal(map) {
  try {
    const keys = Object.keys(map);
    const slim = {};
    keys.slice(-120).forEach((k) => {
      slim[k] = map[k];
    });
    localStorage.setItem(TMDB_LS_KEY, JSON.stringify(slim));
  } catch (_) {}
}

/**
 * Busca meta no helper TMDB.
 * @returns {Promise<{capa?:string,banner?:string,sinopse?:string,nota?:number,titulo?:string}|null>}
 */
export async function lookupTmdbMeta({ titulo, ano, tipo } = {}) {
  const title = String(titulo || "").trim();
  if (!title || title.length < 2) return null;
  // ignora títulos que são só id numérico
  if (/^\d{4,}$/.test(title)) return null;

  const kind = String(tipo || "filme").toLowerCase().includes("ser") ? "serie" : "filme";
  const year = ano ? String(ano).slice(0, 4) : "";
  const key = tmdbCacheKey(title, year, kind);

  if (TMDB_MEM.has(key)) return TMDB_MEM.get(key);

  const local = lerTmdbLocal();
  if (local[key] && (local[key].capa || local[key].miss)) {
    TMDB_MEM.set(key, local[key].miss ? null : local[key]);
    return local[key].miss ? null : local[key];
  }

  try {
    const q = new URLSearchParams({ titulo: title, tipo: kind });
    if (year) q.set("ano", year);
    const r = await fetch(`${TMDB_HELPER_BASE}/tmdb/lookup?${q}`, {
      signal: AbortSignal.timeout ? AbortSignal.timeout(12000) : undefined,
    });
    if (!r.ok) {
      TMDB_MEM.set(key, null);
      return null;
    }
    const d = await r.json();
    if (!d?.ok || !d.found || !d.capa) {
      local[key] = { miss: true, at: Date.now() };
      salvarTmdbLocal(local);
      TMDB_MEM.set(key, null);
      return null;
    }
    const meta = {
      capa: d.capa || d.capa_sm || "",
      banner: d.banner || d.banner_sm || d.capa || "",
      sinopse: d.sinopse || "",
      nota: d.nota,
      titulo: d.titulo || title,
      tmdb_id: d.tmdb_id,
      ano: d.ano || year,
    };
    local[key] = { ...meta, at: Date.now() };
    salvarTmdbLocal(local);
    TMDB_MEM.set(key, meta);
    return meta;
  } catch (_) {
    TMDB_MEM.set(key, null);
    return null;
  }
}

/**
 * Enriquece item in-place se faltar capa/imagem.
 * Não sobrescreve arte que já existe.
 */
export async function enriquecerComTmdb(item, tipoPadrao) {
  if (!item) return item;
  const temArte = Boolean(
    String(item.imagem || item.capa || item.thumb || item.poster || item.banner || "").trim(),
  );
  if (temArte) return item;

  const titulo = String(item.titulo || item.nome || "").trim();
  if (!titulo) return item;

  let tipo = tipoPadrao || item.tipo || "";
  if (!tipo && (item.serieSlug || item.isEpisode)) tipo = "serie";
  if (!tipo) tipo = "filme";

  const meta = await lookupTmdbMeta({
    titulo,
    ano: item.ano,
    tipo,
  });
  if (!meta?.capa) return item;

  item.imagem = meta.capa;
  item.capa = meta.capa;
  item.thumb = meta.capa;
  item.poster = meta.capa;
  if (meta.banner) item.banner = meta.banner;
  if (meta.sinopse && !item.descricao && !item.sinopse) {
    item.descricao = meta.sinopse;
    item.sinopse = meta.sinopse;
  }
  if (meta.nota != null && (item.nota == null || item.nota === 0)) {
    item.nota = meta.nota;
  }
  if (meta.titulo && (/^\d/.test(titulo) || titulo.length < 3)) {
    item.titulo = meta.titulo;
  }
  return item;
}

/** Enriquece lista (máx. concorrência 4). */
export async function enriquecerListaTmdb(lista, tipoPadrao) {
  const arr = Array.isArray(lista) ? lista : [];
  const fila = arr.filter(
    (i) => i && !String(i.imagem || i.capa || i.thumb || i.poster || "").trim(),
  );
  if (!fila.length) return arr;

  const conc = 4;
  let idx = 0;
  async function worker() {
    while (idx < fila.length) {
      const i = idx++;
      try {
        await enriquecerComTmdb(fila[i], tipoPadrao);
      } catch (_) {}
    }
  }
  await Promise.all(Array.from({ length: Math.min(conc, fila.length) }, () => worker()));
  return arr;
}

