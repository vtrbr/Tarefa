import { API_BASE, TEDTOP_API_BASE, LIVE_API_BASE, NOFLIX_API_BASE, NOFLIX_ENABLED, TMDB_HELPER_BASE, MEGACINE_API_BASE, TEDV2_API_BASE } from "./config.js";

/* Cache em memória + deduplicação de requisições.
   Os endpoints "/stream" devolvem o catálogo inteiro (megabytes), então
   nunca são baixados duas vezes na mesma sessão. */
const cache = new Map();
const emVoo = new Map();

const TTL_CURTO = 20 * 60 * 1000; // 20 min — evita spam ao trocar de aba
const TTL_LONGO = 3 * 60 * 60 * 1000; // 3 h — catálogo/home só atualiza no puxar para atualizar
const CACHE_PREFIX = "tedflix:catalog-cache:v2:";

/** Limpa cache de catálogo (memória + localStorage) para forçar dados frescos. */
export function limparCacheCatalogo() {
  cache.clear();
  try {
    const keys = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(CACHE_PREFIX)) keys.push(k);
    }
    keys.forEach((k) => localStorage.removeItem(k));
  } catch (_) {}
}

const CACHE_MAX_BYTES = 1_800_000;

function lerCachePersistente(chave) {
  try {
    const item = JSON.parse(localStorage.getItem(CACHE_PREFIX + chave) || "null");
    return item && item.t && item.v !== undefined ? item : null;
  } catch (_) { return null; }
}

function salvarCachePersistente(chave, valor) {
  try {
    const texto = JSON.stringify({ t: Date.now(), v: valor });
    if (texto.length <= CACHE_MAX_BYTES) localStorage.setItem(CACHE_PREFIX + chave, texto);
  } catch (_) { /* quota cheia: o cache em memória continua válido */ }
}

async function getJSON(caminho, ttl = TTL_CURTO, base = API_BASE) {
  const chave = `${base}${caminho}`;
  const agora = Date.now();
  const guardado = cache.get(chave);
  if (guardado && agora - guardado.t < ttl) return guardado.v;
  const persistido = lerCachePersistente(chave);
  if (persistido && agora - persistido.t < ttl) {
    cache.set(chave, persistido);
    return persistido.v;
  }
  if (emVoo.has(chave)) return emVoo.get(chave);

  const p = fetch(`${base}${caminho}`)
    .then((r) => {
      if (!r.ok) throw new Error(`Falha ao carregar (${r.status})`);
      return r.json();
    })
    .then((v) => {
      cache.set(chave, { t: Date.now(), v });
      salvarCachePersistente(chave, v);
      emVoo.delete(chave);
      return v;
    })
    .catch((e) => {
      emVoo.delete(chave);
      if (persistido?.v !== undefined) return persistido.v;
      throw e;
    });

  emVoo.set(chave, p);
  return p;
}

/** O scraper às vezes duplica o título ("XyzXyz") — limpa isso. */
export function limparTitulo(t) {
  const s = (t || "").trim();
  if (!s) return "";
  const meio = s.length / 2;
  if (s.length % 2 === 0 && s.slice(0, meio) === s.slice(meio)) return s.slice(0, meio);
  return s.replace(/^Assistir\s+/i, "").replace(/\s+Online Grátis$/i, "");
}

export function normalizar(item, tipoPadrao) {
  const tipo = item.tipo || tipoPadrao;
  let imagem = String(item.imagem || item.capa || item.thumb || item.poster || "").trim();
  if (imagem.startsWith("//")) imagem = "https:" + imagem;
  let banner = String(item.banner || "").trim();
  if (banner.startsWith("//")) banner = "https:" + banner;
  return {
    ...item,
    titulo: limparTitulo(item.titulo),
    imagem: imagem || item.imagem,
    capa: imagem || item.capa,
    thumb: imagem || item.thumb,
    banner: banner || imagem || item.banner,
    ...(tipo ? { tipo } : {}),
  };
}

export function parseLink(link) {
  if (!link) return { categoria: "", slug: "" };
  const partes = link.replace(/^https?:\/\/[^/]+/, "").split("/").filter(Boolean);
  return { categoria: partes[partes.length - 2] || "", slug: partes[partes.length - 1] || "" };
}

export function ehSerie(item) {
  const t = (item.tipo || "").toLowerCase();
  return t.includes("séri") || t.includes("serie");
}

/** Rota de detalhes (nunca abre o player direto). */
export function rotaDetalhe(item) {
  if (!item) return "#/";
  if (item.fonte === "tedv2" || item.origem === "tedv2" || item.categoria === "tedv2") {
    const id = String(item.tmdb || item.idtmdb || item.id || "").trim();
    const isSerie = /serie|séri/i.test(String(item.tipo || item.type || ""));
    if (id) return isSerie ? `#/v2/serie/${encodeURIComponent(id)}` : `#/v2/filme/${encodeURIComponent(id)}`;
  }
  if (item.fonte === "megacine" || item.origem === "megacine" || item.categoria === "megacine") {
    const slug = String(item.slug || "").trim();
    const isSerie = /serie|séri/i.test(String(item.tipo || ""));
    if (slug) return isSerie ? `#/cine/serie/${encodeURIComponent(slug)}` : `#/cine/filme/${encodeURIComponent(slug)}`;
  }

  // Continuar assistindo / cards com rota hash — episódio → info; assistir → detalhe
  if (typeof item.link_detalhe === "string" && item.link_detalhe.startsWith("#/")) {
    return item.link_detalhe;
  }
  if (typeof item.link_assistir === "string" && item.link_assistir.startsWith("#/")) {
    const h = item.link_assistir;
    // Episódio NoFlix no histórico
    if (item.isEpisode || item.tipo === "episodio" || /\/assistir\//.test(h)) {
      if (String(item.categoria || "").toLowerCase() === "noflix" || h.includes("/assistir/noflix/")) {
        const m = String(item.slug || "").match(/^serie-(\d+)-(\d+)-(\d+)(?:-(dub|leg))?/i);
        if (m) {
          const audio = m[4] || "dub";
          return `#/episodio/noflix/${m[1]}/${m[2]}/${m[3]}?audio=${audio}`;
        }
      }
      if (item.temporada && item.episodio && (item.serieSlug || item.serieCategoria)) {
        const q = new URLSearchParams({
          t: String(item.temporada),
          e: String(item.episodio),
          serieCategoria: item.serieCategoria || item.categoria || "",
          serieSlug: item.serieSlug || "",
          filmeId: String(item.filmeId || item.slug || ""),
          thumb: item.imagem || item.thumb || "",
          titulo: item.titulo || "",
        });
        return `#/episodio/${encodeURIComponent(item.categoria || "filme")}/${encodeURIComponent(item.slug || "")}?${q}`;
      }
    }
    // Hash de detalhe legítima (#/titulo/... #/noflix/...)
    if (!h.includes("/assistir/")) return h;
  }
  // NoFlix só quando a fonte for de fato NoFlix (idtmdb sozinho NÃO basta —
  // itens CONTENT enriquecidos com TMDB também têm tmdb_id/idtmdb).
  const fonte = String(item.fonte || item.source || "").toLowerCase();
  const tipoRaw = String(item.tipo || "").toLowerCase();
  const catRaw = String(item.categoria || "").toLowerCase();
  const linkHash = String(item.link_assistir || item.link_detalhe || "");
  const isNoflix =
    fonte === "noflix" ||
    catRaw === "noflix" ||
    tipoRaw === "noflix" ||
    linkHash.includes("#/noflix/") ||
    linkHash.includes("/noflix/");
  if (isNoflix && (item.idtmdb || item.tmdb_id || /^\d+$/.test(String(item.slug || "")))) {
    const id = item.idtmdb || item.tmdb_id || item.slug;
    const isSerie = ehSerie(item) || tipoRaw.includes("serie") || tipoRaw.includes("séri") || item.isEpisode;
    return isSerie
      ? `#/noflix/serie/${encodeURIComponent(id)}`
      : `#/noflix/filme/${encodeURIComponent(id)}`;
  }
  const parsed = parseLink(item.link_assistir);
  const episodioDeSerie = Boolean(item.serieSlug || item.serieCategoria || item.isEpisode);
  const tipo = ehSerie(item) || episodioDeSerie ? "serie" : "filme";
  const categoria = episodioDeSerie
    ? (item.serieCategoria || item.categoria || parsed.categoria)
    : (item.categoria || parsed.categoria);
  const slug = episodioDeSerie
    ? (item.serieSlug || item.slug || parsed.slug)
    : (item.slug || parsed.slug);
  if (!categoria || !slug) return "#/";
  return `#/titulo/${tipo}/${encodeURIComponent(categoria)}/${encodeURIComponent(slug)}`;
}

/* ---------------- HOME ---------------- */

export const getCarousel = () =>
  getJSON("/home/carousel", TTL_LONGO).then((d) => (d.itens || []).map((i) => normalizar(i)));

export const getUltimosFilmes = async () => {
  try {
    const d = await getJSON("/home/ultimos-filmes", TTL_CURTO);
    const filmes = Array.isArray(d.filmes) ? d.filmes : Array.isArray(d.resultados) ? d.resultados : [];
    if (filmes.length) return filmes.map((i) => normalizar(i, "Filme"));
  } catch (_) {
    // Não baixar o catálogo inteiro (/filmes/stream) como fallback — é lento e pesado.
  }
  try {
    const d = await getJSON("/home/lancamentos", TTL_CURTO);
    const itens = d.lancamentos || d.filmes || d.resultados || d.itens || [];
    return (Array.isArray(itens) ? itens : []).slice(0, 30).map((i) => normalizar(i, "Filme"));
  } catch (_) {
    return [];
  }
};

export async function getAgenda() {
  try {
    const dias = await getMegacineCronograma();
    if (dias && dias.length) return dias;
  } catch (_) {}
  try {
    const d = await getJSON("/home/agenda");
    return d.dias || [];
  } catch (_) {
    return [];
  }
}

/* ---------------- CATÁLOGOS ---------------- */

export const getFilmes = () =>
  getJSON("/filmes/stream", TTL_LONGO).then((d) => (d.filmes || []).map((i) => normalizar(i, "Filme")));

export const getSeries = () =>
  getJSON("/series/stream", TTL_LONGO).then((d) => (d.series || []).map((i) => normalizar(i, "Série")));

export const getAnimacoes = () =>
  getJSON("/animacoes/stream", TTL_LONGO).then((d) =>
    (d.animacoes || d.resultados || []).map((i) => normalizar(i, "Filme")),
  );

export const getGenero = (slug) => {
  if (slug === "animacao") return getAnimacoes();
  return getJSON(`/genero/${slug}/stream`, TTL_LONGO).then((d) =>
    (d.resultados || []).map((i) => normalizar(i, "Filme")),
  );
};

/** Lançamentos oficiais da Home, retornados pelo endpoint dedicado. */
export const getLancamentos = () =>
  getJSON("/home/lancamentos", TTL_LONGO).then((d) => {
    const itens = d.lancamentos || d.filmes || d.resultados || d.itens || [];
    return (Array.isArray(itens) ? itens : []).map((item) => normalizar(item));
  });

/* ---------------- BUSCA ---------------- */

export const buscar = async (q, pagina = 1) => {
  const termo = String(q || "").trim();
  // Busca paralela: catálogo Tedflix + NoFlix (DUB/LEG)
  const [ted, nox] = await Promise.all([
    getJSON(`/buscar/${encodeURIComponent(termo)}?pagina=${pagina}`)
      .then((d) => ({
        resultados: (d.resultados || []).map((i) => normalizar(i)),
        totalPaginas: d.total_paginas || 1,
      }))
      .catch(() => ({ resultados: [], totalPaginas: 1 })),
    buscarNoflix(termo, 40).catch(() => ({ resultados: [] })),
  ]);
  const vistos = new Set();
  const resultados = [];
  // Tedflix primeiro, depois NoFlix (evita duplicar por título+ano)
  for (const item of [...(ted.resultados || []), ...(nox.resultados || [])]) {
    const key = `${String(item.titulo || "").toLowerCase()}|${item.ano || ""}|${item.fonte || "ted"}`;
    if (vistos.has(key)) continue;
    vistos.add(key);
    resultados.push(item);
  }
  return { resultados, totalPaginas: ted.totalPaginas || 1 };
};

/* ---------------- DETALHES ---------------- */

export const getTitulo = async (categoria, slug, tipo = "filme") => {
  if (String(tipo).toLowerCase().includes("séri") || String(tipo).toLowerCase().includes("serie")) {
    // CONTENT é a autoridade de séries/temporadas. Busca é complementar.
    const [temporadas, busca] = await Promise.all([
      getJSON(`/series/serie/${categoria}/${slug}/temporadas`, TTL_LONGO),
      buscar(slug).catch(() => ({ resultados: [] })),
    ]);
    const item =
      (busca.resultados || []).find((i) => String(i.link_assistir || "").includes(`/${slug}`)) ||
      (busca.resultados || []).find((i) => String(i.slug || "") === String(slug)) ||
      busca.resultados?.[0] ||
      {};
    return {
      ...item,
      titulo: limparTitulo(item.titulo || temporadas.serie || slug),
      categoria: temporadas.categoria || categoria,
      slug: temporadas.slug || slug,
      tipo: "Série",
      imagem: item.imagem || item.thumb || "",
      temporadas: temporadas.temporadas || [],
      total_temporadas: temporadas.total_temporadas || (temporadas.temporadas || []).length,
      recomendados: (item.recomendados || []).map((i) => normalizar(i)),
    };
  }
  return getJSON(`/filmes/filme/${categoria}/${slug}`, TTL_LONGO).then((d) => ({
    ...d,
    titulo: limparTitulo(d.titulo),
    categoria: d.categoria || categoria,
    slug: d.slug || slug,
    recomendados: (d.recomendados || []).map((i) => normalizar(i)),
  }));
};

export const getTemporadas = (categoria, slug) =>
  getJSON(`/series/serie/${categoria}/${slug}/temporadas`, TTL_LONGO).then((d) => d.temporadas || []);

export const getEpisodios = (categoria, slug, numero) =>
  getJSON(`/series/serie/${categoria}/${slug}/temporada/${numero}/episodios`, TTL_LONGO).then(
    (d) => d.episodios || [],
  );

/* ---------------- PLAYER (CONTENT API) ---------------- */

/** Texto puro do manifest .m3u8 (reprodução direta pelo CDN). */
export async function getManifesto(categoria, slug) {
  const r = await fetch(`${API_BASE}/filmes/filme-player/${categoria}/${slug}`);
  if (!r.ok) throw new Error("Este título está indisponível no momento.");
  const texto = await r.text();
  if (!texto.includes("#EXTM3U")) throw new Error("Fonte de vídeo inválida.");
  return texto;
}

/* ============================================================
   TEDTOP API — conteúdo complementar, trailers, ingresso
   Todas as rotas são públicas (sem autenticação).
   ============================================================ */

/** Extrai o videoId de uma URL de YouTube (vários formatos). */
export function extrairYoutubeId(url) {
  if (!url || typeof url !== "string") return null;
  const s = url.trim();
  // //www.youtube.com/watch?v=ID  |  https://www.youtube.com/watch?v=ID&t=10s
  // https://youtu.be/ID  |  https://www.youtube.com/embed/ID
  const m =
    s.match(/[?&]v=([^&#]+)/) ||
    s.match(/youtu\.be\/([^?&#]+)/) ||
    s.match(/youtube\.com\/embed\/([^?&#]+)/) ||
    s.match(/youtube\.com\/shorts\/([^?&#]+)/);
  return m ? m[1] : null;
}


/* ---------------- TEDTOP API (pública, sem auth) ---------------- */

/** Normaliza item TEDTOP para o card/detalhe interno. */
export function normalizarTedtopItem(item = {}) {
  let imagem = String(item.imagem || item.thumb || item.poster || "").trim();
  if (imagem.startsWith("//")) imagem = "https:" + imagem;
  const slug = String(item.slug || "").trim();
  const categoria = String(item.categoria || "destaque").trim() || "destaque";
  return {
    ...item,
    titulo: item.titulo || slug,
    slug,
    categoria,
    imagem,
    ano: item.ano || "",
    nota: item.nota != null ? Number(item.nota) : undefined,
    tipo: item.tipo || "Filme",
    genero: item.genero || item.genero_nome || "",
    link_assistir: item.link_assistir || `#/titulo/filme/${categoria}/${slug}`,
    origem: "tedtop",
  };
}

function listaTedtop(d) {
  const arr = d?.filmes || d?.destaques || d?.resultados || d?.itens || d?.data || [];
  return (Array.isArray(arr) ? arr : []).map(normalizarTedtopItem);
}

/** Telão / destaques */
export const getTedtopTelao = (pagina = 1) =>
  getJSON(`/telao?pagina=${pagina}`, TTL_LONGO, TEDTOP_API_BASE).then((d) => ({
    pagina: d.pagina || pagina,
    total: d.total,
    itens: listaTedtop(d),
  }));

/** Bilheteria */
export const getTedtopBilheteria = () =>
  getJSON(`/bilheteria`, TTL_LONGO, TEDTOP_API_BASE).then((d) => listaTedtop(d));

/** Por ano — GET /sessao/ano/:ano (não filtrar localmente) */
export const getTedtopPorAno = (ano, pagina = 1) =>
  getJSON(`/sessao/ano/${encodeURIComponent(ano)}?pagina=${pagina}`, TTL_LONGO, TEDTOP_API_BASE).then((d) => ({
    ano: d.ano || ano,
    pagina: d.pagina || pagina,
    total: d.total,
    itens: listaTedtop(d),
  }));

/** Por letra — GET /alfabeto/:letra (não usar /buscar) */
export const getTedtopPorLetra = (letra, pagina = 1) => {
  const L = String(letra || "A").toUpperCase().slice(0, 1);
  return getJSON(`/alfabeto/${encodeURIComponent(L)}?pagina=${pagina}`, TTL_LONGO, TEDTOP_API_BASE).then((d) => ({
    letra: d.letra || L,
    pagina: d.pagina || pagina,
    total: d.total,
    itens: listaTedtop(d),
  }));
};

/** Por gênero TEDTOP — GET /generos/:genero */
export const getTedtopPorGenero = (genero, pagina = 1) =>
  getJSON(`/generos/${encodeURIComponent(genero)}?pagina=${pagina}`, TTL_LONGO, TEDTOP_API_BASE).then((d) => ({
    genero: d.genero || genero,
    pagina: d.pagina || pagina,
    total: d.total,
    itens: listaTedtop(d),
  }));

/** Radar ao vivo — GET /radar/live/:termo */
export const getTedtopRadar = (termo) =>
  getJSON(`/radar/live/${encodeURIComponent(termo)}`, TTL_CURTO, TEDTOP_API_BASE).then((d) => {
    // API pode devolver string anti-leecher ou lista
    if (typeof d.resultados === "string") {
      return { termo: d.termo || termo, itens: [], aviso: d.resultados };
    }
    return { termo: d.termo || termo, itens: listaTedtop(d) };
  });

/** Detalhes TEDTOP — GET /filme/:slug */
export async function getTedtopFilme(slug) {
  if (!slug) return null;
  try {
    const d = await getJSON(`/filme/${encodeURIComponent(slug)}`, TTL_LONGO, TEDTOP_API_BASE);
    if (!d) return null;
    return normalizarTedtopItem({
      ...d,
      descricao: d.sinopse || d.descricao || "",
      trailer: d.trailer || "",
      recomendados: (d.recomendados || []).map(normalizarTedtopItem),
    });
  } catch (_) {
    return null;
  }
}

/**
 * Link direto TEDTOP (pode expirar). Não persistir.
 * GET /ingresso/:slug
 */
export async function getTedtopIngresso(slug) {
  if (!slug) return null;
  try {
    return await getJSON(`/ingresso/${encodeURIComponent(slug)}`, 5 * 60 * 1000, TEDTOP_API_BASE);
  } catch (_) {
    return null;
  }
}



/* ---------------- CANAIS AO VIVO — Rei dos Canais API v2 ----------------
 * Base: https://api.reidoscanais.st
 * Docs: GET /  → endpoints
 *   GET /channels
 *   GET /channels/{id}
 *   GET /channels/categories
 *   GET /channels?category={nome}
 *   GET /sports
 *   GET /sports/{id}
 *   GET /sports?status={upcoming|live|finished}
 *   GET /sports?category={nome}
 *   GET /search?q={termo}
 * Público, sem auth.
 * --------------------------------------------------------------------- */

function urlHttpValida(url) {
  try {
    const parsed = new URL(String(url || ""));
    return parsed.protocol === "http:" || parsed.protocol === "https:";
  } catch (_) {
    return false;
  }
}

function normalizarEmbeds(lista) {
  return (Array.isArray(lista) ? lista : [])
    .map((embed) => ({
      provider: String(embed?.provider || "Servidor"),
      quality: String(embed?.quality || "Automático"),
      embed_url: String(embed?.embed_url || "").trim(),
    }))
    .filter((embed) => urlHttpValida(embed.embed_url));
}

export function normalizarCanal(item = {}) {
  let logo = String(item.logo_url || item.logo || item.poster || "").trim();
  if (logo.startsWith("//")) logo = "https:" + logo;
  return {
    id: String(item.id || ""),
    titulo: String(item.name || item.title || "Canal ao vivo"),
    descricao: String(item.description || ""),
    logo,
    categoria: String(item.category || "Outros"),
    embeds: normalizarEmbeds(item.embeds),
    epg: item.epg || {},
    aoVivo: true,
    tipo: "canal",
  };
}

export function normalizarEvento(item = {}) {
  let logo = String(item.poster || item.logo || item.logo_url || "").trim();
  if (logo.startsWith("//")) logo = "https:" + logo;
  const status = String(item.status || "").toLowerCase();
  return {
    id: String(item.id || ""),
    titulo: String(item.title || "Evento"),
    descricao: String(item.description || ""),
    logo,
    categoria: String(item.category || item.competition || "Esportes"),
    embeds: normalizarEmbeds(item.embeds),
    epg: { current: { title: item.competition || item.title || "Evento" } },
    aoVivo: status === "live",
    status,
    teams: item.teams || null,
    start_time: item.start_time || "",
    tipo: "evento",
  };
}

/** Lista canais (opcionalmente por categoria nome exata da API). */
export const getCanais = (categoria = "") => {
  const caminho = categoria
    ? `/channels?category=${encodeURIComponent(categoria)}`
    : "/channels";
  // TTL curto: lista muda (canais novos)
  return getJSON(caminho, 2 * 60 * 1000, LIVE_API_BASE).then((d) =>
    (Array.isArray(d?.data) ? d.data : []).map(normalizarCanal),
  );
};

export const getCanalCategorias = () =>
  getJSON("/channels/categories", 10 * 60 * 1000, LIVE_API_BASE).then((d) =>
    (Array.isArray(d?.data) ? d.data : []).map((item) => ({
      id: String(item.id || item.name || ""),
      nome: String(item.name || "Outros"),
    })),
  );

export const getCanal = (id) =>
  getJSON(`/channels/${encodeURIComponent(id)}`, 2 * 60 * 1000, LIVE_API_BASE).then((d) => {
    const raw = d?.data && !Array.isArray(d.data) ? d.data : d?.channel || d;
    return normalizarCanal(raw || {});
  });

/** Eventos: live prioritário; se vazio, traz upcoming+todos. */
export const getEventosAoVivo = async () => {
  try {
    const live = await getJSON("/sports?status=live", 60 * 1000, LIVE_API_BASE);
    const listaLive = (Array.isArray(live?.data) ? live.data : []).map(normalizarEvento);
    if (listaLive.length) return listaLive;
  } catch (_) {}
  try {
    const all = await getJSON("/sports", 60 * 1000, LIVE_API_BASE);
    return (Array.isArray(all?.data) ? all.data : [])
      .map(normalizarEvento)
      .filter((e) => e.status === "live" || e.status === "upcoming" || e.embeds.length > 0);
  } catch (_) {
    return [];
  }
};

export const getEventos = (status = "") => {
  const caminho = status ? `/sports?status=${encodeURIComponent(status)}` : "/sports";
  return getJSON(caminho, 60 * 1000, LIVE_API_BASE).then((d) =>
    (Array.isArray(d?.data) ? d.data : []).map(normalizarEvento),
  );
};

/** Pesquisa global — GET /search?q= */
export const buscarCanais = (q) => {
  const termo = String(q || "").trim();
  if (!termo) return Promise.resolve([]);
  return getJSON(`/search?q=${encodeURIComponent(termo)}`, 60 * 1000, LIVE_API_BASE).then((d) => {
    const payload = d?.data;
    if (Array.isArray(payload)) return payload.map(normalizarCanal);
    const canais = Array.isArray(payload?.channels) ? payload.channels.map(normalizarCanal) : [];
    const eventos = Array.isArray(payload?.events)
      ? payload.events.map(normalizarEvento)
      : Array.isArray(payload?.sports)
        ? payload.sports.map(normalizarEvento)
        : [];
    return [...canais, ...eventos];
  });
};

/* ============================================================
   NOFLIX API — cinema/seriados com DUB/LEG e M3U8
   Base: NOFLIX_API_BASE (servidores-ted-apply3)
   ============================================================ */

/** Corrige texto UTF-8 lido como Latin-1 (Ã©, Ã§, etc.). */
export function corrigirTexto(s) {
  if (!s || typeof s !== "string") return s || "";
  if (!/[ÃÂ]/.test(s)) return s;
  try {
    return decodeURIComponent(escape(s));
  } catch (_) {
    return s;
  }
}

function audioFlags(audio) {
  const a = String(audio || "").toUpperCase();
  const dub = a.includes("DUB");
  const leg = a.includes("LEG");
  let label = "";
  if (dub && leg) label = "DUB e LEG";
  else if (dub) label = "DUB";
  else if (leg) label = "LEG";
  return { temDub: dub, temLeg: leg, label };
}

/** Cache em memória + sessionStorage — a API não busca por idtmdb. */
const _noflixMem = new Map();
const NOFLIX_SS_KEY = "tedflix:noflix:item:";

export function guardarNoflixItem(item) {
  if (!item || !item.idtmdb) return item;
  const id = String(item.idtmdb);
  _noflixMem.set(id, item);
  try {
    sessionStorage.setItem(NOFLIX_SS_KEY + id, JSON.stringify(item));
  } catch (_) {}
  return item;
}

export function lerNoflixItem(idtmdb) {
  const id = String(idtmdb || "").trim();
  if (!id) return null;
  if (_noflixMem.has(id)) return _noflixMem.get(id);
  try {
    const raw = sessionStorage.getItem(NOFLIX_SS_KEY + id);
    if (raw) {
      const parsed = JSON.parse(raw);
      _noflixMem.set(id, parsed);
      return parsed;
    }
  } catch (_) {}
  return null;
}

/** Normaliza item NoFlix para o formato interno do app. */
export function normalizarNoflix(item = {}, tipoForcado) {
  const tipoRaw = tipoForcado || item.tipo || "filme";
  const tipo = String(tipoRaw).toLowerCase().includes("serie") ? "serie" : "filme";
  const idtmdb = String(item.idtmdb || item.id || "").trim();
  const flags = audioFlags(item.audio);
  const titulo = corrigirTexto(item.titulo || "");
  const sinopse = corrigirTexto(item.sinopse || "");
  const categoria = corrigirTexto(item.categoria || "");
  const capa = item.capa || item.imagem || item.poster || "";
  const banner = item.banner || capa || "";
  const out = {
    ...item,
    fonte: "noflix",
    tipo,
    idtmdb,
    titulo,
    sinopse,
    descricao: sinopse,
    capa,
    imagem: capa,
    thumb: capa,
    poster: capa,
    banner,
    nota: item.rating != null && item.rating !== "" ? Number(item.rating) : null,
    ano: item.ano || "",
    categoria,
    audio: item.audio || "",
    temDub: flags.temDub || Boolean(item.player_dub),
    temLeg: flags.temLeg || Boolean(item.player_leg),
    audioLabel: flags.label || null,
    badgeExtra: flags.label || null,
    runtime: item.runtime,
    idioma: corrigirTexto(item.idioma || ""),
    produtora: corrigirTexto(item.produtora || ""),
    total_temporadas: item.total_temporadas,
    player_dub: item.player_dub || "",
    player_leg: item.player_leg || "",
    slug: idtmdb,
    link_assistir: tipo === "serie" ? `#/noflix/serie/${idtmdb}` : `#/noflix/filme/${idtmdb}`,
  };
  // Recomputa label se players existem sem campo audio
  if (!out.audioLabel) {
    if (out.temDub && out.temLeg) out.audioLabel = "DUB e LEG";
    else if (out.temDub) out.audioLabel = "DUB";
    else if (out.temLeg) out.audioLabel = "LEG";
    out.badgeExtra = out.audioLabel;
  }
  return guardarNoflixItem(out);
}

async function getNoflixJSON(caminho, ttl = TTL_LONGO) {
  // Listagens/detalhes: TTL longo. Busca: TTL curto (termo muda).
  const isBusca = String(caminho || "").includes("/buscar/");
  if (!NOFLIX_ENABLED) return isBusca ? { resultados: [], total: 0 } : { filmes: [], series: [], total: 0 };
  return getJSON(caminho, isBusca ? TTL_CURTO : ttl, NOFLIX_API_BASE);
}

export async function buscarNoflix(termo, limite = 40) {
  if (!NOFLIX_ENABLED) return [];

  const q = String(termo || "").trim();
  if (q.length < 2) return { resultados: [] };
  const d = await getNoflixJSON(`/buscar/${encodeURIComponent(q)}?limite=${limite}`);
  // A API devolve series/filmes como CONTADOR (int); a lista útil está em resultados[]
  const raw = Array.isArray(d.resultados) ? d.resultados : [];
  const lista = raw.map((i) => {
    const tp = String(i.tipo || "").toLowerCase();
    const isSerie = tp.includes("serie") || tp.includes("séri") || tp === "tv" || i.total_temporadas;
    return normalizarNoflix(i, isSerie ? "serie" : "filme");
  });
  return {
    resultados: lista,
    series: lista.filter((i) => /serie|séri/i.test(String(i.tipo || ""))),
    filmes: lista.filter((i) => !/serie|séri/i.test(String(i.tipo || ""))),
    total: d.total || lista.length,
  };
}


/** Top 10 filmes em alta — GET /cinema/ted?limite=10 */
export async function getNoflixTopFilmes(limite = 10) {
  if (!NOFLIX_ENABLED) return null;

  const d = await getNoflixJSON(`/cinema/ted?limite=${limite}`);
  const raw = Array.isArray(d.filmes) ? d.filmes : Array.isArray(d.resultados) ? d.resultados : [];
  return raw.map((i, idx) => {
    const n = normalizarNoflix(i, "filme");
    n.rank = idx + 1;
    n.badgeExtra = null; // rank visual no card, não badge de áudio
    return n;
  });
}

/** Top 10 séries em alta — GET /seriados/ted?limite=10 */
export async funct
  if (!NOFLIX_ENABLED) return null;
ion getNoflixTopSeries(limite = 10) {
  const d = await getNoflixJSON(`/seriados/ted?limite=${limite}`);
  const raw = Array.isArray(d.series) ? d.series : Array.isArray(d.resultados) ? d.resultados : [];
  return raw.map((i, idx) => {
    const n = normalizarNoflix(i, "serie");
    n.rank = idx + 1;
    n.badgeExtra = null;
    return n;
  });
}


/* ==================== MEGACINE ==================== */

function getMegacineJSON(caminho, ttl = TTL_LONGO) {
  return getJSON(caminho, ttl, MEGACINE_API_BASE);
}

/** Normaliza item MegaCine para o formato interno do app. */
export function normalizarMegacine(item = {}, tipoForcado) {
  const tipoRaw = tipoForcado || item.tipo || "filme";
  const isSerie = String(tipoRaw).toLowerCase().includes("serie") || String(tipoRaw).toLowerCase().includes("séri");
  const tipo = isSerie ? "serie" : "filme";
  const slug = String(item.slug || "").trim();
  const capa = item.capa || item.imagem || item.poster || item.banner || "";
  const titulo = item.titulo || slug;
  const out = {
    ...item,
    fonte: "megacine",
    origem: "megacine",
    tipo,
    slug,
    titulo,
    capa,
    imagem: capa,
    thumb: capa,
    poster: capa,
    banner: item.banner || capa,
    nota: item.nota != null && item.nota !== "" ? Number(item.nota) : null,
    ano: item.ano || "",
    descricao: item.sinopse || item.descricao || "",
    sinopse: item.sinopse || item.descricao || "",
    categoria: "megacine",
    filmeId: `cine-${tipo}-${slug}`,
    link_assistir: isSerie ? `#/cine/serie/${encodeURIComponent(slug)}` : `#/cine/filme/${encodeURIComponent(slug)}`,
    link_detalhe: isSerie ? `#/cine/serie/${encodeURIComponent(slug)}` : `#/cine/filme/${encodeURIComponent(slug)}`,
  };
  return out;
}

/** Painel: hero + seções (lançamentos, séries, filmes). */
export async function getMegacinePainel() {
  const d = await getMegacineJSON("/painel", TTL_LONGO);
  const hero = (Array.isArray(d.hero) ? d.hero : []).map((i) => normalizarMegacine(i));
  const secoes = (Array.isArray(d.secoes) ? d.secoes : []).map((s) => ({
    key: s.key || "",
    titulo: s.titulo || s.key || "",
    itens: (Array.isArray(s.itens) ? s.itens : []).map((i) => normalizarMegacine(i)),
  }));
  return { hero, secoes, ok: d.ok !== false };
}

/** Enriquece capa via dossier (hero/lançamentos às vezes vêm sem capa). */
export async function enriquecerMegacineCapa(item) {
  if (!item || !item.slug) return item;
  if (String(item.imagem || item.capa || "").trim()) return item;
  try {
    const tipo = /serie|séri/i.test(String(item.tipo || "")) ? "serie" : "filme";
    const d = await getMegacineDossier(tipo, item.slug);
    if (d && d.capa) {
      item.capa = d.capa;
      item.imagem = d.capa;
      item.thumb = d.capa;
      item.poster = d.capa;
      item.banner = d.banner || d.capa;
      if (d.nota != null) item.nota = Number(d.nota);
      if (d.sinopse) {
        item.sinopse = d.sinopse;
        item.descricao = d.sinopse;
      }
      if (Array.isArray(d.generos)) item.generos = d.generos.map((g) => g.nome || g.slug).filter(Boolean);
    }
  } catch (_) {}
  return item;
}

export async function getMegacineDossier(tipo, slug) {
  const t = String(tipo || "filme").toLowerCase().includes("serie") ? "serie" : "filme";
  const s = String(slug || "").trim();
  if (!s) return null;
  const d = await getMegacineJSON(`/dossier/${t}/${encodeURIComponent(s)}`, TTL_LONGO);
  if (!d || d.ok === false) return null;
  const out = normalizarMegacine({ ...d, tipo: t, slug: s }, t);
  // preserva temporadas/episódios do server
  if (Array.isArray(d.temporadas)) out.temporadas = d.temporadas;
  if (d.total_temporadas != null) out.total_temporadas = d.total_temporadas;
  if (d.total_episodios != null) out.total_episodios = d.total_episodios;
  if (d.viewplayer) out.viewplayer = d.viewplayer;
  if (d.imdb) out.imdb = d.imdb;
  return out;
}

/** Resolve stream HLS — sempre fresco (token expira). */

/** Play episódio por episode_id — GET /projeto/episodio/:id */
export async function getMegacineProjetoEpisodio(episodeId) {
  const id = String(episodeId || "").trim();
  if (!id) return { ok: false, erro: "episode_id vazio" };
  try {
    const resp = await fetch(`${MEGACINE_API_BASE}/projeto/episodio/${encodeURIComponent(id)}`, {
      headers: { Accept: "application/json" },
    });
    const d = await resp.json().catch(() => ({}));
    if (resp.ok && d && d.ok && d.stream) return d;
    return d || { ok: false, erro: `HTTP ${resp.status}` };
  } catch (e) {
    return { ok: false, erro: String(e.message || e) };
  }
}

/** Play série T/E — GET /projeto/serie/:slug/:t/:e */
export async function getMegacineProjetoSerieEp(slug, temp, ep) {
  const s = String(slug || "").trim();
  const t = String(temp != null && temp !== "" ? temp : "1");
  const e = String(ep != null && ep !== "" ? ep : "1");
  if (!s) return { ok: false, erro: "slug vazio" };
  const urls = [
    `${MEGACINE_API_BASE}/projeto/serie/${encodeURIComponent(s)}/${encodeURIComponent(t)}/${encodeURIComponent(e)}`,
  ];
  for (const url of urls) {
    try {
      const resp = await fetch(url, { headers: { Accept: "application/json" } });
      const d = await resp.json().catch(() => ({}));
      if (resp.ok && d && d.ok && d.stream) return d;
      if (d && d.ok === false) return d;
    } catch (_) {}
  }
  return { ok: false, erro: "sem stream" };
}

export async function getMegacineProjeto(tipo, slug) {
  const t = String(tipo || "filme").toLowerCase().includes("serie") ? "serie" : "filme";
  const s = String(slug || "").trim();
  if (!s) return { ok: false, erro: "slug vazio" };
  const urls = [
    `${MEGACINE_API_BASE}/projeto/${t}/${encodeURIComponent(s)}`,
    `${MEGACINE_API_BASE}/projeto?slug=${encodeURIComponent(s)}&tipo=${t}`,
  ];
  for (const url of urls) {
    try {
      const resp = await fetch(url, { headers: { Accept: "application/json" } });
      if (!resp.ok) continue;
      const d = await resp.json();
      if (d && d.ok && d.stream) return d;
      if (d && d.ok === false) return d;
    } catch (_) {}
  }
  return { ok: false, erro: "sem stream" };
}

export async function getMegacinePelicula(pagina = 1) {
  const d = await getMegacineJSON(`/pelicula?pagina=${pagina}`, TTL_LONGO);
  return (Array.isArray(d.itens) ? d.itens : []).map((i) => normalizarMegacine(i, "filme"));
}

export async function getMegacineSerial(pagina = 1) {
  const d = await getMegacineJSON(`/serial?pagina=${pagina}`, TTL_LONGO);
  return (Array.isArray(d.itens) ? d.itens : []).map((i) => normalizarMegacine(i, "serie"));
}

export async function getMegacineGeneros() {
  const d = await getMegacineJSON("/estilo", TTL_LONGO);
  return Array.isArray(d.generos) ? d.generos : [];
}

export async function getMegacineGenero(slug, pagina = 1) {
  const d = await getMegacineJSON(`/estilo/${encodeURIComponent(slug)}?pagina=${pagina}`, TTL_LONGO);
  return (Array.isArray(d.itens) ? d.itens : []).map((i) => normalizarMegacine(i));
}

export async function buscarMegacine(termo) {
  const q = String(termo || "").trim();
  if (q.length < 2) return [];
  const d = await getMegacineJSON(`/lupa/${encodeURIComponent(q)}`, TTL_CURTO);
  return (Array.isArray(d.itens) ? d.itens : []).map((i) => normalizarMegacine(i));
}

/** Cronograma com slug clicável → detalhe da série. */
export async function getMegacineCronograma() {
  const d = await getMegacineJSON("/cronograma", TTL_CURTO);
  const dias = Array.isArray(d?.dias) ? d.dias : [];
  return dias
    .map((dia) => {
      const itens = Array.isArray(dia.itens) ? dia.itens : Array.isArray(dia.episodios) ? dia.episodios : [];
      return {
        data: dia.data || "",
        nome: dia.rotulo || dia.nome || dia.data || "",
        rotulo: dia.rotulo || "",
        episodios: itens.map((ep) => ({
          titulo: ep.titulo || "",
          serie: ep.titulo || "",
          episodio: ep.episodio || "",
          horario: ep.hora || ep.horario || "",
          tipo: ep.tipo || "serie",
          slug: ep.slug || "",
          imagem: ep.capa || ep.imagem || "",
          link_detalhe: ep.slug ? `#/cine/serie/${encodeURIComponent(ep.slug)}` : "",
        })),
      };
    })
    .filter((d) => d.ep
  if (!NOFLIX_ENABLED) return null;
isodios.length > 0);
}

export async function getNoflixFilmeMeta(idtmdb) {
  const id = String(idtmdb || "").trim();
  // 1) Cache (lista/busca já normalizou o item completo)
  const cached = lerNoflixItem(id);
  if (cached && cached.tipo !== "serie") return cached;

  // 2) Procurar por título do cache parcial
  const tituloHint = cached?.titulo;
  if (tituloHint) {
    try {
      const d = await getNoflixJSON(`/cinema/procurar/${encodeURIComponent(tituloHint)}?limite=20`);
      const hit = (d.resultados || d.filmes || []).find((i) => String(i.idtmdb) === id);
      if (hit) return normalizarNoflix(hit, "filme");
    } catch (_) {}
  }

  // 3) Varre listagens (a API não aceita idtmdb em /procurar)
  for (const path of [`/cinema?limite=120`, `/cinema?audio=dub&limite=120`, `/cinema?audio=leg&limite=120`, `/cinema/ted?limite=40`]) {
    try {
      const d = await getNoflixJSON(path);
      const hit = (d.filmes || []).find((i) => String(i.idtmdb) === id);
      if (hit) return normalizarNoflix(hit, 
  if (!NOFLIX_ENABLED) return null;
"filme");
    } catch (_) {}
  }
  return cached || null;
}

export async function getNoflixSerieMeta(idtmdb) {
  const id = String(idtmdb || "").trim();
  const cached = lerNoflixItem(id);
  if (cached && String(cached.tipo).includes("serie")) return cached;

  // Confirma existência via temporadas (funciona com idtmdb)
  let temps = [];
  try {
    temps = await getNoflixTemporadas(id);
  } catch (_) {}

  const tituloHint = cached?.titulo;
  if (tituloHint) {
    try {
      const d = await getNoflixJSON(`/seriados/procurar/${encodeURIComponent(tituloHint)}?limite=20`);
      const hit = (d.series || d.resultados || []).find((i) => String(i.idtmdb) === id);
      if (hit) return normalizarNoflix(hit, "serie");
    } catch (_) {}
  }

  for (const path of [`/seriados?limite=120`, `/seriados?audio=dub&limite=120`, `/seriados/ted?limite=40`, `/seriados/estreias?limite=40`]) {
    try {
      const d = await getNoflixJSON(path);
      const hit = (d.series || []).find((i) => String(i.idtmdb) === id);
      if (hit) return normalizarNoflix(hit, "serie");
    } catch (_) {}
  }

  // Série existe (tem temporadas) mas sem meta rica — monta mínimo
  if (temps && temps.length) {
    return normalizarNoflix(
      {
        idtmdb: id,
        titulo: cached?.titulo || `Série ${id}`,
        capa: cached?.imagem || temps[0]?.capa || "",
        banner: cached?.banner || temps[0]?.capa || "",
        audio: cached?.audio || "DUB",
        total_temporadas: tem
  if (!NOFLIX_ENABLED) return null;
ps.length,
        tipo: "serie",
      },
      "serie",
    );
  }
  return cached || null;
}

export async function getNoflixTemporadas(idtmdb) {
  const d = await getNoflixJSON(`/seriados/${encodeURIComponent(idtmdb)}/temporadas`);
  return (d.temporadas || []).map((t) => ({
    ...t,
    numero: t.numero,
    titulo: corrigi
  if (!NOFLIX_ENABLED) return null;
rTexto(t.titulo || `Temporada ${t.numero}`),
    sinopse: corrigirTexto(t.sinopse || ""),
    capa: t.capa || "",
  }));
}

export async function getNoflixEpisodios(idtmdb, temporada) {
  const d = await getNoflixJSON(
    `/seriados/${encodeURIComponent(idtmdb)}/temporada/${encodeURIComponent(temporada)}/episodios`,
  );
  return (d.episodios || []).map((ep) => {
    const flags = audioFlags(ep.audio || (ep.player_dub ? "DUB" : "") + (ep.player_leg ? "|LEG" : ""));
    const temDub = Boolean(ep.player_dub) || flags.temDub;
    const temLeg = Boolean(ep.player_leg) || flags.temLeg;
    let label = "";
    if (temDub && temLeg) label = "DUB e LEG";
    else if (temDub) label = "DUB";
    else if (temLeg) label = "LEG";
    return {
      ...ep,
      titulo: corrigirTexto(ep.titulo_episodio || ep.titulo || `Episódio ${ep.numero}`),
      sinopse: corrigirTexto(ep.sinopse || ""),
      imagem: ep.imagem || "",
      temDub,
      temLeg,
      audioLabel: label,
      runtime: ep.runtime,
    };
  });
}

/** URL do manifesto M3U8 no proxy NoFlix (filme). */
export function noflixFilmeStreamUrl(idtmdb, audio = "dub") {
  const a = String(audio).toLowerCase() === "leg" ? "leg" : "dub";
  return `${NOFLIX_API_BASE}/cinema/assistir/${encodeURIComponent(idtmdb)}/${a}`;
}

/** URL do manifesto M3U8 no proxy NoFlix (episódio). */
export function noflixEpStreamUrl(idtmdb, temporada, episodio, audio = "dub") {
  const a = String(audio || "").toLowerCase();
  const base = `${NOFLIX_API_BASE}/seriados/assistir/${encodeURIComponent(idtmdb)}/${encodeURIComponent(temporada)}/${encodeURIComponent(epi
  if (!NOFLIX_ENABLED) return null;
sodio)}`;
  if (a === "leg" || a === "dub") return `${base}/${a}`;
  return base;
}

/** Lista filmes NoFlix — GET /cinema?audio=dub|leg&limite= */
export async function getNoflixFilmes({ audio = "", limite = 120 } = {}) {
  const q = new URLSearchParams();
  if (limite) q.set("limite", String(limite));
  const a = String(audio || "").toLowerCase();
  if (a === "dub" || a === "leg") q.set("audio", a);
  const qs = q.toString();
  const d = await getNoflixJSON(`/cinema${qs ? `?${qs
  if (!NOFLIX_ENABLED) return null;
}` : ""}`);
  const lista = d.filmes || d.resultados || [];
  return lista.map((i) => normalizarNoflix(i, "filme"));
}

/** Lista séries NoFlix — GET /seriados?audio=dub|leg&limite= */
export async function getNoflixSeries({ audio = "", limite = 120 } = {}) {
  const q = new URLSearchParams();
  if (limite) q.set("limite", String(limite));
  const a = String(audio || "").toLowerCase();
  if (a === "dub" || a === "leg") q.set("audio", a);
  const qs = 
  if (!NOFLIX_ENABLED) return null;
q.toString();
  const d = await getNoflixJSON(`/seriados${qs ? `?${qs}` : ""}`);
  const lista = d.series || d.resultados || [];
  return lista.map((i) =>
  if (!NOFLIX_ENABLED) return null;
 normalizarNoflix(i, "serie"));
}

/** Top / estreias / ano / gênero (extras úteis) */
export async function getNoflixFilmesTed(limite = 15) {
  const d = await 
  if (!NOFLIX_ENABLED) return null;
getNoflixJSON(`/cinema/ted?limite=${limite}`);
  return (d.filmes || []).map((i) => normalizarNoflix(i, "filme"));
}
export async function getNoflixSeriesTed(limite = 
  if (!NOFLIX_ENABLED) return null;
20) {
  const d = await getNoflixJSON(`/seriados/ted?limite=${limite}`);
  return (d.series || []).map((i) => normalizarNoflix(i, "serie"));
}
export async function getNoflixSeriesEstreia
  if (!NOFLIX_ENABLED) return null;
s(limite = 20) {
  const d = await getNoflixJSON(`/seriados/estreias?limite=${limite}`);
  return (d.series || []).map((i) => normalizarNoflix(i, "serie"));
}

export async function getNoflixFilmesA
  if (!NOFLIX_ENABLED) return null;
no(ano, limite = 40) {
  const d = await getNoflixJSON(`/cinema/ano/${encodeURIComponent(ano)}?limite=${limite}`);
  return (d.filmes || []).map((i) => normalizarNoflix(i, "filme"));
}

export async functi
  if (!NOFLIX_ENABLED) return null;
on getNoflixSeriesAno(ano, limite = 40) {
  const d = await getNoflixJSON(`/seriados/ano/${encodeURIComponent(ano)}?limite=${limite}`);
  return (d.series || []).map((i) => normalizarNoflix(i, "serie"));
}

export async function getNoflixFilmesGenero(categ
  if (!NOFLIX_ENABLED) return null;
oria, limite = 48) {
  const d = await getNoflixJSON(`/cinema/genero/${encodeURIComponent(categoria)}?limite=${limite}`);
  return (d.filmes || []).map((i) => normalizarNoflix(i, "filme"));
}

export async function getNoflixSeriesGenero(categoria, limite = 48) {
  const d = await getNoflixJSON(`/seriados/genero/${encodeURIComponent(categoria)}?limite=${limite}`);
  return (d.series || []).map((i) => normalizarNoflix(i, "serie"));
}

/** Últimos episódios lançados — GET /seriados/ultimos-eps */
export async function getNoflixUltimosEps(limite = 40) {
  const d = await getNoflixJSON(`/seriados/ultimos-eps?limite=${limite}`);
  return (d.episodios || []).map((ep) => {
    const idtmdb = String(ep.idtmdb || "");
    const tituloSerie = corrigirTexto(ep.titulo || "").replace(/\s+\d+x\d+\s*$/i, "").trim();
    const epLabel = `T${ep.temporada}E${ep.numero}`;
    return {
      fonte: "noflix",
      tipo: "serie",
      isEpisode: true,
      idtmdb,
      titulo: corrigirTexto(ep.titulo_episodio || ep.titulo || epLabel),
      tituloSerie: tituloSerie || "Série",
      imagem: ep.imagem || "",
      banner: ep.imagem || "",
      sinopse: corrigirTexto(ep.sinopse || ""),
      temporada: ep.temporada,
      episodioNumero: ep.numero,
      runtime: ep.runtime,
      badgeExtra: epLabel,
      link_assistir: `#/noflix/serie/${idtmdb}`,
      slug: idtmdb,
    };
  });
}

export async function procurarNoflixFilmes(titulo, limite = 40) {
  const d = await getNoflixJSON(`/cinema/procurar/${encodeURIComponent(titulo)}?limite=${limite}`);
  return (d.resultados || d.filmes || []).map((i) => normalizarNoflix(i, "filme"));
}

export async function procurarNoflixSeries(nome, limite = 40) {
  const d = await getNoflixJSON(`/seriados/procurar/${encodeURIComponent(nome)}?limite=${limite}`);
  return (d.series || d.resultados || []).map((i) => normalizarNoflix(i, "serie"));
}



/* ============================================================
   TMDB HELPER — https://servidor-tmdb.onrender.com
   Prioridade: ID TMDB → título limpo → episódios por temporada
   ============================================================ */

const TMDB_LS_KEY = "tedflix:tmdb:meta:v1";
const TMDB_EP_KEY = "tedflix:tmdb:eps:v1";
const TMDB_MEM = new Map();

function tmdbCacheKey(titulo, ano, tipo) {
  const t = String(titulo || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim();
  return `${tipo || "filme"}:${t}:${ano || ""}`;
}

function lerTmdbLocal() {
  try {
    return JSON.parse(localStorage.getItem(TMDB_LS_KEY) || "{}") || {};
  } catch (_) {
    return {};
  }
}

function salvarTmdbLocal(map) {
  try {
    const keys = Object.keys(map);
    const slim = {};
    keys.slice(-150).forEach((k) => {
      slim[k] = map[k];
    });
    localStorage.setItem(TMDB_LS_KEY, JSON.stringify(slim));
  } catch (_) {}
}

function lerTmdbEpsLocal() {
  try {
    return JSON.parse(localStorage.getItem(TMDB_EP_KEY) || "{}") || {};
  } catch (_) {
    return {};
  }
}

function salvarTmdbEpsLocal(map) {
  try {
    const keys = Object.keys(map);
    const slim = {};
    keys.slice(-80).forEach((k) => {
      slim[k] = map[k];
    });
    localStorage.setItem(TMDB_EP_KEY, JSON.stringify(slim));
  } catch (_) {}
}

function metaFromTmdbPayload(d, fallbackTitle, year) {
  if (!d || (!d.ok && !d.found && !d.capa)) return null;
  if (d.found === false && !d.capa) return null;
  const capa = d.capa || d.capa_sm || "";
  if (!capa && !d.tmdb_id) return null;
  return {
    capa: capa || "",
    banner: d.banner || d.banner_sm || capa || "",
    sinopse: d.sinopse || "",
    nota: d.nota,
    titulo: d.titulo || fallbackTitle || "",
    tmdb_id: d.tmdb_id || d.id || null,
    ano: d.ano || year || null,
  };
}

/** Limpa título sujo da CONTENT API / progresso para buscar no TMDB. */
export function limparTituloTmdb(titulo, slug) {
  let t = String(titulo || "").trim();
  t = t.replace(/^assistir\s+/i, "");
  t = t.replace(/\s+online(\s+gr[aá]tis)?$/i, "");
  t = t.replace(/\s+gr[aá]tis$/i, "");
  t = t.replace(/^\d{3,6}[\s\-_]+/, "");
  const fromSlug = String(slug || "")
    .replace(/^\d{3,6}-/, "")
    .replace(/[-_]+/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase())
    .trim();
  if ((!t || t.length < 3 || /^\d+$/.test(t)) && fromSlug) t = fromSlug;
  return t.replace(/\s+/g, " ").trim();
}

/** Extrai id TMDB numérico de campos comuns do item. */
export function extrairTmdbId(item) {
  if (!item) return 0;
  const candidates = [
    item.idtmdb,
    item.tmdb_id,
    item.tmdbId,
    item.id_tmdb,
    item.tmdb,
  ];
  for (const c of candidates) {
    const n = Number(c);
    if (Number.isFinite(n) && n > 0) return Math.floor(n);
  }
  // slug noflix às vezes é só o id
  const slug = String(item.slug || "").trim();
  if (/^\d{3,8}$/.test(slug)) return Number(slug);
  return 0;
}

/** GET /tmdb/id/:id?tipo= */
export async function lookupTmdbById(id, tipo = "filme") {
  const tmdbId = Number(id);
  if (!Number.isFinite(tmdbId) || tmdbId <= 0) return null;
  const kind = String(tipo || "filme").toLowerCase().includes("ser") ? "serie" : "filme";
  const key = `id:${kind}:${tmdbId}`;
  if (TMDB_MEM.has(key)) return TMDB_MEM.get(key);

  const local = lerTmdbLocal();
  if (local[key] && (local[key].capa || local[key].miss)) {
    const v = local[key].miss ? null : local[key];
    TMDB_MEM.set(key, v);
    return v;
  }

  try {
    const r = await fetch(
      `${TMDB_HELPER_BASE}/tmdb/id/${tmdbId}?tipo=${encodeURIComponent(kind)}`,
      { signal: AbortSignal.timeout ? AbortSignal.timeout(12000) : undefined },
    );
    if (!r.ok) {
      TMDB_MEM.set(key, null);
      return null;
    }
    const d = await r.json();
    const meta = metaFromTmdbPayload(d, "", d.ano);
    if (!meta?.capa) {
      local[key] = { miss: true, at: Date.now() };
      salvarTmdbLocal(local);
      TMDB_MEM.set(key, null);
      return null;
    }
    local[key] = { ...meta, at: Date.now() };
    salvarTmdbLocal(local);
    TMDB_MEM.set(key, meta);
    return meta;
  } catch (_) {
    TMDB_MEM.set(key, null);
    return null;
  }
}

/** GET /tmdb/lookup?titulo=&ano=&tipo= */
export async function lookupTmdbMeta({ titulo, ano, tipo, slug } = {}) {
  const raw = String(titulo || "").trim();
  const title = limparTituloTmdb(raw, slug);
  if (!title || title.length < 2) return null;
  if (/^\d{4,}$/.test(title)) return null;

  const kind = String(tipo || "filme").toLowerCase().includes("ser") ? "serie" : "filme";
  const year = ano ? String(ano).slice(0, 4) : "";
  const key = tmdbCacheKey(title, year, kind);

  if (TMDB_MEM.has(key)) return TMDB_MEM.get(key);

  const local = lerTmdbLocal();
  if (local[key] && (local[key].capa || local[key].miss)) {
    TMDB_MEM.set(key, local[key].miss ? null : local[key]);
    return local[key].miss ? null : local[key];
  }

  const tentativas = [title];
  const slugTitle = limparTituloTmdb("", slug);
  if (slugTitle && slugTitle.toLowerCase() !== title.toLowerCase()) {
    tentativas.push(slugTitle);
  }

  try {
    for (const tryTitle of tentativas) {
      const q = new URLSearchParams({ titulo: tryTitle, tipo: kind });
      if (year) q.set("ano", year);
      const r = await fetch(`${TMDB_HELPER_BASE}/tmdb/lookup?${q}`, {
        signal: AbortSignal.timeout ? AbortSignal.timeout(12000) : undefined,
      });
      if (!r.ok) continue;
      const d = await r.json();
      const meta = metaFromTmdbPayload(d, tryTitle, year);
      if (!meta?.capa) continue;
      local[key] = { ...meta, at: Date.now() };
      salvarTmdbLocal(local);
      TMDB_MEM.set(key, meta);
      return meta;
    }
    local[key] = { miss: true, at: Date.now() };
    salvarTmdbLocal(local);
    TMDB_MEM.set(key, null);
    return null;
  } catch (_) {
    TMDB_MEM.set(key, null);
    return null;
  }
}

/**
 * Resolve meta: ID primeiro, depois título limpo.
 */
export async function resolverTmdbMeta(item, tipoPadrao) {
  if (!item) return null;
  let tipo = tipoPadrao || item.tipo || "";
  if (!tipo && (item.serieSlug || item.isEpisode || item.temporadas)) tipo = "serie";
  if (!tipo) tipo = "filme";
  const kind = String(tipo).toLowerCase().includes("ser") ? "serie" : "filme";

  const id = extrairTmdbId(item);
  if (id > 0) {
    const byId = await lookupTmdbById(id, kind);
    if (byId?.capa) return byId;
  }

  const tituloRaw = String(item.titulo || item.nome || item.serie || "").trim();
  const slug = String(item.slug || item.serieSlug || "").trim();
  return lookupTmdbMeta({
    titulo: tituloRaw,
    ano: item.ano,
    tipo: kind,
    slug,
  });
}

/**
 * Enriquece item in-place se faltar capa/imagem (ou só grava tmdb_id).
 * Não sobrescreve arte válida. Não quebra se helper falhar.
 */
export async function enriquecerComTmdb(item, tipoPadrao) {
  if (!item) return item;
  try {
    const meta = await resolverTmdbMeta(item, tipoPadrao);
    if (!meta) return item;

    if (meta.tmdb_id && !extrairTmdbId(item)) {
      item.tmdb_id = meta.tmdb_id;
      item.idtmdb = meta.tmdb_id;
    }

    const temArte = Boolean(
      String(item.imagem || item.capa || item.thumb || item.poster || item.banner || "").trim(),
    );
    if (!temArte && meta.capa) {
      item.imagem = meta.capa;
      item.capa = meta.capa;
      item.thumb = meta.capa;
      item.poster = meta.capa;
      if (meta.banner) item.banner = meta.banner;
    } else if (!item.banner && meta.banner) {
      item.banner = meta.banner;
    }

    if (meta.sinopse && !item.descricao && !item.sinopse) {
      item.descricao = meta.sinopse;
      item.sinopse = meta.sinopse;
    }
    if (meta.nota != null && (item.nota == null || Number(item.nota) === 0)) {
      item.nota = meta.nota;
    }

    const tituloRaw = String(item.titulo || item.nome || item.serie || "").trim();
    if (meta.titulo && tituloRaw) {
      if (
        /^\d/.test(tituloRaw) ||
        /assistir/i.test(tituloRaw) ||
        /online/i.test(tituloRaw)
      ) {
        item.titulo = meta.titulo;
      }
    } else if (meta.titulo && !tituloRaw) {
      item.titulo = meta.titulo;
    }
  } catch (_) {}
  return item;
}

/** GET /tmdb/serie/:id/temporada/:n — só metadados de episódio */
export async function getTmdbEpisodiosTemporada(tmdbId, temporada) {
  const id = Number(tmdbId);
  const temp = Number(temporada);
  if (!Number.isFinite(id) || id <= 0 || !Number.isFinite(temp) || temp < 0) {
    return [];
  }
  const key = `eps:${id}:${temp}`;
  if (TMDB_MEM.has(key)) return TMDB_MEM.get(key) || [];

  const local = lerTmdbEpsLocal();
  if (Array.isArray(local[key])) {
    TMDB_MEM.set(key, local[key]);
    return local[key];
  }

  try {
    const r = await fetch(
      `${TMDB_HELPER_BASE}/tmdb/serie/${id}/temporada/${temp}`,
      { signal: AbortSignal.timeout ? AbortSignal.timeout(15000) : undefined },
    );
    if (!r.ok) {
      TMDB_MEM.set(key, []);
      return [];
    }
    const d = await r.json();
    if (!d?.ok) {
      TMDB_MEM.set(key, []);
      return [];
    }
    const eps = (d.episodios || []).map((ep) => ({
      numero: Number(ep.numero) || 0,
      titulo: ep.titulo || "",
      imagem: ep.imagem || "",
    }));
    local[key] = eps;
    salvarTmdbEpsLocal(local);
    TMDB_MEM.set(key, eps);
    return eps;
  } catch (_) {
    TMDB_MEM.set(key, []);
    return [];
  }
}

/**
 * Complementa APENAS titulo + imagem dos episódios (por número).
 * Preserva link, slug, duração, etc. da fonte original.
 */
/**
 * Complementa título + imagem dos episódios (por número).
 * Cascata de capa: original → TMDB ep → capa da série (serieCapa).
 * Preserva link, slug, duração, etc.
 * @param {Array} episodios
 * @param {number|string} tmdbSerieId
 * @param {number|string} temporada
 * @param {string} [serieCapa] pôster da série como fallback final
 */
export async function enriquecerEpisodiosComTmdb(episodios, tmdbSerieId, temporada, serieCapa = "") {
  const list = Array.isArray(episodios) ? episodios : [];
  if (!list.length) return list;
  const fallbackSerie = String(serieCapa || "").trim();
  let id = Number(tmdbSerieId) || 0;

  let tmdbEps = [];
  if (id > 0) {
    try {
      tmdbEps = await getTmdbEpisodiosTemporada(id, temporada);
    } catch (_) {
      tmdbEps = [];
    }
  }

  const byNum = new Map();
  tmdbEps.forEach((e) => {
    if (e.numero > 0) byNum.set(e.numero, e);
  });

  list.forEach((ep) => {
    const num = Number(ep.numero) || 0;
    const meta = byNum.get(num);
    if (meta) {
      const tituloOrig = String(ep.titulo || ep.nome || "").trim();
      const generico =
        !tituloOrig ||
        /^epis[oó]dio\s*\d*$/i.test(tituloOrig) ||
        /^serie\s*\d*$/i.test(tituloOrig) ||
        /^\d+$/.test(tituloOrig);
      if (generico && meta.titulo && !/^epis[oó]dio/i.test(meta.titulo)) {
        ep.titulo = meta.titulo;
      }
      if (!String(ep.imagem || ep.thumb || "").trim() && meta.imagem) {
        ep.imagem = meta.imagem;
        ep.thumb = meta.imagem;
      }
    }
    // Fallback final: capa da série (nunca deixa o card vazio)
    if (!String(ep.imagem || ep.thumb || "").trim() && fallbackSerie) {
      ep.imagem = fallbackSerie;
      ep.thumb = fallbackSerie;
    }
  });
  return list;
}

/** Enriquece lista (máx. concorrência 4). */
export async function enriquecerListaTmdb(lista, tipoPadrao) {
  const arr = Array.isArray(lista) ? lista : [];
  const fila = arr.filter((i) => i);
  if (!fila.length) return arr;

  const conc = 4;
  let idx = 0;
  async function worker() {
    while (idx < fila.length) {
      const i = idx++;
      try {
        await enriquecerComTmdb(fila[i], tipoPadrao);
      } catch (_) {}
    }
  }
  await Promise.all(Array.from({ length: Math.min(conc, fila.length) }, () => worker()));
  return arr;
}




/* ==================== TEDFLIX API v2 (TMDB catálogo + stream) ==================== */

function getTedv2JSON(caminho, ttl = TTL_CURTO) {
  return getJSON(caminho, ttl, TEDV2_API_BASE);
}

/** Normaliza item v2 → card do app */
export function normalizarTedv2(item = {}, tipoForcado) {
  const typeRaw = tipoForcado || item.type || item.tipo || "movie";
  const isSerie =
    /series|serie|séri|tv/i.test(String(typeRaw)) ||
    String(typeRaw).toLowerCase() === "tv";
  const tipo = isSerie ? "serie" : "filme";
  const tmdb = String(item.tmdb || item.id || item.idtmdb || "").trim();
  const imdb = item.imdb ? String(item.imdb).trim() : "";
  const titulo = String(item.title || item.titulo || item.name || "").trim();
  const capa = item.poster || item.capa || item.imagem || "";
  const banner = item.backdrop || item.banner || capa;
  const ano = item.year || (item.release_date || item.first_air_date || "").slice(0, 4) || "";
  const rating = item.vote_average != null ? Number(item.vote_average) : null;
  return {
    fonte: "tedv2",
    origem: "tedv2",
    categoria: "tedv2",
    tipo,
    type: isSerie ? "series" : "movie",
    tmdb,
    idtmdb: tmdb,
    imdb,
    titulo,
    sinopse: item.overview || item.sinopse || "",
    imagem: capa,
    capa,
    poster: capa,
    banner,
    backdrop: banner,
    ano,
    rating,
    vote_average: rating,
    slug: tmdb ? `${isSerie ? "serie" : "filme"}-${tmdb}` : "",
    filmeId: tmdb ? `tedv2-${tmdb}` : "",
    link_detalhe: tmdb
      ? isSerie
        ? `#/v2/serie/${encodeURIComponent(tmdb)}`
        : `#/v2/filme/${encodeURIComponent(tmdb)}`
      : "#/",
  };
}

export async function getTedv2Home() {
  const d = await getTedv2JSON("/api/v2/catalog/home", TTL_CURTO);
  if (!d || !d.ok) return { hero: [], rows: [] };
  const heroRaw = d.hero;
  const hero = Array.isArray(heroRaw)
    ? heroRaw.map((i) => normalizarTedv2(i))
    : heroRaw
      ? [normalizarTedv2(heroRaw)]
      : [];
  const rows = (d.rows || []).map((row) => ({
    id: row.id || row.title || "",
    titulo: row.title || row.titulo || "Destaques",
    itens: (row.items || row.itens || []).map((i) => normalizarTedv2(i)),
  }));
  return { hero, rows };
}

export async function buscarTedv2(termo, type = "multi") {
  const q = String(termo || "").trim();
  if (q.length < 2) return [];
  try {
    const d = await getTedv2JSON(
      `/api/v2/catalog/search?query=${encodeURIComponent(q)}&type=${encodeURIComponent(type)}`,
      TTL_CURTO,
    );
    return (d.results || []).map((i) => normalizarTedv2(i));
  } catch (_) {
    return [];
  }
}

export async function getTedv2Movie(tmdbId) {
  const id = String(tmdbId || "").trim();
  if (!id) return null;
  const d = await getTedv2JSON(`/api/v2/catalog/movie/${encodeURIComponent(id)}`, TTL_LONGO);
  if (!d || d.ok === false) return null;
  return { ...normalizarTedv2(d, "movie"), ...d, imdb: d.imdb || null, cast: d.cast || [], genres: d.genres || [] };
}

export async function getTedv2Series(tmdbId) {
  const id = String(tmdbId || "").trim();
  if (!id) return null;
  const d = await getTedv2JSON(`/api/v2/catalog/series/${encodeURIComponent(id)}`, TTL_LONGO);
  if (!d || d.ok === false) return null;
  return {
    ...normalizarTedv2(d, "series"),
    ...d,
    imdb: d.imdb || null,
    seasons: d.seasons || [],
    number_of_seasons: d.number_of_seasons,
  };
}

export async function getTedv2Season(tmdbId, season) {
  const id = String(tmdbId || "").trim();
  const n = Number(season) || 1;
  if (!id) return { episodes: [] };
  const d = await getTedv2JSON(
    `/api/v2/catalog/series/${encodeURIComponent(id)}/seasons/${n}`,
    TTL_CURTO,
  );
  return {
    ok: !!(d && d.ok !== false),
    season: n,
    name: d?.name || `Temporada ${n}`,
    episodes: d?.episodes || [],
  };
}

export async function getTedv2Trending(window = "week") {
  const d = await getTedv2JSON(`/api/v2/catalog/trending?window=${encodeURIComponent(window)}`, TTL_CURTO);
  return (d?.results || []).map((i) => normalizarTedv2(i));
}

export async function getTedv2PopularMovies(page = 1) {
  const d = await getTedv2JSON(`/api/v2/catalog/movie/popular?page=${page}`, TTL_CURTO);
  return (d?.results || []).map((i) => normalizarTedv2(i, "movie"));
}

export async function getTedv2PopularSeries(page = 1) {
  const d = await getTedv2JSON(`/api/v2/catalog/series/popular?page=${page}`, TTL_CURTO);
  return (d?.results || []).map((i) => normalizarTedv2(i, "series"));
}

/**
 * Resolve m3u8 via API v2.
 * Filme: /api/v2/stream/movie/{imdb}?lang=dub|sub
 * Série: /api/v2/stream/series/{imdb}/season/{t}/episode/{e}?lang=dub
 */
export async function getTedv2Stream({ imdb, lang = "dub", tipo = "movie", temporada, episodio }) {
  const id = String(imdb || "").trim();
  if (!id) throw new Error("IMDb ausente");
  const a = lang === "leg" || lang === "sub" ? "sub" : "dub";
  let path;
  if (tipo === "serie" || tipo === "series" || tipo === "episode") {
    const t = Number(temporada) || 0;
    const e = Number(episodio) || 0;
    if (t > 0 && e > 0) {
      path = `/api/v2/stream/series/${encodeURIComponent(id)}/season/${t}/episode/${e}?lang=${a}`;
    } else {
      path = `/api/v2/stream/series/${encodeURIComponent(id)}?lang=${a}`;
    }
  } else {
    path = `/api/v2/stream/movie/${encodeURIComponent(id)}?lang=${a}`;
  }
  const d = await getTedv2JSON(path, 60 * 1000);
  if (!d || d.ok === false) {
    const err = new Error(d?.erro || d?.error || "Stream indisponível");
    err.code = d?.code;
    throw err;
  }
  const url =
    d.playback?.url ||
    d.stream ||
    d.stream_url ||
    "";
  return {
    ok: true,
    stream: url,
    stream_direct: d.stream_direct || d.playback?.url || url,
    stream_type: d.stream_type || d.playback?.format || "hls",
    via: d.via || d.source || "tedv2",
    quality: d.quality || d.metadata?.quality || "",
    raw: d,
  };
}
