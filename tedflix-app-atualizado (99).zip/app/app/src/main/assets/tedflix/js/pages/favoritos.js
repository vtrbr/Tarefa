import { el, limpar } from "../dom.js";
import { cardTitulo, skeletonCard } from "../components/card.js";
import { buscar, parseLink, rotaDetalhe } from "../api.js";

/** Detecta episódio NoFlix a partir do filmeId (ex: 58566-t1e77 ou serie-58566-1-77-dub). */
function parseNoflixEpId(filmeId) {
  const s = String(filmeId || "").trim();
  let m = s.match(/^(\d+)-t(\d+)e(\d+)$/i);
  if (m) return { idtmdb: m[1], temp: m[2], ep: m[3] };
  m = s.match(/^serie-(\d+)-(\d+)-(\d+)(?:-(dub|leg))?$/i);
  if (m) return { idtmdb: m[1], temp: m[2], ep: m[3], audio: m[4] || "dub" };
  return null;
}

/** Extrai T1E77 / S1E77 do título. */
function parseEpDoTitulo(titulo) {
  const t = String(titulo || "");
  let m = t.match(/t\s*(\d+)\s*e\s*(\d+)/i);
  if (m) return { temp: m[1], ep: m[2] };
  m = t.match(/s\s*(\d+)\s*e\s*(\d+)/i);
  if (m) return { temp: m[1], ep: m[2] };
  return null;
}

/** Monta rota de detalhe/info a partir do item de favorito — nunca "#/" se houver id/título. */
function rotaFavorito(item) {
  const filmeId = String(item.filmeId || item.id || "").trim();
  const titulo = String(item.titulo || "").trim();
  const tipo = String(item.tipo || item.contentType || "").toLowerCase();
  let categoria = String(item.categoria || "").trim();
  let slug = String(item.slug || "").trim();
  const imagem = String(item.thumb || item.imagem || "").trim();
  const epTitulo = parseEpDoTitulo(titulo);
  const nf = parseNoflixEpId(filmeId) || parseNoflixEpId(slug);

  // 1) Episódio NoFlix por id estruturado
  if (nf) {
    return `#/episodio/noflix/${nf.idtmdb}/${nf.temp}/${nf.ep}?audio=${nf.audio || "dub"}`;
  }

  // 2) Episódio NoFlix: id numérico + T/E no título
  if (/^\d+$/.test(filmeId) && epTitulo) {
    return `#/episodio/noflix/${filmeId}/${epTitulo.temp}/${epTitulo.ep}?audio=dub`;
  }

  // 3) tipo episodio explícito
  if (tipo === "episodio" || tipo === "episode") {
    if (/^\d+$/.test(filmeId) && epTitulo) {
      return `#/episodio/noflix/${filmeId}/${epTitulo.temp}/${epTitulo.ep}?audio=dub`;
    }
    if (categoria && slug) {
      const q = new URLSearchParams({
        t: String(item.temporada || epTitulo?.temp || 1),
        e: String(item.episodio || epTitulo?.ep || 1),
        serieCategoria: item.serieCategoria || categoria,
        serieSlug: item.serieSlug || "",
        filmeId,
        thumb: imagem,
        titulo,
      });
      return `#/episodio/${encodeURIComponent(categoria)}/${encodeURIComponent(slug)}?${q}`;
    }
  }

  // 4) NoFlix série/filme por idtmdb
  if (/^\d+$/.test(filmeId)) {
    if (tipo.includes("serie") || tipo.includes("séri") || tipo === "tv" || epTitulo) {
      if (epTitulo) {
        return `#/episodio/noflix/${filmeId}/${epTitulo.temp}/${epTitulo.ep}?audio=dub`;
      }
      return `#/noflix/serie/${filmeId}`;
    }
    return `#/noflix/filme/${filmeId}`;
  }

  // 5) CONTENT com categoria/slug
  if (categoria && slug) {
    if (epTitulo || tipo.includes("episodio")) {
      const q = new URLSearchParams({
        t: String(item.temporada || epTitulo?.temp || 1),
        e: String(item.episodio || epTitulo?.ep || 1),
        serieCategoria: item.serieCategoria || categoria,
        serieSlug: item.serieSlug || slug,
        filmeId,
        thumb: imagem,
        titulo,
      });
      return `#/episodio/${encodeURIComponent(categoria)}/${encodeURIComponent(slug)}?${q}`;
    }
    const isSerie = tipo.includes("serie") || tipo.includes("séri") || tipo.includes("tv");
    return `#/titulo/${isSerie ? "serie" : "filme"}/${encodeURIComponent(categoria)}/${encodeURIComponent(slug)}`;
  }

  // 6) Fallback busca por título — evita cair na home
  if (titulo) {
    return `#/favorito?titulo=${encodeURIComponent(titulo)}`;
  }
  if (filmeId) {
    return `#/noflix/filme/${encodeURIComponent(filmeId)}`;
  }
  return "#/favoritos";
}

export default async function paginaFavoritos(raiz) {
  const page = el("div", { class: "page page-favoritos" });
  page.append(
    el("h1", { class: "page-title pad" }, "Minha lista"),
    el("p", { class: "sub pad", style: "padding-top:0" }, "Títulos que você marcou como favorito"),
  );
  const grid = el("div", { class: "grid pad", style: "margin-top:12px" });
  for (let i = 0; i < 6; i++) grid.append(skeletonCard());
  page.append(grid);
  raiz.append(page);

  try {
    if (!window.AndroidPlayer?.getFavorites) {
      limpar(grid);
      grid.append(el("p", { class: "sub" }, "Favoritos disponíveis apenas no app."));
      return page;
    }
    const raw = JSON.parse(window.AndroidPlayer.getFavorites() || "{}");
    const lista = Array.isArray(raw.favoritos) ? raw.favoritos : Array.isArray(raw) ? raw : [];
    if (!lista.length) {
      limpar(grid);
      grid.append(
        el("div", { class: "empty-state" }, [
          el("p", { class: "sub" }, "Sua lista está vazia."),
          el("a", { class: "btn primary", href: "#/" }, "Explorar catálogo"),
        ]),
      );
      return page;
    }

    const cards = await Promise.all(
      lista.map(async (item) => {
        const titulo = String(item.titulo || "").trim();
        const filmeId = String(item.filmeId || item.id || "").trim();
        let categoria = String(item.categoria || "").trim();
        let slug = String(item.slug || "").trim();
        let imagem = String(item.thumb || item.imagem || "").trim();
        let tipo = String(item.tipo || item.contentType || "").trim() || "Filme";

        const nf = parseNoflixEpId(filmeId) || parseNoflixEpId(slug);
        const epTitulo = parseEpDoTitulo(titulo);
        if (nf || epTitulo) tipo = "episodio";

        // Completa via busca se faltar rota
        if ((!categoria || !slug) && !nf && !/^\d+$/.test(filmeId) && titulo) {
          try {
            const busca = await buscar(titulo);
            const resultados = Array.isArray(busca?.resultados) ? busca.resultados : [];
            const hit =
              resultados.find((r) => {
                const id = String(r.filmeId || r.id || "").trim();
                return (filmeId && id === filmeId) ||
                  (titulo && String(r.titulo || "").toLowerCase() === titulo.toLowerCase());
              }) || resultados[0];
            if (hit) {
              const p = parseLink(hit.link_assistir);
              if (!categoria) categoria = hit.categoria || p.categoria || "";
              if (!slug) slug = hit.slug || p.slug || "";
              if (!imagem) imagem = hit.imagem || hit.capa || hit.thumb || "";
              if (!tipo || tipo === "Filme") tipo = hit.tipo || tipo;
            }
          } catch (_) {}
        }

        const base = {
          titulo,
          filmeId,
          categoria,
          slug,
          imagem,
          thumb: imagem,
          tipo,
          contentType: tipo,
          temporada: item.temporada || epTitulo?.temp,
          episodio: item.episodio || epTitulo?.ep,
          serieCategoria: item.serieCategoria,
          serieSlug: item.serieSlug,
          isEpisode: Boolean(nf || epTitulo || /episodio|episode/i.test(tipo)),
        };
        const href = rotaFavorito(base);
        return {
          ...base,
          link_detalhe: href,
          link_assistir: href,
        };
      }),
    );

    // Progresso
    let progressoMap = {};
    const pctDe = (item) => {
      let p = Number(item.percent ?? item.progresso ?? 0);
      if (p > 0) return Math.min(99, Math.round(p));
      let pos = Number(item.positionMs || 0);
      let dur = Number(item.durationMs || 0);
      if ((!pos || !dur) && (item.positionSeconds || item.durationSeconds)) {
        pos = Number(item.positionSeconds || 0) * 1000;
        dur = Number(item.durationSeconds || 0) * 1000;
      }
      if (pos > 0 && dur > 0) return Math.min(99, Math.max(1, Math.round((pos * 100) / dur)));
      return 0;
    };
    try {
      const cw = JSON.parse(window.AndroidPlayer?.getContinueWatching?.() || "[]");
      (Array.isArray(cw) ? cw : []).forEach((item) => {
        const keys = [
          `${item.categoria || ""}:${item.slug || item.filmeId || ""}`.toLowerCase(),
          String(item.filmeId || "").toLowerCase(),
          String(item.slug || "").toLowerCase(),
          String(item.titulo || "").trim().toLowerCase(),
        ];
        const percent = pctDe(item);
        if (percent > 0) keys.forEach((k) => { if (k) progressoMap[k] = percent; });
      });
    } catch (_) {}

    cards.forEach((c) => {
      const keys = [
        `${c.categoria || ""}:${c.slug || c.filmeId || ""}`.toLowerCase(),
        String(c.filmeId || "").toLowerCase(),
        String(c.slug || "").toLowerCase(),
        String(c.titulo || "").trim().toLowerCase(),
      ];
      let p = 0;
      for (const k of keys) if (progressoMap[k]) { p = progressoMap[k]; break; }
      if (p > 0) {
        c.progresso = p;
        c.continuarTexto = `${p}% assistido`;
      }
    });

    limpar(grid);
    const frag = document.createDocumentFragment();
    cards.forEach((c) => frag.append(cardTitulo(c, { size: "md", eager: true })));
    grid.append(frag);
  } catch (e) {
    limpar(grid);
    grid.append(el("p", { class: "sub" }, "Não foi possível carregar os favoritos."));
  }

  return page;
}
