import { el, limpar, svgIcone } from "../dom.js";
import {
  getNoflixFilmeMeta,
  getNoflixSerieMeta,
  getNoflixTemporadas,
  getNoflixEpisodios,
  noflixFilmeStreamUrl,
  noflixEpStreamUrl,
  corrigirTexto,
  lerNoflixItem,
  enriquecerComTmdb,
  enriquecerEpisodiosComTmdb,
} from "../api.js";
import { backdrop, poster } from "../img.js";

function botaoVoltar() {
  const b = el("button", {
    class: "back",
    type: "button",
    "aria-label": "Voltar",
    onclick: () => history.back(),
  });
  b.innerHTML = svgIcone("back");
  return b;
}

function abrirPlayerNativo({ categoria, slug, titulo, thumb, tipo, filmeId }) {
  if (window.AndroidPlayer && typeof window.AndroidPlayer.openPlayer === "function") {
    window.AndroidPlayer.openPlayer(
      categoria,
      slug,
      titulo || "",
      "[]",
      filmeId || slug,
      thumb || "",
      tipo || "noflix",
      "",
      "",
      "[]",
      "[]",
    );
    return true;
  }
  return false;
}

function metaLinha(item) {
  const bits = [];
  if (item.nota != null && !Number.isNaN(Number(item.nota))) bits.push(`★ ${Number(item.nota).toFixed(1)}`);
  if (item.ano) bits.push(String(item.ano));
  if (item.runtime) {
    const m = Number(item.runtime);
    if (m >= 60) bits.push(`${Math.floor(m / 60)}h ${m % 60}min`);
    else if (m > 0) bits.push(`${m}min`);
  }
  if (item.idioma) bits.push(item.idioma);
  if (item.audioLabel) bits.push(item.audioLabel);
  return bits.join(" · ");
}

function pctFilmeNoflix(id) {
  try {
    const cw = JSON.parse(window.AndroidPlayer?.getContinueWatching?.() || "[]");
    const list = Array.isArray(cw) ? cw : [];
    const idStr = String(id);
    const hit = list.find((i) =>
      String(i.filmeId || "") === idStr ||
      String(i.slug || "").includes(`filme-${idStr}`) ||
      (String(i.categoria || "").toLowerCase() === "noflix" && String(i.slug || "").startsWith(`filme-${idStr}`))
    );
    if (!hit) return 0;
    let p = Number(hit.percent ?? hit.progresso ?? 0);
    if (!p && hit.positionMs && hit.durationMs) {
      p = Math.min(99, Math.round((Number(hit.positionMs) * 100) / Number(hit.durationMs)));
    }
    return Math.min(99, Math.max(0, Math.round(p)));
  } catch (_) {
    return 0;
  }
}

function botoesFilme(item) {
  const wrap = el("div", { class: "noflix-actions" });
  const titulo = item.titulo || "Filme";
  const thumb = item.imagem || item.banner || "";
  const id = item.idtmdb;
  const pct = pctFilmeNoflix(id);
  const cont = pct > 0;

  const play = (audio, label) => {
    const slug = `filme-${id}-${audio}`;
    if (
      abrirPlayerNativo({
        categoria: "noflix",
        slug,
        titulo: `${titulo} (${label})`,
        thumb,
        tipo: "filme",
        filmeId: id,
      })
    ) {
      return;
    }
    location.hash = `#/assistir/noflix/${encodeURIComponent(slug)}`;
  };

  if (pct > 0) {
    wrap.append(
      el("div", { class: "filme-progress-block", style: "width:100%;margin-bottom:10px" }, [
        el("p", { class: "sub" }, `${pct}% assistido`),
        el("div", { class: "ep-progress ep-progress--lg" }, [
          el("span", { style: `width:${pct}%` }),
        ]),
      ]),
    );
  }

  const lab = cont ? `▶ Continuar · ${pct}%` : "▶ Assistir";
  if (item.temDub && item.temLeg) {
    wrap.append(
      el("button", { class: "btn primary", type: "button", onclick: () => play("dub", "Dublado") }, cont ? lab + " (DUB)" : "▶ Assistir dublado"),
      el("button", { class: "btn ghost", type: "button", onclick: () => play("leg", "Legendado") }, "▶ Legendado"),
    );
  } else if (item.temDub) {
    wrap.append(el("button", { class: "btn primary", type: "button", onclick: () => play("dub", "Dublado") }, cont ? lab : "▶ Assistir"));
  } else if (item.temLeg) {
    wrap.append(el("button", { class: "btn primary", type: "button", onclick: () => play("leg", "Legendado") }, cont ? lab : "▶ Assistir legendado"));
  } else {
    wrap.append(el("p", { class: "sub" }, "Player indisponível para este título."));
  }
  return wrap;
}

export async function paginaNoflixFilme(raiz, { idtmdb }) {
  const page = el("div", { class: "page" });
  page.append(botaoVoltar());
  // Cache primeiro (vindo da lista) — evita tela vazia
  let item = lerNoflixItem(idtmdb);
  if (!item) {
    page.append(el("div", { class: "center" }, [el("div", { class: "spinner" }), el("p", {}, "Carregando…")]));
  }
  raiz.append(page);

  try {
    const fresh = await getNoflixFilmeMeta(idtmdb);
    if (fresh) item = fresh;
  } catch (_) {}

  limpar(page);
  page.append(botaoVoltar());
  if (!item) {
    page.append(
      el("div", { class: "pad" }, [
        el("p", { class: "sub" }, "Título não encontrado na fonte NoFlix."),
        el("p", { class: "sub" }, "Volte à lista e abra de novo (a API não busca por ID)."),
        el("button", { class: "btn ghost", type: "button", onclick: () => history.back() }, "Voltar"),
      ]),
    );
    return page;
  }

  if (!String(item.imagem || item.capa || item.banner || "").trim()) {
    try { await enriquecerComTmdb(item, "filme"); } catch (_) {}
  }

  const hero = el("div", {
    class: "hero",
    style: "margin:0;border-radius:0;aspect-ratio:16/10;max-height:42vh",
  });
  if (item.banner || item.imagem) {
    hero.append(
      el("img", {
        src: backdrop(item.banner || item.imagem, 780) || item.banner || item.imagem,
        alt: "",
        loading: "eager",
      }),
    );
  }
  hero.append(el("div", { class: "veil" }));
  hero.append(
    el("div", { class: "info" }, [
      el("h1", {}, item.titulo || "Filme"),
      el("p", { class: "tags" }, metaLinha(item)),
    ]),
  );
  page.append(hero);
  page.append(botoesFilme(item));
  if (item.sinopse) page.append(el("p", { class: "sub pad", style: "line-height:1.45" }, item.sinopse));
  if (item.categoria) {
    const cats = String(item.categoria)
      .split(",")
      .map((c) => c.trim())
      .filter(Boolean);
    const row = el("div", { class: "pad", style: "display:flex;flex-wrap:wrap;gap:8px" });
    cats.forEach((c) => row.append(el("span", { class: "noflix-chip" }, c)));
    page.append(row);
  }
  if (item.produtora) {
    page.append(el("p", { class: "sub pad", style: "padding-top:0" }, `Produção: ${item.produtora}`));
  }
  return page;
}

export async function paginaNoflixSerie(raiz, { idtmdb }) {
  const page = el("div", { class: "page" });
  page.append(botaoVoltar());
  let item = lerNoflixItem(idtmdb);
  if (!item) {
    page.append(el("div", { class: "center" }, [el("div", { class: "spinner" }), el("p", {}, "Carregando…")]));
  }
  raiz.append(page);

  let temporadas = [];
  try {
    const [fresh, temps] = await Promise.all([
      getNoflixSerieMeta(idtmdb),
      getNoflixTemporadas(idtmdb).catch(() => []),
    ]);
    if (fresh) item = fresh;
    temporadas = temps || [];
  } catch (_) {}

  limpar(page);
  page.append(botaoVoltar());
  if (!item) {
    page.append(
      el("div", { class: "pad" }, [
        el("p", { class: "sub" }, "Série não encontrada na fonte NoFlix."),
        el("p", { class: "sub" }, "Volte à lista e abra de novo."),
        el("button", { class: "btn ghost", type: "button", onclick: () => history.back() }, "Voltar"),
      ]),
    );
    return page;
  }

  if (!String(item.imagem || item.capa || item.banner || "").trim()) {
    try { await enriquecerComTmdb(item, "serie"); } catch (_) {}
  }

  const hero = el("div", {
    class: "hero",
    style: "margin:0;border-radius:0;aspect-ratio:16/10;max-height:42vh",
  });
  if (item.banner || item.imagem) {
    hero.append(
      el("img", {
        src: backdrop(item.banner || item.imagem, 780) || item.banner || item.imagem,
        alt: "",
        loading: "eager",
      }),
    );
  }
  hero.append(el("div", { class: "veil" }));
  hero.append(
    el("div", { class: "info" }, [
      el("h1", {}, item.titulo || "Série"),
      el("p", { class: "tags" }, metaLinha(item)),
    ]),
  );
  page.append(hero);
  if (item.sinopse) page.append(el("p", { class: "sub pad", style: "line-height:1.45" }, item.sinopse));

  const listaTemps = temporadas.length ? temporadas : [{ numero: 1, titulo: "Temporada 1" }];
  let tempAtual = listaTemps[0].numero;
  const chips = el("div", { class: "pad tedtop-chips tedtop-chips--wide" });
  const epsBox = el("div", { class: "pad" });

  async function carregarEps(num) {
    tempAtual = num;
    [...chips.children].forEach((b) => b.classList.toggle("active", Number(b.dataset.t) === Number(num)));
    limpar(epsBox);
    epsBox.append(el("p", { class: "sub" }, "Carregando episódios…"));
    try {
      let eps = await getNoflixEpisodios(idtmdb, num);
      try {
        const serieCapa = item.imagem || item.capa || item.banner || "";
        await enriquecerEpisodiosComTmdb(eps, idtmdb, num, serieCapa);
      } catch (_) {}
      limpar(epsBox);
      if (!eps.length) {
        epsBox.append(el("p", { class: "sub" }, "Nenhum episódio nesta temporada."));
        return;
      }
      eps.forEach((ep) => {
        const abrirInfo = (audio) => {
          const a = audio || (ep.temDub ? "dub" : ep.temLeg ? "leg" : "dub");
          location.hash = `#/episodio/noflix/${encodeURIComponent(idtmdb)}/${num}/${ep.numero}?audio=${a}`;
        };
        const actions = el("div", { class: "ep-actions" });
        // Um toque → informações do episódio (play só lá)
        actions.append(
          el("button", {
            class: "btn primary",
            type: "button",
            onclick: (ev) => { ev.stopPropagation(); abrirInfo(ep.temDub ? "dub" : "leg"); },
          }, "▶"),
        );
        const capaSrc = ep.imagem || item.imagem || item.capa || "";
        const capEl = capaSrc
          ? el("img", {
              src: poster(capaSrc, "sm") || capaSrc,
              alt: "",
              loading: "lazy",
              style: "width:120px;height:68px;object-fit:cover;border-radius:8px;flex:0 0 auto;background:#222",
              onerror: "this.style.display='none';this.nextSibling&&(this.nextSibling.style.display='grid')",
            })
          : null;
        const ph = el("div", {
          class: "thumb-placeholder",
          style: `width:120px;height:68px;border-radius:8px;flex:0 0 auto;display:${capaSrc ? "none" : "grid"}`,
          "aria-hidden": "true",
        });
        const row = el("div", {
          class: "noflix-ep",
          role: "button",
          tabindex: "0",
          onclick: () => abrirInfo(ep.temDub ? "dub" : "leg"),
          style: "cursor:pointer",
        }, [
          capEl,
          ph,
          el("div", { class: "info" }, [
            el("strong", {}, `${ep.numero}. ${ep.titulo || "Episódio"}`),
            el(
              "span",
              {},
              [ep.runtime ? `${ep.runtime}min` : "", ep.audioLabel || ""].filter(Boolean).join(" · ") || " ",
            ),
          ]),
          actions,
        ]);
        epsBox.append(row);
      });
    } catch (_) {
      limpar(epsBox);
      epsBox.append(el("p", { class: "sub" }, "Falha ao carregar episódios."));
    }
  }

  listaTemps.forEach((t) => {
    const btn = el(
      "button",
      {
        class: `chip${Number(t.numero) === Number(tempAtual) ? " active" : ""}`,
        type: "button",
        "data-t": String(t.numero),
      },
      t.titulo || `Temporada ${t.numero}`,
    );
    btn.addEventListener("click", () => carregarEps(t.numero));
    chips.append(btn);
  });

  page.append(chips, epsBox);
  carregarEps(tempAtual);
  return page;
}
