import { el } from "../dom.js";
import { getAgenda } from "../api.js";
import { backdrop, poster } from "../img.js";

export default async function paginaAgenda(raiz) {
  const page = el("div", { class: "page" });
  const corpo = el("div", {});
  page.append(el("h1", { class: "page-title" }, "Agenda"), corpo);
  raiz.append(page);

  corpo.append(el("div", { class: "center" }, [el("div", { class: "spinner" })]));

  try {
    const dias = await getAgenda();
    corpo.innerHTML = "";
    if (!dias.length) {
      corpo.append(el("p", { class: "center" }, "Nenhum episódio agendado."));
      return page;
    }
    dias.forEach((dia) => {
      const eps = dia.episodios || [];
      const bloco = el("section", { class: "section" }, [
        el("div", { class: "section-head" }, [
          el("h2", {}, dia.nome || dia.data || ""),
          el("span", { class: "sub" }, `${eps.length} ep.`),
        ]),
      ]);
      eps.forEach((ep) => {
        const href = ep.link_detalhe || (ep.slug ? `#/cine/serie/${encodeURIComponent(ep.slug)}` : "");
        const body = [
          el("div", { class: "cap" }, [
            ep.imagem
              ? el("img", {
                  src: poster(ep.imagem, "sm") || backdrop(ep.imagem, 342) || ep.imagem,
                  alt: ep.titulo || "",
                  loading: "lazy",
                  decoding: "async",
                })
              : el("div", { class: "thumb-placeholder", "aria-hidden": "true" }),
          ]),
          el("div", { style: "min-width:0;flex:1" }, [
            el("p", { class: "t" }, ep.serie || ep.titulo || ""),
            el("p", { class: "d" }, [ep.episodio, ep.horario].filter(Boolean).join(" · ")),
          ]),
        ];
        if (href) {
          bloco.append(el("a", { class: "ep ep-link", href, style: "display:flex;gap:12px;align-items:center;text-decoration:none;color:inherit;padding:10px 16px" }, body));
        } else {
          bloco.append(el("div", { class: "ep", style: "display:flex;gap:12px;align-items:center;padding:10px 16px" }, body));
        }
      });
      corpo.append(bloco);
    });
  } catch (e) {
    corpo.innerHTML = "";
    corpo.append(el("p", { class: "center" }, "Não foi possível carregar a agenda."));
  }

  return page;
}
