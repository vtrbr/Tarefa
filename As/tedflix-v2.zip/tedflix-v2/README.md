# TEDFLIX API v2

Backend novo (não conflita com CONTENT / NoFlix / TEDTOP / Mega).

```
App → /api/v2/catalog/*  (TMDB)
App → /api/v2/stream/*   (Amenic → byse → m3u8 + proxy)
```

## Subir

```bash
cp .env.example .env
# edite TMDB_API_KEY e PUBLIC_BASE_URL
node server.js
```

Sem `npm install` (Node puro).

## Rotas principais

| Rota | Função |
|------|--------|
| `GET /api/v2/catalog/home` | Hero + fileiras |
| `GET /api/v2/catalog/search?query=` | Busca multi/movie/series |
| `GET /api/v2/catalog/movie/:tmdbId` | Detalhe filme (+ imdb) |
| `GET /api/v2/catalog/series/:tmdbId` | Detalhe série |
| `GET /api/v2/catalog/series/:id/seasons/:n` | Episódios |
| `GET /api/v2/stream/movie/:imdbId?lang=dub` | **m3u8** (proxied) |
| `GET /api/v2/stream/proxy?url=` | HLS proxy |

## Fluxo Assistir

1. Detalhe: `GET /api/v2/catalog/movie/278` → pega `imdb: tt0111161`
2. Play: `GET /api/v2/stream/movie/tt0111161?lang=dub`
3. Resposta: `{ playback: { url: ".../proxy?url=...", format: "hls" } }`
4. Player usa `playback.url`

## Credenciais

| Variável | Obrigatória | Onde |
|----------|-------------|------|
| `TMDB_API_KEY` | Sim (catálogo) | themoviedb.org/settings/api |
| `PUBLIC_BASE_URL` | Recomendada em produção | URL deste server |
| Amenic | Não tem key pública | CF pode bloquear datacenter |

## Limitação conhecida

Amenic (`amenic-plus.com`) usa **Cloudflare**. Em VPS/Render pode retornar 403; em IP residencial costuma funcionar. Byse (m3u8) em si responde sem CF.
