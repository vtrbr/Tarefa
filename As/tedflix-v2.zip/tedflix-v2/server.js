/**
 * TEDFLIX API v2 — catálogo (TMDB) + stream (Amenic → byse → m3u8 + proxy)
 * Node puro (sem npm). Credenciais no .env
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

// carrega .env simples (sem dotenv)
(function loadEnv() {
  const p = path.join(__dirname, '.env');
  if (!fs.existsSync(p)) return;
  const lines = fs.readFileSync(p, 'utf8').split(/\r?\n/);
  for (const line of lines) {
    const t = line.trim();
    if (!t || t.startsWith('#')) continue;
    const i = t.indexOf('=');
    if (i < 1) continue;
    const k = t.slice(0, i).trim();
    let v = t.slice(i + 1).trim();
    if (
      (v.startsWith('"') && v.endsWith('"')) ||
      (v.startsWith("'") && v.endsWith("'"))
    ) {
      v = v.slice(1, -1);
    }
    if (!process.env[k]) process.env[k] = v;
  }
})();

const cache = require('./lib/cache');
const tmdb = require('./lib/tmdb');
const amenic = require('./lib/amenic');
const { handleProxy, toProxyUrl } = require('./lib/proxy');

const PORT = Number(process.env.PORT) || 7600;

const TTL = {
  home: 15 * 60 * 1000,
  search: 5 * 60 * 1000,
  detail: 30 * 60 * 1000,
  list: 20 * 60 * 1000
};

function publicBase(req) {
  if (process.env.PUBLIC_BASE_URL) {
    return process.env.PUBLIC_BASE_URL.replace(/\/$/, '');
  }
  const host = req.headers['x-forwarded-host'] || req.headers.host || 'localhost';
  const proto =
    req.headers['x-forwarded-proto'] ||
    (String(host).includes('localhost') ? 'http' : 'https');
  return proto + '://' + host;
}

function send(res, status, body) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Cache-Control': 'no-store'
  });
  res.end(JSON.stringify(body));
}

function wrapStream(data, req) {
  if (!data || !data.ok || !data.stream) return data;
  const base = publicBase(req);
  const proxyOn = process.env.STREAM_PROXY_ENABLED !== 'false';
  if (!proxyOn) {
    return {
      ok: true,
      type: data.type || 'movie',
      source: data.via || 'amenic',
      playback: {
        url: data.stream,
        format: data.stream_type || 'hls',
        proxy: false
      },
      metadata: {
        title: data.title,
        imdb: data.imdb,
        quality: data.quality,
        player: data.player
      },
      stream: data.stream,
      stream_type: data.stream_type || 'hls',
      via: data.via
    };
  }
  const proxied = toProxyUrl(data.stream, base);
  return {
    ok: true,
    type: data.type || 'movie',
    source: data.via || 'amenic',
    playback: {
      url: proxied,
      format: data.stream_type || 'hls',
      proxy: true
    },
    metadata: {
      title: data.title,
      imdb: data.imdb,
      quality: data.quality,
      player: data.player
    },
    // compat legada
    stream: proxied,
    stream_direct: data.stream,
    stream_type: 'hls',
    via: data.via,
    proxy: true
  };
}

async function router(req, res) {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
    return res.end();
  }

  const u = new URL(req.url, 'http://localhost');
  const pathName = u.pathname.replace(/\/+$/, '') || '/';
  const q = Object.fromEntries(u.searchParams.entries());

  // Proxy HLS
  if (pathName === '/api/v2/stream/proxy' || pathName === '/proxy') {
    return handleProxy(req, res, publicBase(req));
  }

  try {
    // -------- health --------
    if (pathName === '/' || pathName === '/api/v2') {
      return send(res, 200, {
        nome: 'TEDFLIX API v2',
        versao: '2.0.0',
        status: 'online',
        tmdb: !!(process.env.TMDB_API_KEY || process.env.TMDB_KEY),
        endpoints: {
          catalog: {
            home: 'GET /api/v2/catalog/home',
            search: 'GET /api/v2/catalog/search?query=&type=multi|movie|series',
            movie: 'GET /api/v2/catalog/movie/:tmdbId',
            series: 'GET /api/v2/catalog/series/:tmdbId',
            season:
              'GET /api/v2/catalog/series/:tmdbId/seasons/:season',
            trending: 'GET /api/v2/catalog/trending?window=week',
            popular_movies: 'GET /api/v2/catalog/movie/popular',
            popular_series: 'GET /api/v2/catalog/series/popular',
            genres: 'GET /api/v2/catalog/genres?type=movie|series',
            discover: 'GET /api/v2/catalog/discover?type=movie&genre=&year='
          },
          stream: {
            movie: 'GET /api/v2/stream/movie/:imdbId?lang=dub|sub',
            series:
              'GET /api/v2/stream/series/:imdbId?lang=dub (MVP: mesmo what=data Amenic)',
            proxy: 'GET /api/v2/stream/proxy?url='
          }
        }
      });
    }

    // -------- CATALOG --------
    if (pathName === '/api/v2/catalog/home') {
      const data = await cache.wrap('home', TTL.home, () => tmdb.home());
      return send(res, 200, { ok: true, ...data });
    }

    if (pathName === '/api/v2/catalog/search') {
      const query = q.query || q.q || '';
      const page = parseInt(q.page || '1', 10) || 1;
      const type = q.type || 'multi';
      const data = await cache.wrap(
        `search:${type}:${query}:${page}`,
        TTL.search,
        () => tmdb.search(query, page, type)
      );
      return send(res, 200, { ok: true, ...data });
    }

    if (pathName === '/api/v2/catalog/trending') {
      const window = q.window === 'day' ? 'day' : 'week';
      const data = await cache.wrap('trending:' + window, TTL.list, async () => {
        const d = await tmdb.tmdb('/trending/all/' + window);
        return {
          results: (d.results || []).map((r) =>
            r.media_type === 'tv' ? tmdb.mapSeries(r) : tmdb.mapMovie(r)
          )
        };
      });
      return send(res, 200, { ok: true, ...data });
    }

    if (pathName === '/api/v2/catalog/movie/popular') {
      const page = parseInt(q.page || '1', 10) || 1;
      const data = await cache.wrap('mpop:' + page, TTL.list, () =>
        tmdb.list('/movie/popular', page, tmdb.mapMovie)
      );
      return send(res, 200, { ok: true, ...data });
    }

    if (pathName === '/api/v2/catalog/movie/upcoming') {
      const page = parseInt(q.page || '1', 10) || 1;
      const data = await cache.wrap('mup:' + page, TTL.list, () =>
        tmdb.list('/movie/upcoming', page, tmdb.mapMovie)
      );
      return send(res, 200, { ok: true, ...data });
    }

    if (pathName === '/api/v2/catalog/movie/top-rated') {
      const page = parseInt(q.page || '1', 10) || 1;
      const data = await cache.wrap('mtop:' + page, TTL.list, () =>
        tmdb.list('/movie/top_rated', page, tmdb.mapMovie)
      );
      return send(res, 200, { ok: true, ...data });
    }

    if (pathName === '/api/v2/catalog/movie/now-playing') {
      const page = parseInt(q.page || '1', 10) || 1;
      const data = await cache.wrap('mnow:' + page, TTL.list, () =>
        tmdb.list('/movie/now_playing', page, tmdb.mapMovie)
      );
      return send(res, 200, { ok: true, ...data });
    }

    if (pathName === '/api/v2/catalog/series/popular') {
      const page = parseInt(q.page || '1', 10) || 1;
      const data = await cache.wrap('spop:' + page, TTL.list, () =>
        tmdb.list('/tv/popular', page, tmdb.mapSeries)
      );
      return send(res, 200, { ok: true, ...data });
    }

    if (pathName === '/api/v2/catalog/series/top-rated') {
      const page = parseInt(q.page || '1', 10) || 1;
      const data = await cache.wrap('stop:' + page, TTL.list, () =>
        tmdb.list('/tv/top_rated', page, tmdb.mapSeries)
      );
      return send(res, 200, { ok: true, ...data });
    }

    if (pathName === '/api/v2/catalog/series/on-the-air') {
      const page = parseInt(q.page || '1', 10) || 1;
      const data = await cache.wrap('sair:' + page, TTL.list, () =>
        tmdb.list('/tv/on_the_air', page, tmdb.mapSeries)
      );
      return send(res, 200, { ok: true, ...data });
    }

    if (pathName === '/api/v2/catalog/series/airing-today') {
      const page = parseInt(q.page || '1', 10) || 1;
      const data = await cache.wrap('stoday:' + page, TTL.list, () =>
        tmdb.list('/tv/airing_today', page, tmdb.mapSeries)
      );
      return send(res, 200, { ok: true, ...data });
    }

    if (pathName === '/api/v2/catalog/genres') {
      const type = q.type || 'movie';
      const data = await cache.wrap('genres:' + type, 6 * 3600 * 1000, () =>
        tmdb.genres(type)
      );
      return send(res, 200, { ok: true, ...data });
    }

    if (pathName === '/api/v2/catalog/discover') {
      const data = await tmdb.discover({
        type: q.type,
        genre: q.genre,
        year: q.year,
        page: q.page
      });
      return send(res, 200, { ok: true, ...data });
    }

    // /api/v2/catalog/movie/:id
    {
      const m = pathName.match(/^\/api\/v2\/catalog\/movie\/(\d+)$/);
      if (m) {
        const data = await cache.wrap('movie:' + m[1], TTL.detail, () =>
          tmdb.movieDetail(m[1])
        );
        return send(res, 200, { ok: true, ...data });
      }
    }

    // /api/v2/catalog/series/:id/seasons/:season
    {
      const m = pathName.match(
        /^\/api\/v2\/catalog\/series\/(\d+)\/seasons\/(\d+)$/
      );
      if (m) {
        const data = await cache.wrap(
          `season:${m[1]}:${m[2]}`,
          TTL.detail,
          () => tmdb.seasonEpisodes(m[1], m[2])
        );
        return send(res, 200, { ok: true, ...data });
      }
    }

    // /api/v2/catalog/series/:id
    {
      const m = pathName.match(/^\/api\/v2\/catalog\/series\/(\d+)$/);
      if (m) {
        const data = await cache.wrap('series:' + m[1], TTL.detail, () =>
          tmdb.seriesDetail(m[1])
        );
        return send(res, 200, { ok: true, ...data });
      }
    }

    // -------- STREAM --------
    // GET /api/v2/stream/movie/:imdbId?lang=dub|sub
    {
      const m = pathName.match(/^\/api\/v2\/stream\/movie\/(tt\d+)$/i);
      if (m) {
        const lang = q.lang || q.audio || 'dublado';
        const data = await amenic.resolveStream({
          imdb: m[1],
          lang
        });
        if (!data.ok) return send(res, 404, data);
        data.type = 'movie';
        return send(res, 200, wrapStream(data, req));
      }
    }

    // GET /api/v2/stream/series/:imdbId  (MVP: Amenic what=data no mesmo id)
    {
      const m = pathName.match(
        /^\/api\/v2\/stream\/series\/(tt\d+)(?:\/season\/(\d+)\/episode\/(\d+))?$/i
      );
      if (m) {
        const lang = q.lang || q.audio || 'dublado';
        const data = await amenic.resolveStream({
          imdb: m[1],
          lang
        });
        if (!data.ok) {
          return send(res, 404, {
            ...data,
            aviso:
              'Séries no Amenic ainda usam what=data; se não houver players, a fonte não tem este episódio mapeado.'
          });
        }
        data.type = m[2] ? 'episode' : 'series';
        if (m[2]) {
          data.season = Number(m[2]);
          data.episode = Number(m[3]);
        }
        return send(res, 200, wrapStream(data, req));
      }
    }

    // atalho: /api/v2/stream?imdb=tt...&lang=dub
    if (pathName === '/api/v2/stream') {
      const imdb = q.imdb || q.id;
      if (!imdb) {
        return send(res, 400, { ok: false, erro: 'informe imdb=tt...' });
      }
      const data = await amenic.resolveStream({
        imdb,
        lang: q.lang || 'dublado'
      });
      if (!data.ok) return send(res, 404, data);
      data.type = q.type || 'movie';
      return send(res, 200, wrapStream(data, req));
    }

    return send(res, 404, { ok: false, erro: 'Rota não encontrada', path: pathName });
  } catch (e) {
    const status =
      e.code === 'NO_TMDB_KEY' ? 503 : e.status === 403 ? 502 : 502;
    return send(res, status, {
      ok: false,
      erro: e.message || String(e),
      code: e.code || undefined
    });
  }
}

const server = http.createServer((req, res) => {
  router(req, res).catch((e) => {
    send(res, 500, { ok: false, erro: e.message || String(e) });
  });
});

server.listen(PORT, () => {
  console.log('======================================');
  console.log('🎬 TEDFLIX API v2');
  console.log('🌐 Porta:', PORT);
  console.log('🔑 TMDB:', process.env.TMDB_API_KEY || process.env.TMDB_KEY ? 'ok' : 'FALTA no .env');
  console.log('📋 /api/v2/catalog/*  /api/v2/stream/*');
  console.log('======================================');
});
