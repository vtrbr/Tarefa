import { el, limpar } from "../dom.js";
import {
  getMegacineDossier,
  enriquecerComTmdb,
} from "../api.js";
import { lerProgresso, lerFavorito, abrirPlayerNativo, toggleFavorito } from "../playback.js";
import { montarFicha, montarEpisodiosUI } from "../components/ficha.js";

function playMegacineNativo(opts = {}) {
  const slug = opts.slug || "";
  const tipo = opts.tipo === "serie" ? "serie" : "filme";
  let playSlug = slug;
  if (tipo === "serie" && opts.episodeId) {
    playSlug = `ep-${opts.episodeId}`;
  } else if (tipo === "serie" && opts.temp != null && opts.ep != null) {
    playSlug = `${slug}/${opts.temp}/${opts.ep}`;
  }
  return abrirPlayerNativo({
    categoria: "megacine",
    slug: playSlug,
    titulo: opts.titulo || "",
    thumb: opts.thumb || "",
    filmeId: opts.filmeId || slug,
    tipo: tipo === "serie" ? "episodio" : "filme",
    serieCategoria: tipo === "serie" ? "megacine" : "",
    serieSlug: tipo === "serie" ? slug : "",
  });
}

export default async function paginaMegacineDetalhe(raiz, { tipo = "filme", slug = "" } = {}) {
  document.body.classList.add("ficha-mode");
  const page = el("div", { class: "page page-ficha" });
  raiz.append(page);
  page.append(el("div", { class: "center" }, [el("div", { class: "spinner" })]));

  const t = String(tipo || "filme").toLowerCase().includes("serie") ? "serie" : "filme";
  const s = decodeURIComponent(String(slug || "").trim());
  if (!s) {
    limpar(page);
    page.append(el("p", { class: "center" }, "Título inválido."));
    return page;
  }

  let dados;
  try {
    dados = await getMegacineDossier(t, s);
  } catch (e) {
    limpar(page);
    page.append(el("p", { class: "center" }, "Não foi possível carregar este título."));
    return page;
  }
  if (!dados) {
    limpar(page);
    page.append(el("p", { class: "center" }, "Título não encontrado."));
    return page;
  }

  try {
    const enr = await enriquecerComTmdb(
      {
        titulo: dados.titulo || s,
        nome: dados.titulo || s,
        tipo: t,
        ano: dados.ano,
        tmdb_id: dados.tmdb_id || dados.idtmdb,
        sinopse: dados.sinopse,
        nota: dados.nota,
        imagem: dados.capa || dados.imagem,
      },
      t,
    );
    if (enr) {
      if (enr.titulo) dados.titulo = enr.titulo;
      if (enr.capa || enr.poster || enr.imagem) dados.capa = enr.capa || enr.poster || enr.imagem;
      if (enr.banner || enr.backdrop) dados.banner = enr.banner || enr.backdrop;
      if (enr.sinopse) dados.sinopse = enr.sinopse;
      if (enr.nota != null && Number(enr.nota) > 0) dados.nota = enr.nota;
      if (enr.tmdb_id) dados.tmdb_id = enr.tmdb_id;
      if (enr.generos?.length) dados.generos = enr.generos;
    }
  } catch (_) {}

  const capa = dados.capa || dados.imagem || "";
  const filmeId = `cine-${t}-${s}`;
  let favorito = lerFavorito(filmeId, s, "megacine");
  const prog = lerProgresso({ categoria: "megacine", slug: s, filmeId });

  const gens = Array.isArray(dados.generos)
    ? dados.generos.map((g) => (typeof g === "string" ? g : g.nome || g.slug)).filter(Boolean)
    : [];

  function assistirFilme() {
    const ok = playMegacineNativo({
      tipo: "filme",
      slug: s,
      titulo: dados.titulo || s,
      thumb: capa,
      filmeId,
    });
    if (!ok) alert("Player indisponível.");
  }

  async function assistirEp(ep, tempNum) {
    const episodeId = ep.episode_id || ep.id || "";
    const num = ep.numero != null ? ep.numero : 1;
    const tituloEp = ep.titulo || `${dados.titulo} · T${tempNum}E${num}`;
    try {
      const ok = playMegacineNativo({
        tipo: "serie",
        slug: s,
        titulo: tituloEp,
        thumb: capa,
        filmeId: episodeId ? `cine-ep-${episodeId}` : filmeId,
        episodeId,
        temp: tempNum,
        ep: num,
      });
      if (!ok) alert("Player indisponível.");
    } catch (_) {
      alert("Falha ao abrir o episódio.");
    }
  }

  const after = [];
  if (t === "serie") {
    const temporadas = Array.isArray(dados.temporadas) ? dados.temporadas : [];
    if (temporadas.length) {
      after.push(
        montarEpisodiosUI({
          temporadas: temporadas.map((temp, idx) => ({
            numero: temp.numero || idx + 1,
            episodios: (temp.episodios || []).map((ep, ei) => ({
              ...ep,
              numero: ep.numero != null ? ep.numero : ei + 1,
              titulo: ep.titulo || ep.nome || "",
              imagem: ep.imagem || ep.thumb || capa,
              duracao: ep.duracao || null,
              episode_id: ep.episode_id || ep.id,
            })),
          })),
          serieCapa: capa,
          onPlayEp: (ep, tempNum, num) => assistirEp(ep, tempNum),
        }),
      );
    } else {
      after.push(el("p", { class: "sub", style: "padding:16px" }, "Episódios ainda não disponíveis."));
    }
  }

  limpar(page);
  page.append(
    montarFicha({
      titulo: dados.titulo || s,
      poster: capa,
      nota: dados.nota,
      ano: dados.ano,
      tipoLabel: t === "serie" ? "Série" : "Filme",
      temps: t === "serie" ? dados.total_temporadas || dados.temporadas?.length || null : null,
      generos: gens,
      sinopse: dados.sinopse || dados.descricao || "",
      favorito,
      playLabel:
        t === "filme"
          ? prog.percent > 0
            ? `Continuar · ${prog.percent}%`
            : "Assistir"
          : "Assistir",
      onPlay: () => {
        if (t === "filme") assistirFilme();
        else {
          const btn = page.querySelector(".ficha-ep-main");
          if (btn) btn.click();
          else page.querySelector(".ficha-eps")?.scrollIntoView({ behavior: "smooth" });
        }
      },
      onFavorite: () => {
        const r = toggleFavorito(
          filmeId,
          dados.titulo || "Tedflix",
          capa,
          t === "serie" ? "series" : "movie",
        );
        if (r && r.success !== false) {
          favorito = typeof r.favorito === "boolean" ? r.favorito : !favorito;
        }
        return { favorito };
      },
      after,
    }),
  );
  return page;
}
