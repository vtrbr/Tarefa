import { el, limpar } from "../dom.js";
import { getPlexHome, getPlexStream } from "../api.js";

function img(src, alt) {
  const i = el("img", { alt: alt || "", loading: "lazy", decoding: "async" });
  if (src) {
    i.src = src;
    i.addEventListener("error", () => { i.style.opacity = "0.2"; }, { once: true });
  }
  return i;
}

function abrirPlexLive(canal, categoriaNome, streamUrl, headers) {
  if (!streamUrl) return false;
  // força reconhecimento HLS no player nativo
  let url = streamUrl;
  if (!/\.m3u8/i.test(url) && !/mpegurl/i.test(url)) {
    url += (url.includes("?") ? "&" : "?") + "format=m3u8";
  }
  const servers = [
    {
      provider: "1. Plex Free TV",
      quality: "HD",
      embed_url: url,
      headers: headers || { "User-Agent": "Mozilla/5.0", Accept: "*/*" },
    },
  ];
  if (window.AndroidPlayer?.openLivePlayer) {
    window.AndroidPlayer.openLivePlayer(
      canal.id || canal.slug,
      canal.name || canal.nome || "Canal Plex",
      canal.logo || "",
      JSON.stringify(servers),
      "Transmissão ao vivo",
      categoriaNome || "Plex Free TV",
    );
    return true;
  }
  return false;
}

async function tocar(canal, categoriaNome) {
  try {
    const d = await getPlexStream(canal.id);
    if (!d?.ok) return false;
    const url = d.stream_proxy || d.stream;
    return abrirPlexLive(canal, categoriaNome, url, d.headers);
  } catch (_) {
    return false;
  }
}

function cardCanal(canal, categoriaNome) {
  const a = el("button", {
    type: "button",
    class: "pluto-card",
    "aria-label": `Assistir ${canal.name || canal.nome}`,
  });
  a.append(
    el("div", { class: "pluto-card-logo" }, [img(canal.logo, canal.name || canal.nome)]),
    el("div", { class: "pluto-card-body" }, [
      el("strong", {}, canal.name || canal.nome || "Canal"),
      el("span", { class: "pluto-now" }, canal.group || categoriaNome || "Ao vivo"),
    ]),
  );
  a.addEventListener("click", async () => {
    a.disabled = true;
    const ok = await tocar(canal, categoriaNome);
    if (!ok) {
      a.disabled = false;
      alert("Não foi possível abrir este canal agora.");
    } else {
      setTimeout(() => { a.disabled = false; }, 800);
    }
  });
  return a;
}

function fileira(titulo, canais, categoriaNome) {
  const wrap = el("section", { class: "pluto-row" });
  wrap.append(
    el("div", { class: "pluto-row-head" }, [
      el("h2", {}, titulo),
      el("span", { class: "pluto-count" }, `${canais.length} canais`),
    ]),
  );
  const scroller = el("div", { class: "pluto-scroller" });
  for (const c of canais) scroller.append(cardCanal(c, categoriaNome || titulo));
  wrap.append(scroller);
  return wrap;
}

export default async function paginaPlex(raiz) {
  const page = el("div", { class: "page pluto-page plex-page" });
  const head = el("div", { class: "pluto-hero plex-hero" }, [
    el("div", { class: "pluto-hero-text" }, [
      el("span", { class: "pluto-kicker" }, "TV ao vivo"),
      el("h1", {}, "Plex Free TV"),
      el("p", {}, "Centenas de canais grátis · sem login · transmissão ao vivo"),
    ]),
  ]);
  const slot = el("div", { class: "pluto-body" }, [
    el("div", { class: "skel", style: "height:120px;margin:12px 0;border-radius:12px" }),
  ]);
  page.append(head, slot);
  raiz.append(page);

  try {
    const data = await getPlexHome("us");
    if (!page.isConnected) return;
    limpar(slot);
    if (!data?.ok) {
      slot.append(el("p", { class: "empty" }, "Plex indisponível no momento."));
      return;
    }
    const featured = Array.isArray(data.featured) ? data.featured : [];
    const channels = Array.isArray(data.channels) ? data.channels : [];

    if (featured.length) {
      slot.append(fileira("Em destaque", featured.slice(0, 40), "Destaques"));
    }

    const byGroup = new Map();
    for (const c of channels) {
      const g = c.group || c.regions?.[0] || "Todos";
      if (!byGroup.has(g)) byGroup.set(g, []);
      byGroup.get(g).push(c);
    }
    for (const [g, list] of byGroup) {
      slot.append(fileira(g, list.slice(0, 120), g));
    }
    if (!slot.children.length) {
      slot.append(el("p", { class: "empty" }, "Nenhum canal Plex encontrado."));
    }
  } catch (e) {
    if (!page.isConnected) return;
    limpar(slot);
    slot.append(
      el("p", { class: "empty" }, "Falha ao carregar Plex Free TV."),
      el("p", { class: "muted", style: "font-size:12px" }, String(e.message || e)),
    );
  }
}
