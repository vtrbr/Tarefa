import { el, limpar } from "../dom.js";
import { gradeVirtual } from "../components/virtual-grid.js";
import { getProviderCatalog, providerTabs } from "../api.js";

function titleCaseSlug(slug) {
  const map = {
    netflix: "Netflix",
    "prime-video": "Prime Video",
    "disney-plus": "Disney+",
    "apple-tv-plus": "Apple TV+",
    max: "Max",
    "paramount-plus": "Paramount+",
    globoplay: "Globoplay",
    crunchyroll: "Crunchyroll",
    "mgm-plus": "MGM+",
  };
  return map[slug] || slug.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

/**
 * Catálogo de streaming: filtros Filmes/Séries (+ Doramas/Novelas quando houver)
 * sem barra de busca interna. Merge Donflix + MegaFilmes.
 */
export default function paginaStreaming(raiz, { slug, tabInicial = "filmes" } = {}) {
  const s = String(slug || "").toLowerCase();
  const tabs = providerTabs(s);
  let tab = tabs.some((t) => t.id === tabInicial) ? tabInicial : "filmes";

  const page = el("div", { class: "page page-streaming" });
  const chips = el("div", { class: "stream-tabs" });
  const info = el("p", { class: "sub stream-info" }, "Carregando…");
  const area = el("div", { class: "stream-grid pad" });

  page.append(
    el("div", { class: "stream-head pad" }, [
      el("h1", { class: "page-title" }, titleCaseSlug(s)),
      chips,
      info,
    ]),
    area,
  );
  raiz.append(page);

  let grade = null;
  let loadToken = 0;

  function setChipActive() {
    [...chips.children].forEach((c) => {
      c.classList.toggle("is-on", c.dataset.tab === tab);
    });
  }

  tabs.forEach((t) => {
    const btn = el("button", {
      type: "button",
      class: "stream-tab",
      "data-tab": t.id,
    }, t.label);
    btn.onclick = () => {
      if (tab === t.id) return;
      tab = t.id;
      setChipActive();
      // atualiza hash sem reload completo se possível
      try {
        history.replaceState(null, "", `#/streaming/${encodeURIComponent(s)}/${tab}`);
      } catch (_) {}
      carregar();
    };
    chips.append(btn);
  });
  setChipActive();

  async function carregar() {
    const token = ++loadToken;
    if (grade) {
      try {
        grade.destruir?.();
      } catch (_) {}
      grade = null;
    }
    limpar(area);
    info.textContent = "Carregando…";
    area.append(el("div", { class: "center" }, [el("div", { class: "spinner" })]));
    try {
      const r = await getProviderCatalog(s, tab, 1);
      if (token !== loadToken) return;
      const itens = r.itens || [];
      limpar(area);
      info.textContent = `${itens.length} título${itens.length === 1 ? "" : "s"}`;
      if (!itens.length) {
        area.append(el("p", { class: "center sub" }, "Nada por aqui neste filtro."));
        return;
      }
      grade = gradeVirtual(itens);
      area.append(grade);
    } catch (_) {
      if (token !== loadToken) return;
      limpar(area);
      info.textContent = "Não foi possível carregar.";
      area.append(el("p", { class: "center" }, "Tente de novo em instantes."));
    }
  }

  carregar();
  page.destruir = () => {
    try {
      grade?.destruir?.();
    } catch (_) {}
  };
  return page;
}
