import { el, limpar } from "../dom.js";
import {
  getRedeCanaisHome,
  getRedeCanaisChannels,
  getRedeCanaisStream,
  getJSON,
} from "../api.js";
import { REDECANAIS_API_BASE, LIVE_API_BASE } from "../config.js";

function img(src, alt) {
  const i = el("img", { alt: alt || "", loading: "lazy", decoding: "async" });
  if (src) {
    i.src = src;
    i.addEventListener("error", () => { i.style.opacity = "0.2"; }, { once: true });
  }
  return i;
}

/** Monta lista de servidores: 1 = Rede Canais stream, 2 = Rei dos Canais embeds */
async function montarServidores(canal) {
  const servers = [];
  const slug = canal.slug || canal.id;

  // 1) Rede Canais (v9)
  try {
    const d = await getRedeCanaisStream(slug);
    const url = d?.stream_proxy || d?.stream;
    if (d?.ok && url && !/test\/master\.m3u8/i.test(url)) {
      servers.push({
        provider: "1. Rede Canais",
        quality: "HD",
        embed_url: url,
      });
    } else if (d?.embed || d?.final) {
      servers.push({
        provider: "1. Rede Canais",
        quality: "HD",
        embed_url: d.stream_proxy || d.embed || d.final,
      });
    }
  } catch (_) {}

  // 2) Rei dos Canais (api.reidoscanais.si) — embeds resolvidos pelo LivePlayer
  try {
    const id = String(slug || "").replace(/^24h-/, "").replace(/-/g, "") || slug;
    // tenta id direto e slug
    let detail = null;
    for (const key of [slug, canal.id, id]) {
      if (!key) continue;
      try {
        const r = await fetch(
          `${LIVE_API_BASE}/channels/${encodeURIComponent(key)}`,
          { headers: { Accept: "application/json" } },
        );
        if (r.ok) {
          const j = await r.json();
          if (j?.success && j.data) {
            detail = j.data;
            break;
          }
        }
      } catch (_) {}
    }
    // fallback: busca por nome
    if (!detail) {
      try {
        const r = await fetch(
          `${LIVE_API_BASE}/search?q=${encodeURIComponent(canal.name || canal.nome || slug)}`,
          { headers: { Accept: "application/json" } },
        );
        if (r.ok) {
          const j = await r.json();
          const list = j.data || j.channels || j.results || [];
          const hit = (Array.isArray(list) ? list : []).find((c) =>
            String(c.name || "")
              .toLowerCase()
              .includes(String(canal.name || canal.nome || "").toLowerCase().slice(0, 8)),
          );
          if (hit?.embeds?.length) detail = hit;
          else if (hit?.id) {
            const r2 = await fetch(`${LIVE_API_BASE}/channels/${encodeURIComponent(hit.id)}`);
            if (r2.ok) {
              const j2 = await r2.json();
              detail = j2.data || j2;
            }
          }
        }
      } catch (_) {}
    }
    const embeds = detail?.embeds || [];
    for (const em of embeds) {
      if (!em?.embed_url) continue;
      servers.push({
        provider: "2. Rei dos Canais",
        quality: em.quality || "FULL HD",
        embed_url: em.embed_url,
      });
    }
  } catch (_) {}

  // se só temos embed do v9 (mesmo test), ainda assim tenta
  if (!servers.length) {
    try {
      const d = await getRedeCanaisStream(slug);
      if (d?.stream_proxy || d?.stream || d?.embed) {
        servers.push({
          provider: "1. Rede Canais",
          quality: "HD",
          embed_url: d.stream_proxy || d.stream || d.embed,
        });
      }
    } catch (_) {}
  }
  return servers;
}

function abrirLive(canal, categoriaNome, servers) {
  if (!servers?.length) return false;
  if (window.AndroidPlayer?.openLivePlayer) {
    window.AndroidPlayer.openLivePlayer(
      canal.id || canal.slug,
      canal.name || canal.nome || "Canal",
      canal.logo || "",
      JSON.stringify(servers),
      "Transmissão ao vivo",
      categoriaNome || "Rede Canais",
    );
    return true;
  }
  return false;
}

async function tocar(canal, categoriaNome) {
  const servers = await montarServidores(canal);
  if (!servers.length) return false;
  return abrirLive(canal, categoriaNome, servers);
}

function cardCanal(canal, categoriaNome) {
  const a = el("button", {
    type: "button",
    class: "pluto-card",
    "aria-label": `Assistir ${canal.name || canal.nome}`,
  });
  a.append(
    el("div", { class: "pluto-card-logo" }, [img(canal.logo, canal.name || canal.nome)]),
    el("div", { class: "pluto-card-body" }, [
      el("strong", {}, canal.name || canal.nome || "Canal"),
      el("span", { class: "pluto-now" }, canal.category || categoriaNome || "Ao vivo"),
    ]),
  );
  a.addEventListener("click", async () => {
    a.disabled = true;
    const ok = await tocar(canal, categoriaNome);
    if (!ok) {
      a.disabled = false;
      alert("Não foi possível abrir este canal agora.");
    } else {
      setTimeout(() => { a.disabled = false; }, 800);
    }
  });
  return a;
}

function fileira(titulo, canais, categoriaNome) {
  const wrap = el("section", { class: "pluto-row" });
  wrap.append(
    el("div", { class: "pluto-row-head" }, [
      el("h2", {}, titulo),
      el("span", { class: "pluto-count" }, `${canais.length} canais`),
    ]),
  );
  const scroller = el("div", { class: "pluto-scroller" });
  for (const c of canais) scroller.append(cardCanal(c, categoriaNome || titulo));
  wrap.append(scroller);
  return wrap;
}

export default async function paginaRedeCanais(raiz) {
  const page = el("div", { class: "page pluto-page rede-page" });
  const head = el("div", { class: "pluto-hero rede-hero" }, [
    el("div", { class: "pluto-hero-text" }, [
      el("span", { class: "pluto-kicker" }, "TV ao vivo · Brasil"),
      el("h1", {}, "Rede Canais"),
      el("p", {}, "Canais brasileiros · 2 servidores no player (Rede + Rei dos Canais)"),
    ]),
  ]);
  const slot = el("div", { class: "pluto-body" }, [
    el("div", { class: "skel", style: "height:120px;margin:12px 0;border-radius:12px" }),
  ]);
  page.append(head, slot);
  raiz.append(page);

  try {
    // Preferir catálogo Rei dos Canais (embeds reais) + mesclar v9
    let channels = [];
    let cats = [];
    try {
      const live = await fetch(`${LIVE_API_BASE}/channels`, { headers: { Accept: "application/json" } }).then((r) => r.json());
      if (live?.success && Array.isArray(live.data)) {
        channels = live.data.map((c) => ({
          id: c.id,
          slug: c.id,
          name: c.name,
          logo: c.logo_url,
          category: c.category,
          embeds: c.embeds,
        }));
      }
      const lc = await fetch(`${LIVE_API_BASE}/channels/categories`, { headers: { Accept: "application/json" } }).then((r) => r.json());
      if (lc?.success) cats = (lc.data || []).map((c) => ({ id: c.name, name: c.name, count: 0 }));
    } catch (_) {}

    if (!channels.length) {
      const data = await getRedeCanaisHome();
      channels = data.channels || data.featured || [];
      cats = data.categories || [];
    }

    if (!page.isConnected) return;
    limpar(slot);

    if (cats.length) {
      const chips = el("div", { class: "pluto-chips" });
      for (const cat of cats) {
        const chip = el("button", { type: "button", class: "pluto-chip" }, cat.name || cat.id);
        chip.addEventListener("click", () => {
          const row = page.querySelector(`[data-cat="${CSS.escape(cat.name || cat.id)}"]`);
          if (row) row.scrollIntoView({ behavior: "smooth", block: "start" });
        });
        chips.append(chip);
      }
      slot.append(chips);
      for (const cat of cats) {
        const list = channels.filter(
          (c) => String(c.category || "").toLowerCase() === String(cat.name || cat.id || "").toLowerCase(),
        );
        if (!list.length) continue;
        const row = fileira(cat.name || cat.id, list, cat.name);
        row.dataset.cat = cat.name || cat.id;
        slot.append(row);
      }
    } else if (channels.length) {
      slot.append(fileira("Todos os canais", channels, "Rede Canais"));
    } else {
      slot.append(el("p", { class: "empty" }, "Nenhum canal encontrado."));
    }
  } catch (e) {
    if (!page.isConnected) return;
    limpar(slot);
    slot.append(
      el("p", { class: "empty" }, "Falha ao carregar canais."),
      el("p", { class: "muted", style: "font-size:12px" }, String(e.message || e)),
    );
  }
}
