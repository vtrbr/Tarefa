import { el, limpar, anoCurto } from "../dom.js";
import * as SrcNew from "../sources-new.js";
import { abrirPlayerNativo, lerProgresso, mapaProgressoSerie, lerFavorito } from "../playback.js";
import { enriquecerComTmdb } from "../api.js";
import { montarFicha, montarEpisodiosUI } from "../components/ficha.js";

function pickDetalhe(d) {
  if (!d) return null;
  const tit = d.titulo || {};
  const img = d.imagens || {};
  const textos = d.textos || {};
  const desc = d.descricao || {};
  const metricas = d.metricas || {};
  const ids = d.ids || {};
  const player = d.player || {};
  const classif = d.classificacao || {};
  const gens = classif.generos || d.generos || metricas.generos || [];
  return {
    nome: tit.principal || tit.nome || d.nome || d.titulo || "",
    slug: tit.slug || d.slug || "",
    tipo: String(tit.tipo || d.tipo || "filme").toLowerCase(),
    ano: tit.ano || d.ano || null,
    poster: img.poster || d.url_imagem || d.capa || d.poster || null,
    backdrop: img.backdrop || d.backdrop || img.banner || null,
    overview:
      desc.sinopse ||
      d.overview ||
      d.sinopse ||
      textos.sinopse ||
      textos.descricao ||
      "",
    nota: metricas.nota_tmdb || d.nota_tmdb || d.nota || null,
    generos: Array.isArray(gens) ? gens : [],
    tmdb_id: player.tmdb_id || d.tmdb_id || ids.tmdb || tit.tmdb_id || null,
    video_path: player.video_path || null,
    temporadas: d.temporadas || d.seasons || player.temporadas || [],
    total_temporadas: tit.total_temporadas || player.total_temporadas || null,
    classificacao: classif.indicativa || classif.age || null,
    duracao: metricas.duracao || d.duracao || null,
  };
}

export async function paginaDonflix(raiz, { tipo, id }) {
  return paginaFonte(raiz, { api: "donflix", tipo, id });
}

export async function paginaMegafilmes(raiz, { tipo, id }) {
  return paginaFonte(raiz, { api: "megafilmes", tipo, id });
}

async function paginaFonte(raiz, { api, tipo, id }) {
  document.body.classList.add("ficha-mode");
  const page = el("div", { class: "page page-ficha" });
  raiz.append(page);
  page.append(el("div", { class: "center detail-loading" }, [el("div", { class: "spinner" })]));

  let raw;
  try {
    if (api === "donflix") {
      raw =
        tipo === "serie"
          ? await SrcNew.donflixDetalheSerie(id)
          : await SrcNew.donflixDetalheFilme(id);
    } else {
      raw = await SrcNew.megafilmesDetalhe(tipo, id);
    }
  } catch (e) {
    limpar(page);
    page.append(el("p", { class: "center" }, "Não foi possível carregar este título."));
    return page;
  }

  let d = pickDetalhe(raw);
  if (!d || !d.nome) {
    limpar(page);
    page.append(el("p", { class: "center" }, "Título não encontrado."));
    return page;
  }

  try {
    const en = await enriquecerComTmdb(
      {
        titulo: d.nome,
        nome: d.nome,
        ano: d.ano,
        tipo: d.tipo,
        tmdb_id: d.tmdb_id,
        imagem: d.poster,
        sinopse: d.overview,
        nota: d.nota,
        generos: d.generos,
      },
      tipo,
    );
    if (en) {
      d.nome = en.titulo || en.nome || d.nome;
      d.overview = en.sinopse || en.descricao || d.overview;
      d.poster = en.capa || en.poster || en.imagem || d.poster;
      d.backdrop = en.banner || en.backdrop || d.backdrop;
      if (en.nota != null && Number(en.nota) > 0) d.nota = en.nota;
      if (en.generos?.length) d.generos = en.generos;
      if (en.tmdb_id) d.tmdb_id = en.tmdb_id;
      if (en.ano) d.ano = en.ano;
    }
  } catch (_) {}

  const isSerie = /ser/.test(String(d.tipo || tipo));
  const filmeId = String(d.tmdb_id || id);
  let favorito = false;
  try {
    favorito = !!lerFavorito(filmeId, String(id), api);
  } catch (_) {}

  // Progresso LOCAL na hora (0 atraso). API sincroniza por baixo no nativo.
  const catPlay = api === "donflix" ? "donflix" : "megafilmes";
  const idKey = String(d.tmdb_id || id);
  let progressFilme = 0;
  if (!isSerie) {
    const pr = lerProgresso({
      categoria: catPlay,
      slug: `filme-${idKey}`,
      filmeId: idKey,
      idtmdb: idKey,
    });
    progressFilme = pr.percent || 0;
  }
  const progEps = isSerie
    ? mapaProgressoSerie({ categoria: catPlay, serieId: idKey, serieSlug: idKey })
    : {};

  const after = [];
  if (isSerie && Array.isArray(d.temporadas) && d.temporadas.length) {
    after.push(
      montarEpisodiosUI({
        temporadas: d.temporadas.map((t, idx) => {
          const numT = t.numero || t.season_number || idx + 1;
          return {
            numero: numT,
            episodios: (t.episodios || t.episodes || []).map((ep, ei) => {
              const numE = ep.numero || ep.episode_number || ei + 1;
              const pct = progEps[`${numT}-${numE}`] || 0;
              return {
                numero: numE,
                titulo: ep.nome || ep.name || ep.titulo || "",
                imagem: ep.still || ep.imagem || ep.thumb || d.poster,
                video_path: ep.video_path || null,
                duracao: ep.duracao || ep.runtime || null,
                progresso: pct > 0 ? pct : null,
              };
            }),
          };
        }),
        serieCapa: d.poster || "",
        onPlayEp: (ep, temp, num) => play(d, temp, num),
      }),
    );
  }

  function play(dNow, temp, ep) {
    const tmdb = dNow.tmdb_id || (String(id).match(/^\d+$/) ? id : null);
    const isSer = /ser/.test(String(dNow.tipo || tipo));
    if (api === "donflix") {
      const t = temp || 1;
      const e = ep || 1;
      const baseId = tmdb || id;
      const slugPlay = isSer ? `serie-${baseId}-${t}-${e}` : `filme-${baseId}`;
      // filmeId único por EP para API de progresso (não a série inteira)
      const filmeIdPlay = isSer ? `serie-${baseId}-${t}-${e}` : String(baseId);
      abrirPlayerNativo({
        categoria: "donflix",
        slug: slugPlay,
        titulo: isSer
          ? `${dNow.nome} · S${t}E${e}`
          : dNow.nome,
        tipo: isSer ? "episodio" : "filme",
        thumb: dNow.poster || "",
        filmeId: filmeIdPlay,
        serieCategoria: isSer ? "donflix" : "",
        serieSlug: isSer ? String(baseId) : "",
      });
    } else {
      const mid = raw?.ids?.id || raw?.id || id;
      const t = temp || 1;
      const e = ep || 1;
      const slugPlay = isSer ? `serie-${mid}-${t}-${e}` : `filme-${mid}`;
      const filmeIdPlay = isSer ? `serie-${mid}-${t}-${e}` : String(mid);
      abrirPlayerNativo({
        categoria: "megafilmes",
        slug: slugPlay,
        titulo: isSer ? `${dNow.nome} · S${t}E${e}` : dNow.nome,
        tipo: isSer ? "episodio" : "filme",
        thumb: dNow.poster || "",
        filmeId: filmeIdPlay,
        serieCategoria: isSer ? "megafilmes" : "",
        serieSlug: isSer ? String(mid) : "",
      });
    }
  }

  limpar(page);
  page.append(
    montarFicha({
      titulo: d.nome,
      poster: d.poster,
      nota: d.nota,
      ano: anoCurto(d.ano) || d.ano,
      tipoLabel: isSerie ? "Série" : "Filme",
      duracao: !isSerie ? d.duracao : null,
      temps: isSerie ? d.total_temporadas || d.temporadas?.length || null : null,
      classificacao: d.classificacao,
      generos: d.generos,
      sinopse: d.overview,
      favorito,
      progress: !isSerie && progressFilme > 0 ? progressFilme : null,
      playLabel: isSerie ? "Assistir" : progressFilme > 0 ? "Continuar" : "Assistir",
      onPlay: () => play(d),
      onFavorite: () => {
        try {
          const resposta = JSON.parse(
            window.AndroidPlayer?.toggleFavorite?.(
              filmeId,
              d.nome || "Tedflix",
              d.poster || "",
              isSerie ? "series" : "movie",
            ) || "{}",
          );
          if (resposta.success) {
            favorito =
              typeof resposta.favorito === "boolean" ? resposta.favorito : !favorito;
          }
        } catch (_) {}
        return { favorito };
      },
      after,
    }),
  );
  return page;
}

export default paginaDonflix;
