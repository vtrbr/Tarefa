import { el, limpar, svgIcone } from "../dom.js";
import {
  getTedv2Movie,
  getTedv2Series,
  getTedv2Season,
} from "../api.js";
import { lerFavorito, toggleFavorito, abrirPlayerNativo } from "../playback.js";

/**
 * Detalhe TEDFLIX API v2
 * Filme/série: catálogo TMDB; play resolve via CONTENT/Mega (sem Amenic).
 */

/**
 * TED v2 não tem stream (Amenic CF 403). Resolve play via CONTENT/MegaCine pelo título.
 */
async function playTedv2({ imdb, titulo, thumb, filmeId, lang = "dub", temp, ep, tipo }) {
  const hit = await resolverPlayPorTitulo(titulo, {
    tipoPreferido: tipo === "serie" || temp != null ? "serie" : "filme",
  });
  if (!hit) {
    try {
      alert("Sem fonte de reprodução para este título no momento.");
    } catch (_) {}
    return false;
  }

  // MegaCine
  if (hit.fonte === "megacine" || String(hit.link_assistir || "").includes("#/cine/")) {
    const slug = hit.slug || "";
    const isSerie = /serie|séri/i.test(String(hit.tipo || ""));
    if (isSerie && temp != null && ep != null) {
      return abrirPlayerNativo({
        categoria: "megacine",
        slug: `${slug}/${temp}/${ep}`,
        titulo: titulo || hit.titulo || "",
        filmeId: filmeId || slug,
        thumb: thumb || hit.capa || hit.imagem || "",
        tipo: "episodio",
        serieCategoria: "megacine",
        serieSlug: slug,
      });
    }
    return abrirPlayerNativo({
      categoria: "megacine",
      slug,
      titulo: titulo || hit.titulo || "",
      filmeId: filmeId || slug,
      thumb: thumb || hit.capa || hit.imagem || "",
      tipo: isSerie ? "serie" : "filme",
    });
  }

  // Conteúdo ativo: rota explícita ou rota genérica de detalhe.
  let categoria = hit.categoria || "";
  let slug = hit.slug || "";
  if ((!categoria || !slug) && hit.link_assistir) {
    const m = String(hit.link_assistir).match(/#\/titulo\/(?:filme|serie)\/([^/]+)\/([^/?#]+)/i)
      || String(hit.link_assistir).match(/#\/(?:megafilmes|donflix)\/(?:filme|serie)\/([^/?#]+)\/([^/?#]+)/i);
    if (m) {
      categoria = categoria || m[1];
      slug = slug || m[2];
    }
  }
  if (!categoria || !slug) {
    try {
      alert("Título encontrado, mas sem rota de player.");
    } catch (_) {}
    return false;
  }
  return abrirPlayerNativo({
    categoria,
    slug,
    titulo: titulo || hit.titulo || "",
    filmeId: filmeId || slug,
    thumb: thumb || hit.capa || hit.imagem || "",
    tipo: /serie|séri/i.test(String(hit.tipo || "")) ? "serie" : "filme",
  });
}

function metaLinha(parts) {
  return parts.filter(Boolean).join(" · ");
}

function blocoGeneros(genres) {
  const list = Array.isArray(genres) ? genres : [];
  if (!list.length) return null;
  const wrap = el("div", { class: "tedv2-tags" });
  list.forEach((g) => {
    const nome = typeof g === "string" ? g : g?.name || "";
    if (!nome) return;
    wrap.append(el("span", { class: "tedv2-tag" }, nome));
  });
  return wrap.childNodes.length ? wrap : null;
}

function blocoElenco(cast) {
  const list = Array.isArray(cast) ? cast : [];
  if (!list.length) return null;
  const section = el("div", { class: "tedv2-cast-section" });
  section.append(el("h2", { class: "tedv2-section-title" }, "Elenco"));
  const rail = el("div", { class: "tedv2-cast-rail" });
  list.slice(0, 14).forEach((c) => {
    const card = el("div", { class: "tedv2-cast-card" });
    if (c.profile) {
      card.append(
        el("img", {
          class: "tedv2-cast-photo",
          src: c.profile,
          alt: c.name || "",
          loading: "lazy",
          decoding: "async",
        }),
      );
    } else {
      card.append(el("div", { class: "tedv2-cast-photo tedv2-cast-photo--empty" }));
    }
    card.append(el("p", { class: "tedv2-cast-name" }, c.name || "—"));
    if (c.character) {
      card.append(el("p", { class: "tedv2-cast-role" }, c.character));
    }
    rail.append(card);
  });
  section.append(rail);
  return section;
}

export async function paginaTedv2Filme(raiz, tmdbId) {
  const page = el("div", { class: "page page-detail page-tedv2" });
  raiz.append(page);
  page.append(el("div", { class: "center detail-loading" }, [el("div", { class: "spinner" })]));

  let dados;
  try {
    dados = await getTedv2Movie(tmdbId);
  } catch (_) {
    dados = null;
  }
  limpar(page);
  if (!dados) {
    page.append(el("p", { class: "center pad" }, "Não foi possível carregar este filme."));
    return page;
  }

  const imdb = dados.imdb || "";
  const titulo = dados.titulo || dados.title || "Filme";
  const capa = dados.banner || dados.backdrop || dados.capa || dados.poster || "";
  const filmeId = `tedv2-${dados.tmdb || tmdbId}`;
  let favorito = lerFavorito(filmeId, String(dados.tmdb || tmdbId), "tedv2");

  const hero = el("div", { class: "detail-hero" });
  if (capa) {
    hero.append(
      el("img", {
        src: capa,
        alt: titulo,
        class: "detail-hero-img",
        decoding: "async",
      }),
    );
  }
  hero.append(el("div", { class: "veil" }));
  page.append(hero);

  const info = el("div", { class: "detail-info pad" });
  info.append(el("h1", {}, titulo));
  info.append(
    el(
      "p",
      { class: "sub tedv2-meta" },
      metaLinha([
        dados.vote_average != null ? `★ ${Number(dados.vote_average).toFixed(1)}` : "",
        "Filme",
        dados.year || dados.ano || "",
        dados.runtime ? `${dados.runtime} min` : "",
      ]),
    ),
  );

  const acoes = el("div", { class: "detail-actions tedv2-actions" });
  const btnDub = el("button", { type: "button", class: "btn primary" }, "▶ Assistir dublado");
  const btnLeg = el("button", { type: "button", class: "btn ghost" }, "▶ Assistir legendado");
  const btnFav = el(
    "button",
    { type: "button", class: "btn ghost" },
    favorito ? "♥ Na lista" : "♡ Favorito",
  );

  btnDub.addEventListener("click", async () => {
    btnDub.disabled = true;
    try {
      const ok = await playTedv2({ imdb, titulo, thumb: capa, filmeId, lang: "dub", tipo: "filme" });
      if (!ok) {
        /* playTedv2 already alerts */
      }
    } finally {
      btnDub.disabled = false;
    }
  });
  btnLeg.addEventListener("click", async () => {
    btnLeg.disabled = true;
    try {
      await playTedv2({ imdb, titulo, thumb: capa, filmeId, lang: "sub", tipo: "filme" });
    } finally {
      btnLeg.disabled = false;
    }
  });
  btnFav.addEventListener("click", () => {
    favorito = toggleFavorito({
      filmeId,
      slug: String(dados.tmdb || tmdbId),
      categoria: "tedv2",
      titulo,
      thumb: capa,
      tipo: "filme",
    });
    btnFav.textContent = favorito ? "♥ Na lista" : "♡ Favorito";
  });

  if (imdb) {
    acoes.append(btnDub, btnLeg);
  } else {
    acoes.append(el("p", { class: "sub" }, "Reprodução indisponível (sem IMDb)."));
  }
  acoes.append(btnFav);
  info.append(acoes);

  if (dados.sinopse || dados.overview) {
    info.append(el("p", { class: "detail-sinopse" }, dados.sinopse || dados.overview));
  }

  const gens = blocoGeneros(dados.genres);
  if (gens) info.append(gens);

  const elenco = blocoElenco(dados.cast);
  if (elenco) info.append(elenco);

  page.append(info);
  return page;
}

export async function paginaTedv2Serie(raiz, tmdbId) {
  const page = el("div", { class: "page page-detail page-tedv2" });
  raiz.append(page);
  page.append(el("div", { class: "center detail-loading" }, [el("div", { class: "spinner" })]));

  let dados;
  try {
    dados = await getTedv2Series(tmdbId);
  } catch (_) {
    dados = null;
  }
  limpar(page);
  if (!dados) {
    page.append(el("p", { class: "center pad" }, "Não foi possível carregar esta série."));
    return page;
  }

  const imdb = dados.imdb || "";
  const titulo = dados.titulo || dados.title || "Série";
  const capa = dados.banner || dados.backdrop || dados.capa || dados.poster || "";
  const filmeId = `tedv2-${dados.tmdb || tmdbId}`;
  let favorito = lerFavorito(filmeId, String(dados.tmdb || tmdbId), "tedv2");

  const hero = el("div", { class: "detail-hero" });
  if (capa) {
    hero.append(
      el("img", {
        src: capa,
        alt: titulo,
        class: "detail-hero-img",
        decoding: "async",
      }),
    );
  }
  hero.append(el("div", { class: "veil" }));
  page.append(hero);

  const info = el("div", { class: "detail-info pad" });
  info.append(el("h1", {}, titulo));
  info.append(
    el(
      "p",
      { class: "sub tedv2-meta" },
      metaLinha([
        dados.vote_average != null ? `★ ${Number(dados.vote_average).toFixed(1)}` : "",
        "Série",
        dados.year || dados.ano || "",
        dados.number_of_seasons ? `${dados.number_of_seasons} temp.` : "",
      ]),
    ),
  );

  const btnFav = el(
    "button",
    { type: "button", class: "btn ghost" },
    favorito ? "♥ Na lista" : "♡ Favorito",
  );
  btnFav.addEventListener("click", () => {
    favorito = toggleFavorito({
      filmeId,
      slug: String(dados.tmdb || tmdbId),
      categoria: "tedv2",
      titulo,
      thumb: capa,
      tipo: "serie",
    });
    btnFav.textContent = favorito ? "♥ Na lista" : "♡ Favorito";
  });
  info.append(el("div", { class: "detail-actions tedv2-actions" }, [btnFav]));

  if (dados.sinopse || dados.overview) {
    info.append(el("p", { class: "detail-sinopse" }, dados.sinopse || dados.overview));
  }

  const gens = blocoGeneros(dados.genres);
  if (gens) info.append(gens);

  const elenco = blocoElenco(dados.cast);
  if (elenco) info.append(elenco);

  page.append(info);

  // Temporadas
  const seasons = (dados.seasons || []).filter((s) => Number(s.season_number) > 0);
  const epSection = el("div", { class: "pad detail-eps tedv2-eps" });
  epSection.append(el("h2", { class: "tedv2-section-title" }, "Episódios"));
  const tabs = el("div", { class: "tedv2-season-tabs", role: "tablist" });
  const list = el("div", { class: "tedv2-ep-list" });
  epSection.append(tabs, list);
  page.append(epSection);

  let currentSeason = seasons[0]?.season_number || 1;

  async function carregarTemp(n) {
    currentSeason = n;
    [...tabs.querySelectorAll(".tedv2-season-tab")].forEach((b) => {
      b.classList.toggle("ativo", Number(b.dataset.s) === n);
      b.setAttribute("aria-selected", Number(b.dataset.s) === n ? "true" : "false");
    });
    limpar(list);
    list.append(el("div", { class: "center" }, [el("div", { class: "spinner" })]));
    let eps = [];
    try {
      const data = await getTedv2Season(tmdbId, n);
      eps = data.episodes || [];
    } catch (_) {
      eps = [];
    }
    limpar(list);
    if (!eps.length) {
      list.append(el("p", { class: "sub" }, "Nenhum episódio encontrado."));
      return;
    }
    eps.forEach((ep) => {
      const num = ep.episode_number != null ? ep.episode_number : "?";
      const nome = ep.name || `Episódio ${num}`;
      const row = el("div", { class: "tedv2-ep-row" });
      const still = ep.still || capa || "";
      if (still) {
        row.append(
          el("img", {
            class: "tedv2-ep-thumb",
            src: still,
            alt: "",
            loading: "lazy",
          }),
        );
      }
      const body = el("div", { class: "tedv2-ep-body" });
      body.append(el("strong", { class: "tedv2-ep-title" }, `E${num} · ${nome}`));
      if (ep.overview) {
        body.append(
          el("p", { class: "sub tedv2-ep-overview" }, String(ep.overview).slice(0, 140)),
        );
      }
      row.append(body);
      const play = el(
        "button",
        { type: "button", class: "tedv2-ep-play", "aria-label": "Assistir" },
        "▶",
      );
      play.addEventListener("click", async () => {
        if (
          !playTedv2({
            imdb,
            titulo: `${titulo} — T${n}E${num}`,
            thumb: ep.still || capa,
            filmeId: `tedv2-${tmdbId}-t${n}e${num}`,
            lang: "dub",
            temp: n,
            ep: num,
            tipo: "serie",
          })
        ) {
          alert("Player indisponível neste aparelho.");
        }
      });
      row.append(play);
      list.append(row);
    });
  }

  seasons.forEach((s) => {
    const n = s.season_number;
    const b = el(
      "button",
      {
        type: "button",
        class: "tedv2-season-tab",
        "data-s": String(n),
        role: "tab",
        "aria-selected": "false",
      },
      `T${n}`,
    );
    b.addEventListener("click", () => carregarTemp(n));
    tabs.append(b);
  });
  if (seasons.length) carregarTemp(currentSeason);
  else list.append(el("p", { class: "sub" }, "Sem temporadas."));

  return page;
}

export default async function paginaTedv2Detalhe(raiz, { tipo, id }) {
  if (tipo === "serie" || tipo === "series") return paginaTedv2Serie(raiz, id);
  return paginaTedv2Filme(raiz, id);
}
