import { el, limpar, anoCurto } from "../dom.js";
import {
  getTitulo,
  getTemporadas,
  getEpisodios,
  parseLink,
  getTedtopFilme,
  extrairYoutubeId,
  enriquecerComTmdb,
  enriquecerEpisodiosComTmdb,
  extrairTmdbId,
} from "../api.js";
import { backdrop, poster } from "../img.js";
import { lerProgresso, lerFavorito, mapaProgresso } from "../playback.js";
import { cardTitulo } from "../components/card.js";
import { montarFicha, montarEpisodiosUI } from "../components/ficha.js";

function blocoTrailer(trailerUrl) {
  const videoId = extrairYoutubeId(trailerUrl);
  if (!videoId) return null;
  const wrap = el("div", {
    class: "trailer-wrap",
    style:
      "margin-top:8px;position:relative;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:12px;background:#111",
  });
  wrap.append(
    el("iframe", {
      src: `https://www.youtube.com/embed/${videoId}?rel=0&modestbranding=1`,
      title: "Trailer",
      frameborder: "0",
      allow:
        "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
      allowfullscreen: "true",
      style: "position:absolute;top:0;left:0;width:100%;height:100%;border:0",
      loading: "lazy",
    }),
  );
  return el("section", { class: "trailer-section" }, [
    el("h2", { class: "ficha-eps-title" }, "Trailer"),
    wrap,
  ]);
}

function dadosParaPlayer(item) {
  if (!item) return null;
  const p = parseLink(item.link_assistir || item.link);
  const categoria = item.categoria || p.categoria;
  const slug = item.slug || p.slug;
  if (!categoria || !slug) return null;
  return {
    categoria,
    slug,
    filmeId: String(item.filmeId || item.id || item._id || slug),
    thumb: item.imagem || item.thumb || "",
    titulo: item.titulo || "",
    tipo: item.tipo || "filme",
  };
}

export default async function paginaDetalhe(raiz, { tipo, categoria, slug }) {
  document.body.classList.add("ficha-mode");
  const page = el("div", { class: "page page-ficha" });
  raiz.append(page);
  page.append(el("div", { class: "center detail-loading" }, [el("div", { class: "spinner" })]));

  let dados;
  let tedtop = null;
  try {
    const [contentResult, ted] = await Promise.all([
      getTitulo(categoria, slug, tipo)
        .then((d) => ({ ok: true, d }))
        .catch((e) => ({ ok: false, e })),
      getTedtopFilme(slug).catch(() => null),
    ]);
    tedtop = ted;
    if (contentResult.ok) {
      dados = contentResult.d;
    } else if (ted) {
      dados = {
        titulo: ted.titulo || slug,
        imagem: String(ted.imagem || "").startsWith("//")
          ? `https:${ted.imagem}`
          : ted.imagem || "",
        ano: ted.ano || "",
        duracao: ted.duracao || "",
        descricao: ted.sinopse || ted.descricao || "",
        generos: ted.genero ? [ted.genero] : [],
        tipo: tipo === "serie" ? "Série" : "Filme",
        categoria,
        slug,
        recomendados: (ted.recomendados || []).map((r) => ({
          ...r,
          imagem: String(r.imagem || "").startsWith("//") ? `https:${r.imagem}` : r.imagem,
          link_assistir: r.link_assistir || `#/titulo/filme/destaque/${r.slug || ""}`,
        })),
      };
    } else {
      throw contentResult.e || new Error("título indisponível");
    }
    if (ted) {
      if (!dados.imagem && ted.imagem) {
        dados.imagem = String(ted.imagem).startsWith("//") ? `https:${ted.imagem}` : ted.imagem;
      }
      if (!dados.descricao && (ted.sinopse || ted.descricao)) {
        dados.descricao = ted.sinopse || ted.descricao;
      }
    }
  } catch (e) {
    limpar(page);
    page.append(el("p", { class: "center" }, "Não foi possível carregar este título."));
    return page;
  }

  if (!dados.titulo && dados.serie) dados.titulo = dados.serie;
  if (!dados.slug) dados.slug = slug;
  if (!dados.categoria) dados.categoria = categoria;

  try {
    await enriquecerComTmdb(
      dados,
      tipo === "serie" || /sér|ser/i.test(String(dados.tipo || "")) ? "serie" : "filme",
    );
  } catch (_) {}

  const isSerie = tipo === "serie" || /sér|ser/i.test(String(dados.tipo || ""));
  const filmeId = String(dados.filmeId || dados.id || dados._id || dados.tmdb_id || slug);
  const thumb = String(
    dados.imagem || dados.thumb || dados.poster || dados.capa || dados.banner || "",
  );
  let favorito = lerFavorito(filmeId, slug, categoria);
  const pctFilme = lerProgresso({ categoria, slug, filmeId }).percent;

  const after = [];

  // Episódios (série)
  if (isSerie) {
    const epsSection = el("div", { class: "ficha-eps-host" });
    epsSection.append(el("div", { class: "center" }, [el("div", { class: "spinner" })]));
    after.push(epsSection);
    // carrega async
    (async () => {
      try {
        const temporadas = await getTemporadas(categoria, slug);
        const tmdbSerieId = extrairTmdbId(dados) || dados.tmdb_id || 0;
        const tempsData = [];
        for (const t of temporadas || []) {
          const num = t.numero || t.season_number || 1;
          let eps = [];
          try {
            eps = await getEpisodios(categoria, slug, num);
            await enriquecerEpisodiosComTmdb(eps, tmdbSerieId, num, thumb);
          } catch (_) {}
          tempsData.push({
            numero: num,
            episodios: (eps || []).map((ep, i) => ({
              ...ep,
              numero: ep.numero ?? i + 1,
              titulo: ep.titulo || ep.nome || "",
              imagem: ep.imagem || ep.thumb || thumb,
              duracao: ep.duracao || "",
              categoria: ep.categoria || categoria,
              slug: ep.slug || parseLink(ep.link || ep.link_assistir).slug,
              progresso: lerProgresso({
                categoria: ep.categoria || categoria,
                slug: ep.slug || parseLink(ep.link || ep.link_assistir).slug,
                filmeId: ep.filmeId || ep.id || ep.slug || "",
              }).percent,
            })),
          });
        }
        limpar(epsSection);
        if (!tempsData.length) {
          epsSection.append(el("p", { class: "sub", style: "padding:16px" }, "Episódios indisponíveis."));
          return;
        }
        epsSection.append(
          montarEpisodiosUI({
            temporadas: tempsData,
            serieCapa: thumb,
            onPlayEp: (ep, temp, num) => {
              const p = parseLink(ep.link || ep.link_assistir);
              const cat = ep.categoria || p.categoria || categoria;
              const sl = ep.slug || p.slug;
              if (!sl) return;
              const params = new URLSearchParams({
                filmeId: String(ep.filmeId || ep.id || sl),
                thumb: ep.imagem || thumb,
                tipo: "episodio",
                serieCategoria: categoria,
                serieSlug: slug,
              });
              location.hash = `#/assistir/${encodeURIComponent(cat)}/${encodeURIComponent(sl)}?${params}`;
            },
          }),
        );
      } catch (_) {
        limpar(epsSection);
        epsSection.append(el("p", { class: "sub", style: "padding:16px" }, "Episódios indisponíveis."));
      }
    })();
  }

  // Trailer
  const trailerUrl = (tedtop && tedtop.trailer) || dados.trailer || null;
  const trailerEl = blocoTrailer(trailerUrl);
  if (trailerEl) after.push(trailerEl);

  // Recomendados
  if ((dados.recomendados || []).length) {
    const rail = el("div", { class: "rail" });
    dados.recomendados.slice(0, 16).forEach((r) => rail.append(cardTitulo(r)));
    after.push(
      el("section", { class: "trailer-section" }, [
        el("h2", { class: "ficha-eps-title" }, "Recomendados"),
        rail,
      ]),
    );
  }

  const generos = (dados.generos || []).map((g) =>
    typeof g === "string" ? g : g?.nome || g?.name || "",
  );

  limpar(page);
  page.append(
    montarFicha({
      titulo: dados.titulo || "",
      poster: thumb,
      nota: dados.nota,
      ano: anoCurto(dados.ano) || dados.ano,
      tipoLabel: isSerie ? "Série" : "Filme",
      duracao: !isSerie ? dados.duracao : null,
      temps: isSerie
        ? dados.total_temporadas || dados.temporadas?.length || null
        : null,
      classificacao: dados.classificacao || dados.age || null,
      generos,
      sinopse: dados.descricao || dados.sinopse || dados.overview || "",
      progress: pctFilme,
      favorito,
      playLabel: isSerie
        ? "Assistir"
        : pctFilme > 0
          ? `Continuar · ${pctFilme}%`
          : "Assistir",
      onPlay: () => {
        if (isSerie) {
          const host = page.querySelector(".ficha-ep-main");
          if (host) host.click();
          else {
            const ep = page.querySelector(".ficha-eps");
            if (ep) ep.scrollIntoView({ behavior: "smooth" });
          }
          return;
        }
        const params = new URLSearchParams({
          filmeId,
          thumb,
          tipo: dados.tipo || tipo || "filme",
        });
        const recomendados = (dados.recomendados || []).map(dadosParaPlayer).filter(Boolean);
        if (recomendados.length) params.set("recomendados", JSON.stringify(recomendados));
        location.hash = `#/assistir/${encodeURIComponent(categoria)}/${encodeURIComponent(slug)}?${params}`;
      },
      onFavorite: () => {
        try {
          const contentType = isSerie ? "series" : "movie";
          const resposta = JSON.parse(
            window.AndroidPlayer?.toggleFavorite?.(
              filmeId,
              dados.titulo || "Tedflix",
              thumb,
              contentType,
            ) || "{}",
          );
          if (!resposta.success) throw new Error(resposta.error || "Erro");
          favorito =
            typeof resposta.favorito === "boolean" ? resposta.favorito : !favorito;
          return { favorito };
        } catch (_) {
          return { favorito };
        }
      },
      after,
    }),
  );

  return page;
}
