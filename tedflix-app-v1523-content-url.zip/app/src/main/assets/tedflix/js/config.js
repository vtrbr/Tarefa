/** Catálogo legado — fallback; pesquisa usa fontes abaixo. */
export const API_BASE = "https://v1-novelasflix-megaflix-v2.onrender.com";

/** AUTH — login, conta, favoritos, progresso (NÃO MUDAR) */
export const USER_API_BASE = "https://login-148v.onrender.com";

/** v2 Donflix — home, providers, calendar, video mp4 */
export const DONFLIX_API_BASE = "https://v2-donflix.onrender.com";

/** v3 Megafilmes — streaming tabs (não entra na busca principal) */
export const MEGAFILMES_API_BASE = "https://v3-megafilmes.onrender.com";

/** v4 Megacine */
export const MEGACINE_API_BASE = "https://v4-megacine.onrender.com";

/** v5 TMDB Ted (só meta; sem play; fora da busca principal) */
export const TEDV2_API_BASE = "https://v5-tmdb-tedv2.onrender.com";

/** v6 TedTop (conteúdo; NÃO é auth) */
export const TEDTOP_API_BASE = "https://servidores-ted-auth-h42l.onrender.com";

/** TMDB Helper legado (capas) */
export const TMDB_HELPER_BASE = "https://servidor-tmdb.onrender.com";

/** LIVE legado */
export const LIVE_API_BASE = "https://api.reidoscanais.si";

/** Pluto TV — seção própria (fora da busca principal) */
export const PLUTO_API_BASE = "https://v7-plutotv.onrender.com";

/** Plex Free Live TV */
export const PLEX_API_BASE = "https://v8-plextv.onrender.com";

/** RedeCanaisTV — canais ao vivo BR */
export const REDECANAIS_API_BASE = "https://v9-redecanaistv.onrender.com";

/** Streamberry — filmes/séries + BYSE */
export const STREAMBERRY_API_BASE = "https://v10-streamberry.onrender.com";

/** NovelasFlix / MegaFlix content (v1) */
export const CONTENT_API_BASE = "https://v1-novelasflix-megaflix-v2.onrender.com";

/** NoFlix desativado */
export const NOFLIX_ENABLED = false;
export const NOFLIX_API_BASE = "https://servidores-ted-apply3.onrender.com";

export const CATEGORIAS = [
  { slug: "acao", label: "Ação" },
  { slug: "animacao", label: "Animação" },
  { slug: "aventura", label: "Aventura" },
  { slug: "comedia", label: "Comédia" },
  { slug: "drama", label: "Drama" },
  { slug: "ficcao-cientifica", label: "Ficção Científica" },
  { slug: "romance", label: "Romance" },
  { slug: "suspense", label: "Suspense" },
  { slug: "terror", label: "Terror" },
];

export const NAV = [
  { href: "#/", label: "Início", icon: "home" },
  { href: "#/series", label: "Séries", icon: "tv" },
  { href: "#/filmes", label: "Filmes", icon: "film" },
  { href: "#/categorias", label: "Categorias", icon: "grid" },
  { href: "#/agenda", label: "Agenda", icon: "calendar" },
];
