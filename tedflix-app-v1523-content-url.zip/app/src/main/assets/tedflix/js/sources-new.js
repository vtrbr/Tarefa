/**
 * Clientes v2 Donflix + v3 Megafilmes (contratos /v2/*)
 */
import { DONFLIX_API_BASE, MEGAFILMES_API_BASE, TMDB_HELPER_BASE } from "./config.js";

const TTL_MS = 45 * 60 * 1000;
const mem = new Map();

async function getJSON(base, path, ttl = TTL_MS) {
  const url = base.replace(/\/$/, "") + path;
  const key = url;
  const hit = mem.get(key);
  if (hit && Date.now() - hit.t < ttl) return hit.d;
  const ctrl = new AbortController();
  const to = setTimeout(() => ctrl.abort(), 28000);
  try {
    const r = await fetch(url, { signal: ctrl.signal, headers: { Accept: "application/json" } });
    if (!r.ok) throw new Error("HTTP " + r.status);
    const d = await r.json();
    mem.set(key, { t: Date.now(), d });
    return d;
  } finally {
    clearTimeout(to);
  }
}

function slugFromUrl(url) {
  if (!url) return null;
  const m = String(url).match(/\/(filme|serie|series)\/([^/?#]+)/i);
  return m ? m[2] : null;
}

function card(it, api, tipoForcado) {
  if (!it) return null;
  const tipo =
    tipoForcado ||
    (String(it.tipo || "").toLowerCase().includes("ser") ? "serie" : "filme");
  const titulo = it.nome || it.titulo || it.title || "";
  let capa =
    it.url_imagem ||
    it.capa ||
    it.poster ||
    it.imagem ||
    (it.imagens && (it.imagens.poster || it.imagens.capa)) ||
    null;
  const tmdb = it.tmdb_id || it.tmdb || it.idtmdb || null;
  if (!capa && tmdb) {
    capa = `https://image.tmdb.org/t/p/w500/${String(tmdb)}`; // placeholder — real path needs poster path
  }
  let slug = it.slug || slugFromUrl(it.url_pagina) || (tmdb ? String(tmdb) : null);
  const notaRaw = it.nota_tmdb ?? it.nota ?? it.rating;
  const nota = notaRaw != null && Number(notaRaw) > 0 ? Number(notaRaw) : null;
  const fonte = api === "v2" ? "donflix" : api === "v3" ? "megafilmes" : api;
  const isSerie = tipo === "serie";
  let link_detalhe = "#/";
  if (api === "v2" || fonte === "donflix") {
    // SEMPRE tmdb numérico quando existir (player unificado)
    const id = (tmdb && String(tmdb)) || slug;
    if (id) link_detalhe = isSerie
      ? `#/donflix/serie/${encodeURIComponent(id)}`
      : `#/donflix/filme/${encodeURIComponent(id)}`;
  } else if (api === "v3" || fonte === "megafilmes") {
    // TMDB → Donflix (server de players unificado)
    if (tmdb && String(tmdb).match(/^\d+$/)) {
      link_detalhe = isSerie
        ? `#/donflix/serie/${encodeURIComponent(tmdb)}`
        : `#/donflix/filme/${encodeURIComponent(tmdb)}`;
      // play vai pro Donflix API
    } else if (slug) {
      link_detalhe = isSerie
        ? `#/megafilmes/serie/${encodeURIComponent(slug)}`
        : `#/megafilmes/filme/${encodeURIComponent(slug)}`;
    }
  }
  // Se o link final é Donflix, fonte de play = donflix
  let fontePlay = fonte;
  let apiPlay = api;
  if (/^#\/donflix\//i.test(link_detalhe)) {
    fontePlay = "donflix";
    apiPlay = "v2";
  }
  return {
    titulo,
    nome: titulo,
    capa,
    imagem: capa,
    banner: it.banner || it.backdrop || (it.imagens && it.imagens.backdrop) || null,
    ano: it.ano || it.year || null,
    nota,
    tipo,
    slug: (tmdb && String(tmdb).match(/^\d+$/) ? String(tmdb) : slug),
    tmdb_id: tmdb,
    idtmdb: tmdb,
    api: apiPlay,
    fonte: fontePlay,
    pode_assistir: true,
    url_pagina: it.url_pagina || null,
    link_detalhe,
    overview: it.overview || it.sinopse || null,
  };
}

/** Enriquece capas nulas via TMDB helper (título) */
export async function enriquecerCapas(itens) {
  const list = Array.isArray(itens) ? itens : [];
  await Promise.all(
    list.slice(0, 24).map(async (it) => {
      if (!it || (it.imagem && it.imagem.length > 8) || (it.capa && String(it.capa).includes("image.tmdb"))) {
        if (it.capa && !it.imagem) it.imagem = it.capa;
        return;
      }
      // se capa for só número tmdb inválido, limpa
      if (it.capa && /\/\d+$/.test(String(it.capa))) it.capa = it.imagem = null;
      try {
        const q = encodeURIComponent(it.titulo || it.nome || "");
        if (!q) return;
        const r = await fetch(`${TMDB_HELPER_BASE}/tmdb/lookup?titulo=${q}`, {
          headers: { Accept: "application/json" },
        });
        if (!r.ok) return;
        const d = await r.json();
        const poster = d.capa || d.poster || d.poster_path || d.imagem;
        if (poster) {
          const url = String(poster).startsWith("http")
            ? poster
            : `https://image.tmdb.org/t/p/w500${poster}`;
          it.capa = it.imagem = url;
          if (d.tmdb_id || d.id) {
            it.tmdb_id = it.idtmdb = d.tmdb_id || d.id;
          }
        }
      } catch (_) {}
    }),
  );
  return list;
}

/* ---------- Donflix ---------- */
export async function donflixBanner() {
  const d = await getJSON(DONFLIX_API_BASE, "/v2/banner");
  return (d.itens || []).map((i) => card(i, "v2")).filter(Boolean);
}

export async function donflixHome() {
  return getJSON(DONFLIX_API_BASE, "/v2/home");
}

export async function donflixTop10(tipo = "filmes") {
  const d = await getJSON(DONFLIX_API_BASE, `/v2/top10/${tipo}`);
  return (d.itens || d.filmes || d.series || []).map((i) =>
    card(i, "v2", tipo.startsWith("ser") ? "serie" : "filme"),
  );
}

export async function donflixList(tipo = "filmes", page = 1) {
  const path = page > 1 ? `/v2/${tipo}/${page}` : `/v2/${tipo}`;
  const d = await getJSON(DONFLIX_API_BASE, path);
  const itens = (d.itens || []).map((i) =>
    card(i, "v2", tipo.startsWith("ser") ? "serie" : "filme"),
  );
  await enriquecerCapas(itens);
  return { itens, meta: d.meta || {} };
}

export async function donflixProviders() {
  const d = await getJSON(DONFLIX_API_BASE, "/v2/providers");
  return (d.providers || []).map((p) => ({
    slug: p.slug || String(p.provider_name || "").toLowerCase().replace(/\s+/g, "-"),
    nome: p.nome || p.provider_name || p.slug,
    logo: p.logo || p.logo_path || null,
    id: p.id,
    api: "v2",
  }));
}

export async function donflixByProvider(slug, tipo = "filmes", page = 1) {
  const base = `/v2/${slug}/${tipo}`;
  const path = page > 1 ? `${base}/${page}` : base;
  const d = await getJSON(DONFLIX_API_BASE, path);
  const itens = (d.itens || []).map((i) =>
    card(i, "v2", tipo.startsWith("ser") ? "serie" : "filme"),
  );
  await enriquecerCapas(itens);
  return { itens, meta: d.meta || {} };
}

export async function donflixSearch(q) {
  const d = await getJSON(DONFLIX_API_BASE, `/v2/search/${encodeURIComponent(q)}`, 15 * 60 * 1000);
  const itens = (d.itens || []).map((i) => card(i, "v2")).filter(Boolean);
  await enriquecerCapas(itens);
  return itens;
}

export async function donflixCalendar(dias = 14, pagina = 1) {
  const path = pagina > 1 ? `/v2/calendar/${dias}/${pagina}` : `/v2/calendar/${dias}`;
  const d = await getJSON(DONFLIX_API_BASE, path, 30 * 60 * 1000);
  return {
    meta: d.meta || {},
    itens: (d.itens || []).map((i) => {
      const c = card(i, "v2", "serie");
      return {
        ...c,
        data: i.data || i.air_date || d.meta?.de || null,
        horario: i.horario || i.hora || "",
        episodio: i.episodio || i.ep || (i.season && i.episode ? `T${i.season} E${i.episode}` : ""),
      };
    }),
  };
}

export async function donflixDetalheFilme(slugOrId) {
  return getJSON(DONFLIX_API_BASE, `/v2/filme/${encodeURIComponent(slugOrId)}`);
}

export async function donflixDetalheSerie(slugOrId) {
  return getJSON(DONFLIX_API_BASE, `/v2/serie/${encodeURIComponent(slugOrId)}`);
}

export async function donflixVideoFilme(tmdbId) {
  return getJSON(DONFLIX_API_BASE, `/v2/video/filme/${encodeURIComponent(tmdbId)}`, 5 * 60 * 1000);
}

export async function donflixVideoSerie(tmdbId, s, e) {
  return getJSON(
    DONFLIX_API_BASE,
    `/v2/video/serie/${encodeURIComponent(tmdbId)}/${encodeURIComponent(s)}/${encodeURIComponent(e)}`,
    5 * 60 * 1000,
  );
}

/* ---------- Megafilmes ---------- */
export async function megafilmesList(tipo = "filmes", page = 1) {
  const path = page > 1 ? `/v2/${tipo}/${page}` : `/v2/${tipo}`;
  const d = await getJSON(MEGAFILMES_API_BASE, path);
  const itens = (d.itens || []).map((i) =>
    card(
      i,
      "v3",
      tipo.startsWith("ser") || tipo === "doramas" || tipo === "novelas" ? "serie" : "filme",
    ),
  );
  await enriquecerCapas(itens);
  return { itens, meta: d.meta || {} };
}

export async function megafilmesStreaming(platform, tab = "filmes", page = 1, sort = "recent") {
  let path = `/v2/${platform}/${tab}`;
  if (sort === "top") path += "/top";
  else if (sort === "az") path += "/az";
  if (page > 1) path += `/${page}`;
  const d = await getJSON(MEGAFILMES_API_BASE, path);
  const itens = (d.itens || []).map((i) =>
    card(i, "v3", tab === "series" || tab === "doramas" || tab === "novelas" ? "serie" : "filme"),
  );
  await enriquecerCapas(itens);
  return { itens, meta: d.meta || {} };
}

export async function megafilmesDetalhe(tipo, slug) {
  const t = tipo.startsWith("ser") ? "serie" : tipo === "dorama" ? "dorama" : tipo === "novela" ? "novela" : "filme";
  return getJSON(MEGAFILMES_API_BASE, `/v2/${t}/${encodeURIComponent(slug)}`);
}

export async function megafilmesVideoFilme(id) {
  return getJSON(MEGAFILMES_API_BASE, `/v2/video/filme/${encodeURIComponent(id)}`, 5 * 60 * 1000);
}

export async function megafilmesVideoSerie(id, s, e) {
  return getJSON(
    MEGAFILMES_API_BASE,
    `/v2/video/serie/${encodeURIComponent(id)}/${encodeURIComponent(s)}/${encodeURIComponent(e)}`,
    5 * 60 * 1000,
  );
}

export const MEGAFILMES_STREAMINGS = [
  "netflix",
  "prime-video",
  "disney-plus",
  "apple-tv-plus",
  "max",
  "paramount-plus",
  "globoplay",
  "crunchyroll",
];
