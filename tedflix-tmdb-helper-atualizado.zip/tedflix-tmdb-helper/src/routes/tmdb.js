const express = require('express');
const { lookup, byId, episodiosTemporada } = require('../services/tmdb');

const router = express.Router();

/**
 * GET /tmdb/lookup?titulo=...&ano=2026&tipo=serie|filme
 */
router.get('/lookup', async (req, res) => {
  try {
    const titulo = req.query.titulo || req.query.q || req.query.title || '';
    const ano = req.query.ano || req.query.year || '';
    const tipo = req.query.tipo || req.query.type || 'filme';
    const result = await lookup({ titulo, ano, tipo });
    res.json(result);
  } catch (err) {
    const status = err.status || 500;
    res.status(status).json({
      ok: false,
      error: err.message || 'erro no lookup TMDB',
    });
  }
});

/**
 * GET /tmdb/id/:id?tipo=serie|filme
 */
router.get('/id/:id', async (req, res) => {
  try {
    const result = await byId({
      id: req.params.id,
      tipo: req.query.tipo || req.query.type || 'filme',
    });
    res.json(result);
  } catch (err) {
    const status = err.status || 500;
    res.status(status).json({
      ok: false,
      error: err.message || 'erro no detalhe TMDB',
    });
  }
});

/**
 * GET /tmdb/serie/:id/temporada/:temporada
 * Retorna metadados dos episódios de uma temporada, sem dados de reprodução.
 */
router.get('/serie/:id/temporada/:temporada', async (req, res) => {
  try {
    const result = await episodiosTemporada({
      id: req.params.id,
      temporada: req.params.temporada,
    });
    return res.json(result);
  } catch (err) {
    const status = err.status || (err.response?.status === 404 ? 404 : 502);
    return res.status(status).json({
      ok: false,
      error: err.status
        ? err.message
        : status === 404
          ? 'Série ou temporada não encontrada no TMDB'
          : 'Erro ao consultar o TMDB',
    });
  }
});

module.exports = router;
