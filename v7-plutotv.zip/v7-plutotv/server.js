/**
 * Pluto TV API — categorias, canais ao vivo (HLS), VOD
 * Compatível com o padrão dos outros servers TEDFLIX (zero npm deps)
 */
const http = require('http');
const { URL } = require('url');
const catalog = require('./lib/catalog');
const { proxyFetch } = require('./lib/proxy');

const PORT = process.env.PORT || 3017;

const cache = new Map();
const CACHE_TTL = 3 * 60 * 1000; // 3 min (grades mudam)

function getCached(key) {
  const hit = cache.get(key);
  if (!hit) return null;
  if (Date.now() - hit.at > CACHE_TTL) {
    cache.delete(key);
    return null;
  }
  return hit.data;
}
function setCached(key, data) {
  cache.set(key, { at: Date.now(), data });
  return data;
}

function send(res, status, body) {
  const json = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Cache-Control': 'public, max-age=60',
  });
  res.end(json);
}

async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    });
    return res.end();
  }

  const u = new URL(req.url, 'http://localhost');
  const path = u.pathname.replace(/\/+$/, '') || '/';

  try {
    if (path === '/' || path === '/health') {
      return send(res, 200, {
        ok: true,
        nome: 'plutotv-api',
        versao: '1.1.0',
        origem: 'https://pluto.tv/br/',
        fix: 'v2+jwt+masterJWTPassthrough+XFF-BR',
        endpoints: {
          home: 'GET /v1/home',
          categories: 'GET /v1/categories',
          category: 'GET /v1/categories/:slug',
          channels: 'GET /v1/channels',
          stream: 'GET /v1/channels/:id/stream  |  /v1/live/:id',
          vod: 'GET /v1/vod',
          vod_stream: 'GET /v1/vod/:slug/stream',
          search: 'GET /v1/search?q=',
          proxy: 'GET /v1/proxy?url=',
        },
      });
    }

    if (path === '/v1/home') {
      const c = getCached('home');
      if (c) return send(res, 200, c);
      const data = await catalog.home();
      return send(res, 200, setCached('home', data));
    }

    if (path === '/v1/categories') {
      const c = getCached('cats');
      if (c) return send(res, 200, c);
      const data = await catalog.categoriesOnly();
      return send(res, 200, setCached('cats', data));
    }

    let m = path.match(/^\/v1\/categories\/([^/]+)$/);
    if (m) {
      const key = 'cat:' + m[1];
      const c = getCached(key);
      if (c) return send(res, 200, c);
      const data = await catalog.categoryBySlug(decodeURIComponent(m[1]));
      if (!data.ok) return send(res, 404, data);
      return send(res, 200, setCached(key, data));
    }

    if (path === '/v1/channels') {
      const c = getCached('channels');
      if (c) return send(res, 200, c);
      const data = await catalog.allChannels();
      return send(res, 200, setCached('channels', data));
    }

    m = path.match(/^\/v1\/channels\/([^/]+)\/stream$/);
    if (m) {
      const data = await catalog.channelStream(decodeURIComponent(m[1]));
      return send(res, data.ok ? 200 : 404, data);
    }

    m = path.match(/^\/v1\/live\/([^/]+)$/);
    if (m) {
      const data = await catalog.channelStream(decodeURIComponent(m[1]));
      return send(res, data.ok ? 200 : 404, data);
    }

    if (path === '/v1/vod') {
      const c = getCached('vod');
      if (c) return send(res, 200, c);
      const data = await catalog.vodHome();
      return send(res, 200, setCached('vod', data));
    }

    m = path.match(/^\/v1\/vod\/([^/]+)\/stream$/);
    if (m) {
      const data = await catalog.vodStream(decodeURIComponent(m[1]));
      return send(res, data.ok ? 200 : 404, data);
    }

    if (path === '/v1/search') {
      const q = u.searchParams.get('q') || '';
      const data = await catalog.search(q);
      return send(res, 200, data);
    }

    // Proxy HLS (mesmo IP da sessão)
    if (path === '/v1/proxy') {
      const target = u.searchParams.get('url') || '';
      if (!target || !/^https?:\/\//i.test(target)) {
        return send(res, 400, { ok: false, erro: 'url inválida' });
      }
      // só hosts Pluto / stitcher / CDN conhecidos
      let host = '';
      try { host = new URL(target).hostname; } catch {
        return send(res, 400, { ok: false, erro: 'url inválida' });
      }
      const allow =
        /pluto\.tv$/i.test(host) ||
        /\.pluto\.tv$/i.test(host) ||
        /plutotv\.net$/i.test(host) ||
        /\.plutotv\.net$/i.test(host) ||
        /stitcher/i.test(host) ||
        host.includes('pluto');
      if (!allow) {
        return send(res, 403, { ok: false, erro: 'host não permitido' });
      }
      const proto = (req.headers['x-forwarded-proto'] || 'https').toString().split(',')[0].trim();
      const hostHdr = (req.headers['x-forwarded-host'] || req.headers.host || '').toString();
      const publicBase =
        process.env.PUBLIC_BASE ||
        process.env.RENDER_EXTERNAL_URL ||
        (hostHdr ? proto + '://' + hostHdr : '');
      const result = await proxyFetch(target, { publicBase });
      res.writeHead(result.status || 200, {
        'Content-Type': result.contentType || 'application/octet-stream',
        'Access-Control-Allow-Origin': '*',
        'Cache-Control': result.isPlaylist ? 'no-cache' : 'public, max-age=30',
      });
      return res.end(result.body);
    }

    return send(res, 404, { ok: false, erro: 'rota não encontrada', path });
  } catch (e) {
    console.error(e);
    return send(res, 500, { ok: false, erro: e.message || String(e) });
  }
}

const server = http.createServer((req, res) => {
  handler(req, res);
});

server.listen(PORT, () => {
  console.log('plutotv-api on :' + PORT);
});
