# Pluto TV API (v7) — BR

API leve (zero deps) para catálogo + streams HLS da Pluto TV Brasil.

## Fix 1.1.0 (slate "device no longer available")

- Boot em `boot.pluto.tv/v4/start` com **X-Forwarded-For BR**
- Stream montado como:
  `{stitcher}/v2/stitch/hls/channel/{id}/master.m3u8?{stitcherParams}&jwt=...&masterJWTPassthrough=true&includeExtendedEvents=true`
- Proxy reescreve master → variants → segmentos mantendo o mesmo XFF

## Endpoints

- `GET /` health
- `GET /v1/home` categorias + canais
- `GET /v1/categories`
- `GET /v1/channels`
- `GET /v1/channels/:id/stream` ou `/v1/live/:id`
- `GET /v1/vod`
- `GET /v1/vod/:slug/stream`
- `GET /v1/search?q=`
- `GET /v1/proxy?url=` (HLS rewrite)

## Deploy (Render)

```bash
# root do serviço = pasta v7-plutotv
npm start
# ou
node server.js
```

Env opcional:
- `PUBLIC_BASE=https://v7-plutotv.onrender.com`
- `PORT=10000`

## Teste local

```bash
node -e 'require("./lib/session").boot().then(s=>console.log(s.session.marketingRegion, s.servers.stitcher))'
```
