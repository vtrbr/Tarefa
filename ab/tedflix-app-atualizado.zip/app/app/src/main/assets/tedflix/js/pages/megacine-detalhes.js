import { el, limpar } from "../dom.js";
import {
  getMegacineDossier,
} from "../api.js";
import { poster, backdrop } from "../img.js";
import { lerFavorito, toggleFavorito, abrirPlayerNativo, lerProgresso } from "../playback.js";

function playMegacineNativo({ tipo, slug, titulo, thumb, filmeId, episodeId, temp, ep }) {
  // slug nativo:
  //  filme-{slug}
  //  ep-{episodeId}
  //  serie-{slug}-{t}-{e}
  let nativeSlug = `${tipo}-${slug}`;
  if (episodeId) nativeSlug = `ep-${episodeId}`;
  else if (tipo === "serie" && temp != null && ep != null) {
    nativeSlug = `serie-${slug}-${temp}-${ep}`;
  }
  return abrirPlayerNativo({
    categoria: "megacine",
    slug: nativeSlug,
    titulo: titulo || slug,
    filmeId: filmeId || `cine-${tipo}-${slug}`,
    thumb: thumb || "",
    tipo: episodeId || (temp && ep) ? "episodio" : tipo,
    serieSlug: tipo === "serie" ? slug : "",
    serieCategoria: "megacine",
  });
}

export default async function paginaMegacineDetalhe(raiz, { tipo = "filme", slug = "" } = {}) {
  const page = el("div", { class: "page page-detail" });
  raiz.append(page);
  page.append(el("div", { class: "center" }, [el("div", { class: "spinner" })]));

  const t = String(tipo || "filme").toLowerCase().includes("serie") ? "serie" : "filme";
  const s = decodeURIComponent(String(slug || "").trim());
  if (!s) {
    limpar(page);
    page.append(el("p", { class: "center" }, "Título inválido."));
    return page;
  }

  let dados;
  try {
    dados = await getMegacineDossier(t, s);
  } catch (e) {
    limpar(page);
    page.append(el("p", { class: "center" }, "Não foi possível carregar este título."));
    return page;
  }
  if (!dados) {
    limpar(page);
    page.append(el("p", { class: "center" }, "Título não encontrado."));
    return page;
  }

  limpar(page);

  const capa = dados.capa || dados.imagem || "";
  const filmeId = `cine-${t}-${s}`;
  let favorito = lerFavorito(filmeId, s, "megacine");

  const btnFav = el("button", {
    type: "button",
    class: `btn ghost${favorito ? " on" : ""}`,
  }, favorito ? "♥ Na lista" : "♡ Favorito");

  btnFav.addEventListener("click", () => {
    const r = toggleFavorito(
      filmeId,
      dados.titulo || "Tedflix",
      capa,
      t === "serie" ? "series" : "movie",
    );
    if (r && r.success !== false) {
      favorito = typeof r.favorito === "boolean" ? r.favorito : !favorito;
      btnFav.textContent = favorito ? "♥ Na lista" : "♡ Favorito";
      btnFav.classList.toggle("on", favorito);
    }
  });

  const prog = lerProgresso({ categoria: "megacine", slug: s, filmeId });

  function assistirFilme() {
    // Uma só chamada: o PlayerActivity busca /projeto no Kotlin (evita 2× round-trip)
    const ok = playMegacineNativo({
      tipo: "filme",
      slug: s,
      titulo: dados.titulo || s,
      thumb: capa,
      filmeId,
    });
    if (!ok) alert("Player indisponível.");
  }

  async function assistirEp(ep, tempNum) {
    const episodeId = ep.episode_id || ep.id || "";
    const num = ep.numero || ep.episode || 1;
    const tituloEp = ep.titulo || `${dados.titulo} · T${tempNum}E${num}`;
    try {
      // tenta nativo direto (Player resolve)
      const ok = playMegacineNativo({
        tipo: "serie",
        slug: s,
        titulo: tituloEp,
        thumb: capa,
        filmeId: episodeId ? `cine-ep-${episodeId}` : filmeId,
        episodeId,
        temp: tempNum,
        ep: num,
      });
      if (!ok) alert("Player indisponível.");
    } catch (_) {
      alert("Falha ao abrir o episódio.");
    }
  }

  const btnPlay = el("button", {
    type: "button",
    class: "btn primary",
    html:
      '<svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M8 5v14l11-7z"/></svg> ' +
      (t === "filme"
        ? prog.percent > 0
          ? `Continuar · ${prog.percent}%`
          : "Assistir"
        : "Episódios abaixo"),
  });
  if (t === "filme") {
    btnPlay.addEventListener("click", assistirFilme);
  } else {
    btnPlay.addEventListener("click", () => {
      const lista = page.querySelector(".cine-eps");
      if (lista) lista.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }

  const gens = Array.isArray(dados.generos)
    ? dados.generos.map((g) => (typeof g === "string" ? g : g.nome || g.slug)).filter(Boolean)
    : [];
  const meta = [
    dados.nota != null ? `★ ${Number(dados.nota).toFixed(1)}` : null,
    t === "serie" ? "Série" : "Filme",
    dados.ano || null,
    dados.total_temporadas ? `${dados.total_temporadas} temp.` : null,
    gens.slice(0, 3).join(" · ") || null,
  ].filter(Boolean);

  const hero = el("div", { class: "detail-hero" }, [
    capa
      ? el("img", {
          src: backdrop(capa, 780) || poster(capa, "lg") || capa,
          alt: dados.titulo || "",
          decoding: "async",
        })
      : null,
    el("div", { class: "veil" }),
  ]);

  page.append(
    hero,
    el("div", { class: "pad detail-body" }, [
      el("h1", { class: "detail-title" }, dados.titulo || s),
      el("p", { class: "sub" }, meta.join(" · ")),
      el("div", { class: "detail-actions", style: "display:flex;gap:10px;flex-wrap:wrap;margin:14px 0" }, [
        btnPlay,
        btnFav,
      ]),
      dados.sinopse || dados.descricao
        ? el("p", { class: "detail-sinopse" }, dados.sinopse || dados.descricao)
        : null,
    ]),
  );

  // Temporadas / episódios
  if (t === "serie") {
    const temporadas = Array.isArray(dados.temporadas) ? dados.temporadas : [];
    const wrap = el("div", { class: "pad cine-eps", style: "padding-top:8px" });
    if (!temporadas.length) {
      wrap.append(
        el("p", { class: "sub" }, "Episódios ainda não disponíveis para esta série."),
      );
    } else {
      wrap.append(el("h2", { style: "margin:8px 0 12px;font-size:18px" }, "Episódios"));

      const tabs = el("div", {
        class: "chips",
        style: "padding:0 0 12px;margin:0",
      });
      const lista = el("div", { class: "cine-ep-list" });
      let atual = 0;

      function renderTemp(idx) {
        atual = idx;
        [...tabs.children].forEach((c, i) => c.classList.toggle("on", i === idx));
        limpar(lista);
        const temp = temporadas[idx] || {};
        const numT = temp.numero || idx + 1;
        const eps = Array.isArray(temp.episodios) ? temp.episodios : [];
        if (!eps.length) {
          lista.append(el("p", { class: "sub" }, "Nenhum episódio nesta temporada."));
          return;
        }
        eps.forEach((ep) => {
          const num = ep.numero != null ? ep.numero : (ep.episode != null ? ep.episode : "?");
          const titulo = ep.titulo || `Episódio ${num}`;
          const row = el("button", {
            type: "button",
            class: "cine-ep-row",
            style:
              "display:flex;width:100%;align-items:center;gap:12px;padding:12px 4px;background:transparent;border:none;border-bottom:1px solid rgba(255,255,255,.08);color:inherit;text-align:left;cursor:pointer",
          }, [
            el("span", {
              style:
                "flex:0 0 40px;font-weight:800;opacity:.7;font-size:14px",
            }, `E${num}`),
            el("span", { style: "flex:1;min-width:0;font-weight:600;font-size:14px" }, titulo),
            el("span", {
              style:
                "flex:0 0 auto;width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.12);display:grid;place-items:center",
              html: '<svg viewBox="0 0 24 24" width="14" height="14"><path fill="currentColor" d="M8 5v14l11-7z"/></svg>',
            }),
          ]);
          row.addEventListener("click", () => assistirEp(ep, numT));
          lista.append(row);
        });
      }

      temporadas.forEach((temp, idx) => {
        const num = temp.numero || idx + 1;
        const chip = el("button", {
          type: "button",
          class: `chip${idx === 0 ? " on" : ""}`,
          style: "cursor:pointer;border:none",
        }, `T${num}`);
        chip.addEventListener("click", () => renderTemp(idx));
        tabs.append(chip);
      });

      wrap.append(tabs, lista);
      renderTemp(0);
    }
    page.append(wrap);
  }

  return page;
}
