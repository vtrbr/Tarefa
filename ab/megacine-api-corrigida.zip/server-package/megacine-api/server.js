const http = require('http');
const { URL } = require('url');
const cache = require('./lib/cache');
const scraper = require('./lib/scraper');
const { getStream } = require('./lib/stream');
const { handleProxy, toProxyUrl } = require('./lib/proxy');
const {
  createRequestId,
  runWithRequestContext,
  currentRequestId,
  elapsedMs,
  safePath,
  log
} = require('./lib/logger');

const PORT = process.env.PORT || 7400;

const TTL = {
  painel: 20 * 60 * 1000,
  cronograma: 10 * 60 * 1000,
  lista: 45 * 60 * 1000,
  estilo: 6 * 60 * 60 * 1000,
  lupa: 5 * 60 * 1000,
  dossier: 30 * 60 * 1000,
  projeto: 8 * 60 * 1000
};

function publicBase(req) {
  if (process.env.PUBLIC_BASE_URL) {
    return process.env.PUBLIC_BASE_URL.replace(/\/$/, '');
  }
  const host = req.headers['x-forwarded-host'] || req.headers.host || 'localhost';
  const proto =
    req.headers['x-forwarded-proto'] ||
    (String(host).includes('localhost') ? 'http' : 'https');
  return proto + '://' + host;
}

/** /projeto devolve stream já via /proxy (CDN só fala com o server) */
function wrapProjeto(data, req) {
  if (!data || !data.ok || !data.stream) return data;
  const base = publicBase(req);
  const proxied = toProxyUrl(data.stream, base);
  return {
    ...data,
    stream_direct: data.stream,
    stream: proxied,
    stream_type: 'hls',
    proxy: true
  };
}

function send(res, status, body) {
  const json = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Expose-Headers': 'X-Request-Id',
    ...(currentRequestId() ? { 'X-Request-Id': currentRequestId() } : {}),
    'Cache-Control': 'no-store'
  });
  res.end(json);
}

async function router(req, res) {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Expose-Headers': 'X-Request-Id',
      ...(currentRequestId() ? { 'X-Request-Id': currentRequestId() } : {})
    });
    return res.end();
  }

  const u = new URL(req.url, 'http://localhost');
  const path = u.pathname.replace(/\/+$/, '') || '/';
  const q = Object.fromEntries(u.searchParams.entries());

  // Proxy HLS (m3u8 + segmentos) — não passa por send() JSON
  if (path === '/proxy') {
    return handleProxy(req, res, publicBase(req));
  }

  try {
    if (path === '/') {
      return send(res, 200, {
        nome: 'MegaCine API',
        versao: '1.1.0',
        status: 'online',
        origem: scraper.BASE,
        deps: 'node-puro (sem npm)',
        endpoints: {
          painel: 'GET /painel',
          cronograma: 'GET /cronograma',
          pelicula: 'GET /pelicula?pagina=1',
          serial: 'GET /serial?pagina=1',
          estilo: 'GET /estilo | GET /estilo/:slug',
          lupa: 'GET /lupa/:termo',
          dossier: 'GET /dossier/filme/:slug | /dossier/serie/:slug',
          projeto:
            'GET /projeto/filme/:slug | /projeto/episodio/:episode_id | /projeto/serie/:slug/:temporada/:episodio',
          proxy: 'GET /proxy?url=  (HLS m3u8 + segmentos)'
        }
      });
    }

    if (path === '/painel') {
      const data = await cache.wrap('painel', TTL.painel, scraper.fetchHome);
      return send(res, 200, { ok: true, ...data });
    }

    if (path === '/cronograma') {
      const data = await cache.wrap(
        'cronograma',
        TTL.cronograma,
        scraper.fetchCronograma
      );
      return send(res, 200, { ok: true, ...data });
    }

    if (path === '/pelicula' || path === '/pelicula/recentes') {
      const pagina = Math.max(1, parseInt(q.pagina || '1', 10) || 1);
      const data = await cache.wrap('pelicula:' + pagina, TTL.lista, () =>
        scraper.fetchList('/filmes/', pagina)
      );
      return send(res, 200, { ok: true, tipo: 'filme', ...data });
    }

    if (path === '/serial' || path === '/serial/recentes') {
      const pagina = Math.max(1, parseInt(q.pagina || '1', 10) || 1);
      const data = await cache.wrap('serial:' + pagina, TTL.lista, () =>
        scraper.fetchList('/series/', pagina)
      );
      return send(res, 200, { ok: true, tipo: 'serie', ...data });
    }

    if (path === '/estilo') {
      return send(res, 200, {
        ok: true,
        generos: scraper.GENEROS.map((g) => ({
          ...g,
          endpoint: '/estilo/' + g.slug
        }))
      });
    }

    if (path.startsWith('/estilo/')) {
      const slug = path.slice('/estilo/'.length);
      const pagina = Math.max(1, parseInt(q.pagina || '1', 10) || 1);
      const data = await cache.wrap(
        'estilo:' + slug + ':' + pagina,
        TTL.estilo,
        () => scraper.fetchGenero(slug, pagina)
      );
      return send(res, 200, { ok: true, ...data });
    }

    if (path.startsWith('/lupa/')) {
      const termo = decodeURIComponent(path.slice('/lupa/'.length)).trim();
      if (!termo) return send(res, 400, { ok: false, erro: 'termo vazio' });
      const data = await cache.wrap(
        'lupa:' + termo.toLowerCase(),
        TTL.lupa,
        () => scraper.fetchBusca(termo)
      );
      return send(res, 200, { ok: true, ...data });
    }

    if (path.startsWith('/dossier/filme/')) {
      const slug = path.slice('/dossier/filme/'.length).replace(/-online$/i, '');
      const data = await cache.wrap('dossier:filme:' + slug, TTL.dossier, () =>
        scraper.fetchDossier('filme', slug)
      );
      return send(res, 200, data);
    }

    if (path.startsWith('/dossier/serie/')) {
      const slug = path.slice('/dossier/serie/'.length).replace(/-online$/i, '');
      const data = await cache.wrap('dossier:serie:' + slug, TTL.dossier, () =>
        scraper.fetchDossier('serie', slug)
      );
      return send(res, 200, data);
    }

    if (path.startsWith('/projeto/filme/')) {
      const slug = path.slice('/projeto/filme/'.length).replace(/-online$/i, '');
      // não cachear resposta com stream (token expira + IP)
      const data = await getStream({ tipo: 'filme', slug });
      return send(res, data.ok ? 200 : 404, wrapProjeto(data, req));
    }

    // /projeto/episodio/:episode_id  → play direto do episódio
    if (path.startsWith('/projeto/episodio/')) {
      const episode_id = path.slice('/projeto/episodio/'.length).split('/')[0];
      const data = await getStream({ episode_id });
      return send(res, data.ok ? 200 : 404, wrapProjeto(data, req));
    }

    // /projeto/serie/:slug/:temporada/:episodio
    // /projeto/serie/:slug  → 404 orientativo com exemplo
    if (path.startsWith('/projeto/serie/')) {
      const rest = path.slice('/projeto/serie/'.length);
      const parts = rest.split('/').filter(Boolean);
      const slug = (parts[0] || '').replace(/-online$/i, '');
      const temporada = parts[1];
      const episodio = parts[2];
      const data = await getStream({
        tipo: 'serie',
        slug,
        temporada,
        episodio
      });
      return send(res, data.ok ? 200 : 404, wrapProjeto(data, req));
    }

    if (path === '/projeto') {
      const data = await getStream({
        tipo: q.tipo || 'filme',
        slug: q.slug,
        viewplayer: q.viewplayer || q.vp,
        episode_id: q.episode_id || q.episodio_id,
        temporada: q.temporada || q.t,
        episodio: q.episodio || q.e
      });
      return send(res, data.ok ? 200 : 404, wrapProjeto(data, req));
    }

    return send(res, 404, { ok: false, erro: 'Rota não encontrada', path });
  } catch (e) {
    log('http.request.failed', {
      path: safePath(req.url || '/'),
      error_name: e.name || 'Error'
    }, 'error');
    return send(res, 502, { ok: false, erro: e.message || String(e) });
  }
}

const server = http.createServer((req, res) => {
  const requestId = createRequestId();
  runWithRequestContext(requestId, () => {
    log('http.request.received', {
      method: req.method || 'GET',
      path: safePath(req.url || '/')
    });
    res.once('finish', () => {
      log('http.response.finished', {
        status: res.statusCode,
        duration_ms: elapsedMs()
      });
    });
    res.once('close', () => {
      if (!res.writableFinished) {
        log('http.response.closed_early', {
          status: res.statusCode,
          duration_ms: elapsedMs()
        }, 'warn');
      }
    });
    router(req, res).catch((error) => {
      log('http.request.unhandled_error', {
        error_name: error.name || 'Error'
      }, 'error');
      if (!res.headersSent) {
        send(res, 502, { ok: false, erro: 'erro interno do servidor' });
      } else {
        res.destroy();
      }
    });
  });
});

server.listen(PORT, () => {
  log('server.started', { port: Number(PORT) || PORT });
  console.log('======================================');
  console.log('🎬 MegaCine API online (node puro)');
  console.log('🌐 Porta: ' + PORT);
  console.log('📋 /painel /cronograma /pelicula /serial');
  console.log('📋 /estilo /lupa /dossier /projeto');
  console.log('======================================');
});

server.on('error', (error) => {
  log('server.error', { error_name: error.name || 'Error', code: error.code || null }, 'error');
});
