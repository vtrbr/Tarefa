# Correção e logs — MegaCine API

## O que foi alterado

- Corrigida somente a comparação de temporada/episódio em `lib/stream.js`: episódio `0` agora é tratado como um número válido na rota `/projeto/serie/:slug/:temporada/:episodio`.
- Acrescido logging estruturado em `server.js`, `lib/http.js`, `lib/stream.js` e `lib/proxy.js`.
- As rotas, o formato normal de resposta, o scraper, os headers do proxy e as outras funcionalidades foram mantidos.
- Adicionado `X-Request-Id` à resposta para facilitar a correlação com os logs.

## Validação executada nesta cópia

- `node --check` passou em `server.js` e nos arquivos JavaScript da pasta `lib/`.
- `/projeto/serie/helluva-boss/1/0` respondeu HTTP 200 e resolveu o ID `333131`.
- `/projeto/episodio/333132` respondeu HTTP 200.
- O proxy local entregou as playlists HLS com `#EXTM3U` e um segmento `video/MP2T` com HTTP 200.
- Foram observados logs estruturados de entrada/saída, chamadas upstream, seleção da fonte, reescrita de manifesto e encaminhamento de segmento. As query strings não apareceram nos registros.

## Onde ver os logs

O processo escreve JSON em uma linha por evento no `stdout`. No Render, consulte os logs do serviço da API. Pesquise pelo `request_id` para agrupar uma requisição recebida e as chamadas upstream feitas durante ela. Cada pedido separado do player ao proxy (manifesto ou segmento) terá seu próprio `request_id`.

Eventos mais úteis:

- `http.request.received` / `http.response.finished`: rota recebida, status e duração.
- `upstream.request.start` / `upstream.response.complete`: chamadas do scraper e resolver ao site/player, com status, bytes e duração.
- `stream.episode_number.lookup.found` / `not_found`: busca por temporada e episódio e ID encontrado.
- `stream.source.attempt` / `success` / `failed`: cada fonte candidata e resultado.
- `proxy.request.received`, `proxy.upstream.response.complete`: requisição do app ao proxy e busca remota do recurso.
- `proxy.manifest.rewritten`: playlist HLS reescrita e quantidade de URIs.
- `proxy.segment.forwarded`: status, tipo e bytes de cada segmento.

As URLs são registradas sem query string e segmentos de caminho longos são ocultados; assim, tokens de reprodução não devem aparecer nos logs. As requisições de segmento geram eventos por segmento, então a reprodução pode produzir muitas linhas.

## Teste rápido local

No Render, faça o deploy do conteúdo desta pasta como o serviço Node original. Para testar em máquina local, rode:

```bash
PORT=7400 PUBLIC_BASE_URL=http://localhost:7400 node server.js
```

Depois teste o caso que antes falhava:

```bash
curl -i http://localhost:7400/projeto/serie/helluva-boss/1/0
```

Esse caminho deve agora resolver o episódio 0. Os streams continuam temporários e a rota por ID, `/projeto/episodio/:episode_id`, permanece inalterada.
